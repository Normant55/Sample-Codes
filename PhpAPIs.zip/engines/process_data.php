<?php
header('Access-Control-Allow-Origin: 79.165.201.223:8080');
include('InputProcessor.php');
$new_processor = new InputProcess();
if($_POST['type']=='strip_tags'){
	$return_data = InputProcess::strip_tags($_POST['data']);
}elseif ($_POST['type']=='strip_javascript') {
	# code...
	$return_data = InputProcess::strip_javascript($_POST['data']);
}
echo $return_data;

?>