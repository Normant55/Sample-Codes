<?php
header('Access-Control-Allow-Origin: localhost:8080');
class Query{
	public static function selectall($dbh, $table){
		$query = $dbh->query("SELECT * FROM {$table}");
        $object_array = array();
        while($r = $query->fetch(PDO::FETCH_OBJ)) {
            $object_array[] = $r;
        }       
        return $object_array;
	}
	public static function countall($dbh, $table){
		$statement = $dbh -> query("SELECT count(*) FROM {$table}");
        return $statement->fetchColumn();
	}
	public static function selectallby($dbh, $operation_columns, $condition, $suffix, $condition_targets, $table){
				$array_operation_columns = explode("*-, ", $operation_columns);
				$array_condition_targets = explode("*-, ", $condition_targets);
				$query = "SELECT";
				$count = 0;
				$lenght = count($array_operation_columns);
				if(!(strlen($operation_columns) > 0 && strlen(trim($operation_columns)) == 0) && $operation_columns != ""){	
				foreach ($array_operation_columns as $array_columns){
					$query .= " ".$array_columns."";
					$count++;
					if($count!=$lenght){
						$query .=", ";
					}else{$query.=" ";}
				}
				}
				$regex = '~(:\w+)~';
				$count = 0;
				if(!(strlen($condition) > 0 && strlen(trim($condition)) == 0)  && $condition != ""){
				$query .= "FROM ".$table;
				$query .= ' WHERE '.$condition.' '.$suffix;
				$statement = $dbh -> prepare($query);
				if (preg_match_all($regex, $condition, $matches, PREG_PATTERN_ORDER)) {
   				foreach ($matches[1] as $word) {
					$statement->bindParam("".$word, $array_condition_targets[$count]);
					$count++;
   				}
				}
				}else{
					$query .= "FROM ".$table." ".$suffix;
					$statement = $dbh -> prepare($query);
				}
				$statement->execute();
        		$object_array = array();
        		while($r = $statement->fetch(PDO::FETCH_OBJ)) {
            		$object_array[] = $r;
        		}       
        		return $object_array;
	}
	public static function countallby($dbh, $condition, $suffix, $condition_targets, $table){
				$array_condition_targets = explode("*-, ", $condition_targets);
				$query = "SELECT count(*) ";
				$regex = '~(:\w+)~';
				$count = 0;
				if(!(strlen($condition) > 0 && strlen(trim($condition)) == 0)  && $condition != ""){
				$query .= "FROM ".$table;
				$query .= ' WHERE '.$condition.' '.$suffix;
				$statement = $dbh -> prepare($query);
				if (preg_match_all($regex, $condition, $matches, PREG_PATTERN_ORDER)) {
   				foreach ($matches[1] as $word) {
					$statement->bindParam("".$word, $array_condition_targets[$count]);
					$count++;
   				}
				}
				}else{
					$query .= "FROM ".$table." ".$suffix;
					$statement = $dbh -> prepare($query);
				}
				$statement->execute();
        		return $statement->fetchColumn();
	}
	public function run(){
		$dbh = $this->db;
		switch ($this->crud){
			case "UPDATE":
				if(isset($this->operation_columns)){
				$array_operation_columns = explode("*-, ", $this->operation_columns);
				}
				if(isset($this->operation_targets)){
				$array_operation_targets = explode("*-, ", $this->operation_targets);
				}
				if(isset($this->preset_columns)){
				$array_preset_columns = explode("*-, ", $this->preset_columns);
				}
				if(isset($this->preset_targets)){
				$array_preset_targets = explode("*-, ", $this->preset_targets);
				}
				$array_condition_targets = explode("*-, ", $this->condition_targets);
				$condition = $this->condition;
				$query = "UPDATE ";
				$query .= "".$this->table." SET";
				$count = 0;
				$lenght = 0;
				if(isset($this->operation_columns)&&!(strlen($this->operation_columns) > 0 && strlen(trim($this->operation_columns)) == 0) && $this->operation_columns != ""){
				$lenght = count($array_operation_columns);
				}
				if(isset($this->preset_columns)&&!(strlen($this->preset_columns) > 0 && strlen(trim($this->preset_columns)) == 0) && $this->preset_columns != ""){	
				$nextlenght = count($array_preset_columns);
				if(isset($this->operation_columns)&&!(strlen($this->operation_columns) > 0 && strlen(trim($this->operation_columns)) == 0) && $this->operation_columns != ""){			
				foreach ($array_operation_columns as $array_columns){
					$query .= " ".$array_columns."=".":".$array_columns;
					$count++;
					if($count!=$lenght){
						$query .=", ";
					}else{
						if($nextlenght > 0){
							$query.=", ";
						}else{
							$query.=" ";
						}
					}
				}
				}
				}else{
				if(!(strlen($this->operation_columns) > 0 && strlen(trim($this->operation_columns)) == 0) && $this->operation_columns != ""){			
				foreach ($array_operation_columns as $array_columns){
					$query .= " ".$array_columns."=".":".$array_columns;
					$count++;
					if($count!=$lenght){
						$query .=", ";
					}else{$query.=" ";}
				}
				}					
				}
				$count = 0;
				if(isset($this->preset_columns)&&!(strlen($this->preset_columns) > 0 && strlen(trim($this->preset_columns)) == 0) && $this->preset_columns != ""){	
				foreach ($array_preset_columns as $array_columns){
					$query .= " ".$array_columns."="." ".$array_preset_targets[$count++];
					$count++;
					if($count<$nextlenght){
						$query .=", ";
					}else{$query.=" ";}
				}
				}
				$regex = '~(:\w+)~';
				$count = 0;
				if(isset($this->condition)&&!(strlen($this->condition) > 0 && strlen(trim($this->condition)) == 0)  && $this->condition != ""){
				$query .= 'WHERE '.$condition;
				$statement = $dbh -> prepare($query);
				if (preg_match_all($regex, $condition, $matches, PREG_PATTERN_ORDER)) {
   				foreach ($matches[1] as $word) {
					$statement->bindParam("".$word, $array_condition_targets[$count]);
					$count++;
   				}
				}
				}else{
				$statement = $dbh -> prepare($query);
				}
				$count = 0;
				if(isset($this->operation_columns)&&!(strlen($this->operation_columns) > 0 && strlen(trim($this->operation_columns)) == 0) && $this->operation_columns != ""){
				foreach ($array_operation_columns as $array_columns){
					$statement->bindParam(":".$array_columns, $array_operation_targets[$count]);
					$count++;
				}
				}
				break; 
			case "DELETE":
				$array_condition_targets = explode("*-, ", $this->condition_targets);
				$condition = $this->condition;
				$query = "DELETE ";
				$query .= "FROM ".$this->table." ";
				$regex = '~(:\w+)~';
				$count = 0;
				if(isset($this->condition)&&!(strlen($this->condition) > 0 && strlen(trim($this->condition)) == 0)  && $this->condition != ""){
				$query .= 'WHERE '.$condition;
				$statement = $dbh -> prepare($query);
				if (preg_match_all($regex, $condition, $matches, PREG_PATTERN_ORDER)) {
   				foreach ($matches[1] as $word) {
					$statement->bindParam("".$word, $array_condition_targets[$count]);
					$count++;
   				}
				}
				}else{
					$statement = $dbh -> prepare($query);
				}
				break; 
			case "INSERT":
				if(isset($this->operation_columns)){
				$array_operation_columns = explode("*-, ", $this->operation_columns);
				}
				if(isset($this->operation_targets)){
				$array_operation_targets = explode("*-, ", $this->operation_targets);
				}
				if(isset($this->preset_columns)){
				$array_preset_columns = explode("*-, ", $this->preset_columns);
				}
				if(isset($this->preset_targets)){
				$array_preset_targets = explode("*-, ", $this->preset_targets);
				}
				$query = "INSERT ";
				$query .= "INTO ".$this->table."(";
				$count = 0;
				$lenght = count($array_operation_columns);
				if(isset($this->preset_columns)){
					$nextlenght = count($array_preset_columns);
				}else{
					$nextlenght = 0;
				}
				if(isset($this->operation_columns)&&!(strlen($this->operation_columns) > 0 && strlen(trim($this->operation_columns)) == 0) && $this->operation_columns != ""){			
				foreach ($array_operation_columns as $array_columns){
					$query .= "".$array_columns."";
					$count++;
					if($count!=$lenght){
						$query .=", ";
					}else{
						if($nextlenght > 0){
							$query.=", ";
						}else{
							$query.=")";
						}
					}
				}
				}
				$count = 0;
				if(isset($this->preset_columns)&&!(strlen($this->preset_columns) > 0 && strlen(trim($this->preset_columns)) == 0) && $this->preset_columns != ""){	
				foreach ($array_preset_columns as $array_columns){
					$query .= "".$array_columns."";
					$count++;
					if($count!=$nextlenght){
						$query .=", ";
					}else{$query.=")";}
				}
				}
				$query .= "VALUES(";
				$count = 0;
				$lenght = count($array_operation_columns);
				if(isset($this->preset_columns)){
					$nextlenght = count($array_preset_columns);
				}else{
					$nextlenght = 0;
				}
				if(isset($this->operation_columns)&&!(strlen($this->operation_columns) > 0 && strlen(trim($this->operation_columns)) == 0) && $this->operation_columns != ""){			
				foreach ($array_operation_columns as $array_columns){
					$query .= ":".$array_columns."";
					$count++;
					if($count!=$lenght){
						$query .=", ";
					}else{
						if($nextlenght > 0){
							$query.=", ";
						}else{
							$query.=")";
						}
					}
				}
				}
				$count = 0;
				if(isset($this->preset_targets)&&!(strlen($this->preset_targets) > 0 && strlen(trim($this->preset_targets)) == 0) && $this->preset_targets != ""){	
				foreach ($array_preset_targets as $array_columns){
					$query .= "".$array_columns."";
					$count++;
					if($count!=$nextlenght){
						$query .=", ";
					}else{$query.=")";}
				}
				}
				$statement = $dbh -> prepare($query);
				$count = 0;
				if(!(strlen($this->operation_columns) > 0 && strlen(trim($this->operation_columns)) == 0) && $this->operation_columns != ""){
				foreach ($array_operation_columns as $array_columns){
					$statement->bindParam(":".$array_columns, $array_operation_targets[$count]);
					$count++;
				}
				}
				break; 
			default:
				break; 
		}		
				$all='';
				try{
				$statement->execute();
				$msg = $this->message;
				}catch(Exception $e) {
    			$msg = 'Caught exception: ' .  $e->getMessage() . "\n";
    			$all = $all.$msg;
    			}
    			if($all!=''){
    			return $all;
    			}else{
    			return $msg;
    			}
	}
}
?>