<?php
class confirmation{
	public function confirmonly(){
		echo '<div class = "confirmation normal">';
		echo '<div class = "title">';
		echo '<h6>'.$this->title;
		echo '</h6></div>';
		echo '<div class = "message">';
		echo '<h6>'.$this->message;
		echo '</h6></div>';
		echo '<div class = "choices">';
		echo '<a class = "btn '.$this->button_class.'" href="'.$this->form_link.'">Confirm</a>';
		echo '</div>';
		echo '</div>';
	}
	public function confirmdata(){
		echo '<div class = "confirmation normal">';
		echo '<div class = "title">';
		echo '<h6>'.$this->title;
		echo '</h6></div>';
		echo '<div class = "message">';
		echo '<h6>'.$this->message;
		echo '</h6></div>';
		echo '<form action="'.$this->form_link.'" method="post">
        <div class = "row">';
        if(isset($this->post_feed_text)){	
		$array_feed_text = explode("*-, ", $this->post_feed_text);
		}
		if(isset($this->post_name_text)){	
		$array_name_text = explode("*-, ", $this->post_name_text);
		}
		if(isset($this->post_type_text)){	
		$array_type_text = explode("*-, ", $this->post_type_text);
		}
		// if(isset($this->post_feed_number)){	
		// $array_feed_number = explode("*-, ", $this->post_feed_number);
		// }
		// if(isset($this->post_name_number)){	
		// $array_name_number = explode("*-, ", $this->post_name_number);
		// }
		if(isset($this->submit_feed)){	
		$array_submit_feed = explode("*-, ", $this->submit_feed);
		}
		if(isset($this->submit_name)){
		$array_submit_name = explode("*-, ", $this->submit_name);
		}
		if(isset($this->submit_class)){
		$array_submit_class = explode("*-, ", $this->submit_class);
		}						
		$count = 0;	
		if(isset($this->post_feed_text) && !(strlen($this->post_feed_text) > 0 && strlen(trim($this->post_feed_text)) == 0) && $this->post_feed_text != ""){
			foreach ($array_feed_text as $array_columns){
				echo '<input class = "nodisplay" type="'.$array_type_text[$count].'" name = "'.$array_name_text[$count].'" value = "'.$array_columns.'">';
				$count++;
			}
		}
		// $count = 0;	
		// if(isset($this->post_feed_number) && !(strlen($this->post_feed_number) > 0 && strlen(trim($this->post_feed_number)) == 0) && $this->post_feed_number != ""){
		// 	foreach ($array_feed_number as $array_columns){
		// 		echo '<input class = "nodisplay" type="number" name = "'.$array_name_number[$count].'" value = "'.$array_columns.'">';
		// 		$count++;
		// 	}
		// }
		$count = 0;	
		if(isset($this->submit_feed) && !(strlen($this->submit_feed) > 0 && strlen(trim($this->submit_feed)) == 0) && $this->submit_feed != ""){
			foreach ($array_submit_feed as $array_columns){
				echo '<input class = "btn '.$array_submit_class[$count].'" type="submit" name="'.$array_submit_name[$count].'" value="'.$array_columns.'" >';
				$count++;
			}
		}
		echo '</div>
        </form>';
        echo '</div>';
	}
}
?>