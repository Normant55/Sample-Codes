<?php
header('Access-Control-Allow-Origin: localhost:8080');
class InputProcess(){
	public static function strip_tags($word){
		$return_word = strip_tags($word);
		return $return_word;
	}
	public static function strip_javascript($word){
		  $return_word = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $word);
		return $return_word;
	}
}
?>