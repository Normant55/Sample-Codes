<?php
define('URL', 'http://localhost:8080/jenny_prototype/');
include('Database.php');
$newdb = new Database();
$newdb->host = 'localhost';
$newdb->dbname = 'car_mobile';
$newdb->username = 'root';
$newdb->password = '';
$dbh=$newdb->connect_mysql();
?>