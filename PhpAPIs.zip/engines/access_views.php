<?php
header('Access-Control-Allow-Origin: 79.165.201.223:8080');
include('view_input.php');
$inputhandle = new inputframe();

//Class*** div_class

//<div class>div_class

//<div class = "input_outer_class">input_description
//<input type = "input_type" id = "input_id" class = "input_class">
//</div>

//<div class>input_button_outer_class
//<button id = "input_button_id" class = "input_button_class">input_button_description</button>
//</div>

//</div>

$inputhandle->div_class = $_POST['div_class'];

//<div class = "input_outer_class">input_description
//<input type = "input_type" id = "input_id" class = "input_class">
//</div>
$inputhandle->input_outer_class = $_POST['input_outer_class'];
$inputhandle->input_description = $_POST['input_description'];
$inputhandle->input_id = $_POST['input_id'];
$inputhandle->input_class = $_POST['input_class'];
$inputhandle->input_type = $_POST['input_type'];

//<div class>input_button_outer_class
//<button id = "input_button_id" class = "input_button_class">input_button_description</button>
//</div>
$inputhandle->input_button_outer_class = $_POST['input_button_outer_class'];
$inputhandle->input_button_description = $_POST['input_button_description'];
$inputhandle->input_button_id = $_POST['input_button_id'];
$inputhandle->input_button_class = $_POST['input_button_class'];

if(isset($_POST['view_type']) && !(strlen($_POST['view_type']) > 0 && strlen(trim($_POST['view_type'])) == 0) && $_POST['view_type'] != ""){
	$forquery = $inputhandle->vanilla_js();
		}else if($_POST['view_type' == 'vanilla']){
	$forquery = $inputhandle->vanilla_js();
		}else{
	$forquery = $inputhandle->vanilla_js();
		}

echo $forquery;
?>