<?php
class Database{
public static function databasecreate($dbname){
// $statement = "CREATE DATABASE IF NOT EXISTS :dbname;";
// $run->prepare($statement);
// $run->bindParam(":dbname", $dbname);
// $run->execute();
}

public static function tablecreate($tablename){

}

public function connect_db()
{
    try
    {
    $connection = new PDO('sqlsrv:server='.$this->host.';Database='.$this->dbname.'', ''.$this->username.'', ''.$this->password.'');
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    }
    catch (PDOException $e)
    {
        // Proccess error
        echo 'Cannot connect to database: ' . $e->getMessage();
    }

    return $connection;
}
public function connect_mysql()
{
    try
    {
    $connection = new PDO('mysql:host='.$this->host.';dbname='.$this->dbname.'', ''.$this->username.'', ''.$this->password.'');
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $connection->setAttribute(PDO::ATTR_PERSISTENT, true);
    }
    catch (PDOException $e)
    {
        // Proccess error
        echo 'Cannot connect to database: ' . $e->getMessage();
    }

    return $connection;
}
}
?>