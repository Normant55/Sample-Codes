<?php
header('Access-Control-Allow-Origin: localhost:8080');
class inputframe{
	public function vanilla_js(){

		//Class*** div_class

		//<div class>div_class

		//<div class = "input_outer_class">input_description
		//<input type = "input_type" id = "input_id" class = "input_class">
		//</div>

		//<div class>input_button_outer_class
		//<button id = "input_button_id" class = "input_button_class">input_button_description</button>
		//</div>

		//</div>

		if(isset($this->div_class) && !(strlen($this->div_class) > 0 && strlen(trim($this->div_class)) == 0) && $this->div_class != ""){
			echo '<div class = "'.$this->div_class.'">';
		}else{
			echo '<div class = "container">';
		}

		//Div Class*** input_outer_class
		if(isset($this->input_outer_class) && !(strlen($this->input_outer_class) > 0 && strlen(trim($this->input_outer_class)) == 0) && $this->input_outer_class != ""){
			$array_input_outer_class = explode("*-, ", $this->input_outer_class);
		}
		//Description*** input_description
		if(isset($this->input_description) && !(strlen($this->input_description) > 0 && strlen(trim($this->input_description)) == 0) && $this->input_description != ""){
			$array_input_description = explode("*-, ", $this->input_description);
		}
		//ID*** input_id
		if(isset($this->input_id) && !(strlen($this->input_id) > 0 && strlen(trim($this->input_id)) == 0) && $this->input_id != ""){
			$array_input_id = explode("*-, ", $this->input_id);
		}
		//Class*** input_class
		if(isset($this->input_class) && !(strlen($this->input_class) > 0 && strlen(trim($this->input_class)) == 0) && $this->input_class != ""){
			$array_input_class = explode("*-, ", $this->input_class);
		}
		//Type*** input_type
		if(isset($this->input_type) && !(strlen($this->input_type) > 0 && strlen(trim($this->input_type)) == 0) && $this->input_type != ""){
			$array_input_type = explode("*-, ", $this->input_type);
		}


		$count = 0;

		//<div class = "input_outer_class">input_description
		//<input type = "input_type" id = "input_id" class = "input_class">
		//</div>

		if(isset($this->input_id) && !(strlen($this->input_id) > 0 && strlen(trim($this->input_id)) == 0) && $this->input_id != ""){
			foreach ($array_input_id as $array_columns){
        		echo '<div class ="'.$array_input_outer_class[$count].'">'.$array_input_description[$count].'<input class = "'.$array_input_class[$count].'" type="'.$array_input_type[$count].'" id = "'.$array_columns.'"></div>';
				$count++;
			}
		}

		//Div Class*** input_button_outer_class
		if(isset($this->input_button_outer_class) && !(strlen($this->input_button_outer_class) > 0 && strlen(trim($this->input_button_outer_class)) == 0) && $this->input_button_outer_class != ""){
			$array_input_button_outer_class = explode("*-, ", $this->input_button_outer_class);
		}
		//Description*** input_button_description
		if(isset($this->input_button_description) && !(strlen($this->input_button_description) > 0 && strlen(trim($this->input_button_description)) == 0) && $this->input_button_description != ""){
			$array_input_button_description = explode("*-, ", $this->input_button_description);
		}
		//ID*** input_button_id
		if(isset($this->input_button_id) && !(strlen($this->input_button_id) > 0 && strlen(trim($this->input_button_id)) == 0) && $this->input_button_id != ""){
			$array_input_button_id = explode("*-, ", $this->input_button_id);
		}
		//Class*** input_button_class
		if(isset($this->input_button_class) && !(strlen($this->input_button_class) > 0 && strlen(trim($this->input_button_class)) == 0) && $this->input_button_class != ""){
			$array_input_button_class = explode("*-, ", $this->input_button_class);
		}

		$count = 0;	

		//<div class>input_button_outer_class
		//<button id = "input_button_id" class = "input_button_class">input_button_description</button>
		//</div>

		if(isset($this->input_button_id) && !(strlen($this->input_button_id) > 0 && strlen(trim($this->input_button_id)) == 0) && $this->input_button_id != ""){
			foreach ($array_input_button_id as $array_columns){
				echo '<div class ="'.$array_input_button_outer_class[$count].'"">
				<button class = "'.$array_input_button_class[$count].'" id="'.$array_columns.'" >'.$array_input_button_description[$count].'
				</button>
				</div>';
				$count++;
			}
		}	

		echo '</div>';
	}
}
?>