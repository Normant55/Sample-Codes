<?php
header('Access-Control-Allow-Origin: localhost:8080');
include("../connectPDO.php");
include("QueryEngine.php");
$itemhandle = new Query();
$itemhandle->db = $dbh;
if(isset($_POST['operation_columns'])){
	$array_operation_columns = explode("*-, ", $_POST['operation_columns']);
}
if(isset($_POST['condition_targets'])){
	$array_condition_targets = explode("*-, ", $_POST['condition_targets']);
}

if($_POST['type']=='select_all'){
	if($_POST['database']=='dbhsub'){
	$select_object = Query::selectall($dbhsub, $_POST['table']);
	}elseif($_POST['database']=='dbh_leave'){
	$select_object = Query::selectall($dbh_leave, $_POST['table']);
	}else{
    $select_object = Query::selectall($dbh, $_POST['table']);
	}
    foreach($select_object as $row)
       	{
			if(isset($_POST['operation_columns'])&&!(strlen($_POST['operation_columns']) > 0 && strlen(trim($_POST['operation_columns'])) == 0) && $_POST['operation_columns'] != ""){
				$count = 0;
				foreach ($array_operation_columns as $array_columns){
					$data = eval('return $row->'.$array_columns.';');
					// echo '<div class = "col-md-8 '.$array_column_class[$count].'"><div class = "datatitle">'.$array_column_headers[$count].': </div>'.$data.'</div>';
					echo $data;
					echo ', ';
					$count++;
				}
			}            
        }
}elseif($_POST['type']=='select_allby'){
	if($_POST['database']=='dbhsub'){
    $select_object = Query::selectallby($dbhsub, $_POST['operation_columns'], $_POST['condition'], $_POST['suffix'], $_POST['condition_targets'], $_POST['table']);
	}elseif($_POST['database']=='dbh_leave'){
	$select_object = Query::selectallby($dbh_leave, $_POST['operation_columns'], $_POST['condition'], $_POST['suffix'], $_POST['condition_targets'], $_POST['table']);
	}else{
    $select_object = Query::selectallby($dbh, $_POST['operation_columns'], $_POST['condition'], $_POST['suffix'], $_POST['condition_targets'], $_POST['table']);
	}
    foreach($select_object as $row)
       	{
			if(isset($_POST['operation_columns'])&&!(strlen($_POST['operation_columns']) > 0 && strlen(trim($_POST['operation_columns'])) == 0) && $_POST['operation_columns'] != "")
			{
				$count = 0;
				foreach ($array_operation_columns as $array_columns)
				{
					$data = eval('return $row->'.$array_columns.';');
					// echo '<div class = "col-md-8 '.$array_column_class[$count].'"><div class = "datatitle">'.$array_column_headers[$count].': </div>'.$data.'</div>';
					echo $data;
					echo ', ';
					$count++;
				}
			}           		
       	}	
}elseif($_POST['type']=='countallby'){
	if($_POST['database']=='dbhsub'){
    $select_object = Query::countallby($dbhsub, $_POST['condition'], $_POST['suffix'], $_POST['condition_targets'], $_POST['table']);
	}elseif($_POST['database']=='dbh_leave'){
	$select_object = Query::countallby($dbh_leave, $_POST['condition'], $_POST['suffix'], $_POST['condition_targets'], $_POST['table']);
	}else{
    $select_object = Query::countallby($dbh, $_POST['condition'], $_POST['suffix'], $_POST['condition_targets'], $_POST['table']);
	}
	echo $select_object;
}
?>
