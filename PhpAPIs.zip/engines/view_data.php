<?php
header('Access-Control-Allow-Origin: localhost:8080');
class itemframe{
	public function optionframe(){
		$dbh = $this->db;
		$itempage = $this->itempage;
?>
	<div class = "optionsframe">
<?php
    	$table = $this->table;
    	$row_count = Query::countall($dbh, $table);
    	$iteration = round($row_count/15, 0)+1;
    	if($itempage==1&&$itempage<$iteration){
?>
    	Page 1 of <?php echo $iteration?><a class = "btn btn-light" href="<?php currentlink; ?>?itempage=<?php echo 2?>">Next Page</a>
<?php
    	}else if($itempage<$iteration&&$itempage<$iteration){
?>
    	<a class = "btn btn-light" href="<?php currentlink; ?>?itempage=<?php echo $itempage-1?>">Previous</a>
   		Page <?php echo $_GET['itempage']?> of <?php echo $iteration?>
   		<a class = "btn btn-light" href="<?php currentlink; ?>?itempage=<?php echo $itempage+1?>">Next</a>
<?php        
    	}else if($itempage<=$iteration){
?>
    	<a class = "btn btn-light" href="<?php currentlink; ?>?itempage=<?php echo $itempage-1?>">Previous</a>
   		Page <?php echo $_GET['itempage']?> of <?php echo $iteration?>
<?php
		}else{			
?>
		Page <?php echo $itempage?> of <?php echo $iteration?>
<?php       
    }
    echo '</div>';
	}
	public function dataheader(){
		echo '<div class = "row dataheader">';
		if(isset($this->column_headers)){
			$array_column_headers = explode("*-, ", $this->column_headers);
		}
		if(isset($this->column_class)){
			$array_column_class = explode("*-, ", $this->column_class);
		}
		$count = 0;
		if(isset($this->column_headers)&&!(strlen($this->column_headers) > 0 && strlen(trim($this->column_headers)) == 0) && $this->column_headers != ""){
			foreach ($array_column_headers as $array_columns){
				echo '<div class = "'.$array_column_class[$count].'">'.$array_columns.'</div>';
				$count++;
			}
		}
		echo '</div>';
	}
	public function datagrid(){
		$dbh = $this->db;
		$form_link = $this->form_link;
		if(isset($this->column_class)){
			$array_column_class = explode("*-, ", $this->column_class);
		}
		if(isset($this->operation_columns)){
			$array_operation_columns = explode("*-, ", $this->operation_columns);
		}
		if(isset($this->column_headers)){
			$array_column_headers = explode("*-, ", $this->column_headers);
		}
		$products = Query::selectallby($dbh, $this->operation_columns, $this->condition, $this->suffix, $this->condition_targets, $this->table);
		foreach($products as $row) {
		$update_by_column = eval('return $row->'.$this->update_by_column.';');
		echo '
    	<div class = "row datagrid">';
		$count = 0;
		if(isset($this->operation_columns)&&!(strlen($this->operation_columns) > 0 && strlen(trim($this->operation_columns)) == 0) && $this->operation_columns != ""){
			foreach ($array_operation_columns as $array_columns){
				$data = eval('return $row->'.$array_columns.';');
				echo '<div class = "col-md-8 '.$array_column_class[$count].'"><div class = "datatitle">'.$array_column_headers[$count].': </div>'.$data.'</div>';
				$count++;
			}
		}
?>
    <div class = "col-md-8 col-lg-2">
    <a href="<?php echo $form_link;?><?php if(!isset($_GET['itempage'])){echo'?';}else{echo'&';} ?>updateid=<?php echo $update_by_column ?>"><?php echo $this->update_name?></a>
    </div>
    </div>
<?php	
		}
	}
	public function datatable(){
		if(isset($this->operation_title)){
			$array_operation_title = explode("*-, ", $this->operation_title);
		}
		if(isset($this->operation_title_description)){
			$array_operation_title_description = explode("*-, ", $this->operation_title_description);
		}
		if(isset($this->operation_message)){
			$array_operation_message = explode("*-, ", $this->operation_message);
		}
		if(isset($this->operation_message_description)){
			$array_operation_message_description = explode("*-, ", $this->operation_message_description);
		}
		if(isset($this->post_name_text)){	
		$array_name_text = explode("*-, ", $this->post_name_text);
		}
		if(isset($this->post_class_text)){
		$array_class_text = explode("*-, ", $this->post_class_text);
		}
		if(isset($this->post_type_text)){	
		$array_type_text = explode("*-, ", $this->post_type_text);
		}
		if(isset($this->post_text_description)){
		$array_text_description = explode("*-, ", $this->post_text_description);
		}
		// if(isset($this->post_name_number)){	
		// $array_name_number = explode("*-, ", $this->post_name_number);
		// }
		// if(isset($this->post_class_number)){	
		// $array_class_number = explode("*-, ", $this->post_class_number);
		// }
		// if(isset($this->post_number_description)){	
		// $array_number_description = explode("*-, ", $this->post_number_description);
		// }
		if(isset($this->submit_feed)){
		$array_submit_feed = explode("*-, ", $this->submit_feed);
		}
		if(isset($this->submit_name)){
		$array_submit_name = explode("*-, ", $this->submit_name);
		}
		if(isset($this->submit_class)){
		$array_submit_class = explode("*-, ", $this->submit_class);
		}
		$dbh = $this->db;
		$form_link = $this->form_link;
		$products = Query::selectallby($dbh, $this->operation_columns, $this->condition, $this->suffix, $this->condition_targets, $this->table);
		foreach($products as $row) {
			echo '<div class = "datatable '.$this->datatable_class.'">';
			echo '<div class = "title">';
			$count = 0;	
			if(isset($this->operation_title) && !(strlen($this->operation_title) > 0 && strlen(trim($this->operation_title)) == 0) && $this->operation_title != ""){
				foreach ($array_operation_title as $array_columns){
					$data = eval('return $row->'.$array_columns.';');
					echo ''.$array_operation_title_description[$count].': '.$data;
					$count++;
				}
			}
			echo '</div>';
			echo '<div class = "message">';
			$count = 0;	
			if(isset($this->operation_message) && !(strlen($this->operation_message) > 0 && strlen(trim($this->operation_message)) == 0) && $this->operation_message != ""){
				foreach ($array_operation_message as $array_columns){
					$data = eval('return $row->'.$array_columns.';');
					echo '<h6>'.$array_operation_message_description[$count].': '.$data.'</h6>';
					$count++;
				}
			}
			echo '</div>';
			echo '
        	<form action="'.$form_link.'" method="post">
        	<div class = "row">';
			$count = 0;	
			if(isset($this->post_name_text) && !(strlen($this->post_name_text) > 0 && strlen(trim($this->post_name_text)) == 0) && $this->post_name_text != ""){
				foreach ($array_name_text as $array_columns){
					$data = eval('return $row->'.$array_columns.';');
        			echo ''.$array_text_description[$count].'<input class = "'.$array_class_text[$count].'" type="'.$array_type_text[$count].'" name = "'.$array_columns.'" value = "'.$data.'">';
					$count++;
				}
			}
			// $count = 0;	
			// if(isset($this->post_name_number) && !(strlen($this->post_name_number) > 0 && strlen(trim($this->post_name_number)) == 0) && $this->post_name_number != ""){
			// 	foreach ($array_name_number as $array_columns){
			// 		$data = eval('return $row->'.$array_columns.';');
   //      			echo ''.$array_number_description[$count].'<input class = "'.$array_class_number[$count].'" type="number" name = "'.$array_columns.'" value = "'.$data.'">';
			// 		$count++;
			// 	}
			// }
			$count = 0;	
			if(isset($this->submit_feed) && !(strlen($this->submit_feed) > 0 && strlen(trim($this->submit_feed)) == 0) && $this->submit_feed != ""){
				foreach ($array_submit_feed as $array_columns){
					echo '<input class = "btn '.$array_submit_class[$count].'" type="submit" name="'.$array_submit_name[$count].'" value="'.$array_columns.'" >';
					$count++;
				}
			}
			echo'</div>
        	</form>';
        	echo '
        	<div class = "choices">
        	<a class = "btn btn-light" href="'.$form_link.'">Back</a>
			</div>';
        	echo '</div>';
		}
	}
}
?>