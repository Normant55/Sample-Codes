<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
$idea = $_POST['idea'];
$thequery = $dbhsub -> query("DELETE FROM newsextension WHERE newscontentid = '$idea'");
if($thequery){
	echo 'Successfully Deleted Subsection!';
}
if(file_exists("../../images/newsimages/".$idea.".png")){
$deleterpath = "../../images/newsimages/".$idea.".png";
unlink($deleterpath);
}
?>