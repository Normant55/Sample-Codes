<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
    $statement = $dbhsub -> query("SELECT TOP 12 * FROM mainnews WHERE featured = 'yes' ORDER BY dateuploaded ASC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
      echo $row['newsid'].', ';
  }
?>