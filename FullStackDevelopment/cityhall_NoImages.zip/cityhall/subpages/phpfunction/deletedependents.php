<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');


$studID =  $_GET['studID'];


	$query = $dbh->prepare("DELETE FROM employee_children WHERE child_numb = ?");
$stmt = $query->execute(array($studID));
if($stmt){
	echo 'Succesfully Deleted';
}
else{
	echo 'Fail';
}

?> 