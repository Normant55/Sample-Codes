<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
$startmonth =  $_GET['startmonthtoolkit'];
$startday =  $_GET['startdaytoolkit'];
$startyear =  $_GET['startyeartoolkit'];
$endmonth =  $_GET['endmonthtoolkit'];
$endday =  $_GET['enddaytoolkit'];
$endyear =  $_GET['endyeartoolkit'];
$status_select = $_GET['status_select'];
$gender_select =  $_GET['gender_select'];
$input_min_age =  $_GET['input_min_age'];
$input_max_age =  $_GET['input_max_age'];

if(isset($_GET['searchkeyword']) AND !empty($_GET['searchkeyword'])){
	$searchkeyword = $_GET['searchkeyword'];
}else{
	$searchkeyword = '';
}
if($gender_select == 1){
$gender_query = 'gender = 1';}elseif($gender_select == 0){
$gender_query = 'gender = 0';}elseif($gender_select == 2){
$gender_query = 'gender = 1 OR gender = 0';
}
if($status_select == 0){
$select_query = 'process_status = \'Hired\'';}
elseif($status_select == 3){
$select_query = 'process_status IS NULL';}
elseif($status_select == 2){
$select_query = 'process_status = \'Viewed\'';}
elseif($status_select == 1){
$select_query = 'process_status = \'For Exam\'';}
elseif($status_select == 4){
$select_query = '1 = 1';
}

echo '
  <div class = "no_lining">
  <a onclick = "reto(\'default\')" style = "cursor:pointer;">
  <img class = "img-responsive" src="images/return_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
  Exit</a>
</div>
';

echo '<div class = "col-xs-12">
  <h3>Search Applicant</h3>
  <div class = "col-md-4">
  <input type = "text" ng-disabled="true" class = "input_standard" onkeyup = "searchengineapplicant()" id ="searchapplicant"';if($searchkeyword!=''){echo'value = "'.$searchkeyword.'"';} echo' placeholder = "Search Keyword..." style = "width: 100%; margin-right: 2.5%;"></div>
';
echo '<div class = "keywords_category">';
echo 'Gender: ';
echo '<select class = "input_standard" id = "gender_select" onchange = "searchengineapplicant()">';
echo '<option value = 2 ';if($gender_select != 1 OR $gender_select != 0){echo'selected';}echo'>Any</option>
	  <option value = 1 ';if($gender_select == 1){echo'selected';}echo'>Male</option>
	  <option value = 0 ';if($gender_select == 0){echo'selected';}echo'>Female</option>';
echo '</select>';
echo '</div>';
echo '<div class = "keywords_category">';
echo 'Status: ';
echo '<select class = "input_standard" id = "status_select" onchange = "searchengineapplicant()">';
echo '<option value = 4 ';if($status_select != 0 OR $status_select != 1 OR $status_select != 2 OR $status_select != 3){echo'selected';}echo'>Any</option>
	  <option value = 3 ';if($status_select == 3){echo'selected';}echo'>New</option>
	  <option value = 2 ';if($status_select == 2){echo'selected';}echo'>Viewed</option>
	  <option value = 1 ';if($status_select == 1){echo'selected';}echo'>Exam</option>
	  <option value = 0 ';if($status_select == 0){echo'selected';}echo'>Hired</option>
	  ';
echo '</select>';
echo '</div>';
echo '<div class = "keywords_category">';
echo 'Age: ';
echo '
<input class = "input_standard" type = "number" ';if($input_min_age != 0 OR $input_max_age != 999){echo'value = "'.$input_min_age.'"';}else{
	echo'value = "0"';
	}echo' id = "input_min_age" onchange = "searchengineapplicant()">
---
<input class = "input_standard" type = "number" ';if($input_min_age != 0 OR $input_max_age != 999){echo'value = "'.$input_max_age.'"';}else{
	echo'value = "999"';
	}echo' id = "input_max_age" onchange = "searchengineapplicant()">';
echo '</div>';

$data_count = 0;
if(isset($_GET['searchkeyword']) AND !empty($_GET['searchkeyword'])){
	$searchkeyword = $_GET['searchkeyword'];
$keys = explode(" ", $searchkeyword);
$idfound_count = array();
$x = 1;
$current = 0;
while($x<2){
	if(isset($keys[$current]) && $keys[$current]!=''){
	$searchthis = $keys[$current];
	$current++;
$stmt = $dbh -> prepare("SELECT employeeid FROM Applicants WHERE (lastname LIKE :searchthis OR firstname LIKE :searchthis2 OR middle LIKE :searchthis3 OR job_title LIKE :searchthis4 OR eligibility LIKE :searchthis5 OR school_grad LIKE :searchthis6 OR course_degree LIKE :searchthis7 OR home_address LIKE :searchthis8) AND CONVERT(int, age) >= '$input_min_age' AND CONVERT(int, age) <= '$input_max_age' AND employeeid NOT IN ('".implode(' \', \'', $idfound_count)."') AND (".$select_query.") AND (".$gender_query.") AND date_registered between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000'");
$stmt -> bindValue(':searchthis', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis2', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis3', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis4', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis5', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis6', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis7', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis8', '%'.$searchthis.'%');

$stmt -> execute();
// $add_count = $stmt -> fetchColumn();
while($crow = $stmt -> fetch(PDO::FETCH_ASSOC)){
array_push($idfound_count, $crow['employeeid']);
	$data_count++;
	}
// $data_count = $data_count + $add_count;
}else{
	$x = 2;
}
}
}else{
$stmt = $dbh -> prepare("SELECT employeeid FROM Applicants WHERE CONVERT(int, age) >= '$input_min_age' AND CONVERT(int, age) <= '$input_max_age' AND date_registered between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' AND (".$select_query.") AND (".$gender_query.")");
$stmt -> execute();
// $add_count = $stmt -> fetchColumn();
while($crow = $stmt -> fetch(PDO::FETCH_ASSOC)){
	$data_count++;
	}
// $data_count = $data_count + $add_count;
}



// echo '<div class = "keywords_category">';
// echo 'Age:';
// echo '<input type = "number" id = "min_age_select" onclick = "searchengineapplicant()">-----';
// echo '<input type = "number" id = "max_age_select" onclick = "searchengineapplicant()">';
// echo '</div>';
echo '</div>';

echo '<div class = "col-xs-12"><div class = "datesectorover" style = "margin-bottom:20px;">';
echo '<div class = "datesector">';
echo '<div class = "markword col-xs-12 col-md-2 col-lg-2">Starting Date</div>';
echo '<div class = "markwordd">Month</div> <select id = "startmonth" onchange = "searchengineapplicant()">
<option value = 1 ';if($startmonth == 1){echo'selected';}echo'>January</option>
<option value = 2 ';if($startmonth == 2){echo'selected';}echo'>Febuary</option>
<option value = 3 ';if($startmonth == 3){echo'selected';}echo'>March</option>
<option value = 4 ';if($startmonth == 4){echo'selected';}echo'>April</option>
<option value = 5 ';if($startmonth == 5){echo'selected';}echo'>May</option>
<option value = 6 ';if($startmonth == 6){echo'selected';}echo'>June</option>
<option value = 7 ';if($startmonth == 7){echo'selected';}echo'>July</option>
<option value = 8 ';if($startmonth == 8){echo'selected';}echo'>August</option>
<option value = 9 ';if($startmonth == 9){echo'selected';}echo'>September</option>
<option value = 10 ';if($startmonth == 10){echo'selected';}echo'>October</option>
<option value = 11 ';if($startmonth == 11){echo'selected';}echo'>November</option>
<option value = 12 ';if($startmonth == 12){echo'selected';}echo'>December</option>
</select>';
echo '<div class = "markwordd">Day</div> <select id ="startday" onchange = "searchengineapplicant()">';
for($x=1; $x<=31; $x++){
	echo '<option value = '.$x.' ';if($startday == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markwordd">Year</div> <select id ="startyear" onchange = "searchengineapplicant()">';
for($x=1990; $x<=2030; $x++){
	echo '<option value = '.$x.' ';if($startyear == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markword col-xs-12 col-md-1 col-lg-1"> ----- </div>';
echo '<div class = "markwordd">Month</div> <select id = "endmonth" onchange = "searchengineapplicant()">
<option value = 1 ';if($endmonth == 1){echo'selected';}echo'>January</option>
<option value = 2 ';if($endmonth == 2){echo'selected';}echo'>Febuary</option>
<option value = 3 ';if($endmonth == 3){echo'selected';}echo'>March</option>
<option value = 4 ';if($endmonth == 4){echo'selected';}echo'>April</option>
<option value = 5 ';if($endmonth == 5){echo'selected';}echo'>May</option>
<option value = 6 ';if($endmonth == 6){echo'selected';}echo'>June</option>
<option value = 7 ';if($endmonth == 7){echo'selected';}echo'>July</option>
<option value = 8 ';if($endmonth == 8){echo'selected';}echo'>August</option>
<option value = 9 ';if($endmonth == 9){echo'selected';}echo'>September</option>
<option value = 10 ';if($endmonth == 10){echo'selected';}echo'>October</option>
<option value = 11 ';if($endmonth == 11){echo'selected';}echo'>November</option>
<option value = 12 ';if($endmonth == 12){echo'selected';}echo'>December</option>
</select>';
echo '<div class = "markwordd">Day</div> <select id ="endday" onchange = "searchengineapplicant()">';
for($x=1; $x<=31; $x++){
	echo '<option value = '.$x.' ';if($endday == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markwordd">Year</div> <select id ="endyear" onchange = "searchengineapplicant()">';
for($x=1990; $x<=2030; $x++){
	echo '<option value = '.$x.' ';if($endyear == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '</div></div>';

echo '<div class = "col-md-12 standard_margin"></div>';

echo '<div class = "col-md-3 passerbiga">Fullname</div>
  <div class = "col-md-2 passerbiga">Position</div>
  <div class = "col-md-3 passerbiga">Education</div> 
  <div class = "col-md-2 passerbiga">Eligibility</div>
  <div class = "col-md-2 passerbiga">Date Registered</div></div>
  <div class = "col-xs-12" id = "applicantlist_box">

  ';
if(isset($_GET['searchkeyword']) AND !empty($_GET['searchkeyword'])){
	$searchkeyword = $_GET['searchkeyword'];
$keys = explode(" ", $searchkeyword);
$idfound = array();
$x = 1;
$current = 0;
while($x<2){
	if(isset($keys[$current]) && $keys[$current]!=''){
	$searchthis = $keys[$current];
	$current++;
$statement = $dbh -> prepare("SELECT employeeid, lastname, firstname, middle, job_title, course_degree, eligibility, birthdate, CONVERT(VARCHAR(10),birthdate, 101) AS birthdate, school_grad, date_registered, CONVERT(int, age) AS age FROM Applicants WHERE (lastname LIKE :searchthis9 OR firstname LIKE :searchthis10 OR middle LIKE :searchthis11 OR job_title LIKE :searchthis12 OR eligibility LIKE :searchthis13 OR school_grad LIKE :searchthis14 OR course_degree LIKE :searchthis15 OR home_address LIKE :searchthis16) AND (CONVERT(int, age) >= '$input_min_age' AND CONVERT(int, age) <= '$input_max_age') AND employeeid NOT IN ('".implode(' \', \'', $idfound)."') AND (".$select_query.") AND (".$gender_query.") AND date_registered between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' ORDER BY date_registered DESC");
$statement -> bindValue(':searchthis9', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis10', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis11', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis12', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis13', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis14', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis15', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis16', '%'.$searchthis.'%');
$statement -> execute();
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
array_push($idfound, $row['employeeid']);
	echo '<div onmouseover = "color('.$row['employeeid'].')" onmouseout = "uncolor('.$row['employeeid'].')" style = "cursor:pointer; margin-bottom:50px;" onclick = "applicantshow('.$row['employeeid'].')">';
	echo '<div class = "col-md-12" id = "apall'.$row['employeeid'].'">';
	echo '<div class = "col-md-3 passerbigs phone_bar" id = "apname'.$row['employeeid'].'">'.strip_tags($row['lastname']).', '.strip_tags($row['firstname']).' '.strip_tags($row['middle']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apjob'.$row['employeeid'].'">'.strip_tags($row['job_title']).'</div>';
	echo '<div class = "col-md-3 passerbigs" id = "apgrad'.$row['employeeid'].'">'.strip_tags($row['course_degree']).' '.strip_tags($row['school_grad']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apelig'.$row['employeeid'].'">'.strip_tags($row['eligibility']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apbirth'.$row['employeeid'].'">'.strip_tags($row['date_registered']).'</div>';
	echo '</div></div>';
}
}else{
	$x = 2;
}
}

}else{
$statement = $dbh -> prepare("SELECT employeeid, lastname, firstname, middle, job_title, course_degree, eligibility, birthdate, CONVERT(VARCHAR(10),birthdate, 101) AS birthdate, school_grad, date_registered, CONVERT(int, age) AS age FROM Applicants WHERE (CONVERT(int, age) >= '$input_min_age' AND CONVERT(int, age) <= '$input_max_age') AND date_registered between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' AND (".$select_query.") AND (".$gender_query.") ORDER BY date_registered DESC");
$statement -> execute();
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
	echo '<div onmouseover = "color('.$row['employeeid'].')" onmouseout = "uncolor('.$row['employeeid'].')" style = "cursor:pointer; margin-bottom:50px;" onclick = "applicantshow('.$row['employeeid'].')">';
	echo '<div class = "col-md-12" id = "apall'.$row['employeeid'].'">';
	echo '<div class = "col-md-3 passerbigs phone_bar" id = "apname'.$row['employeeid'].'">'.strip_tags($row['lastname']).', '.strip_tags($row['firstname']).' '.strip_tags($row['middle']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apjob'.$row['employeeid'].'">'.strip_tags($row['job_title']).'</div>';
	echo '<div class = "col-md-3 passerbigs" id = "apgrad'.$row['employeeid'].'">'.strip_tags($row['course_degree']).' '.strip_tags($row['school_grad']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apelig'.$row['employeeid'].'">'.strip_tags($row['eligibility']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apbirth'.$row['employeeid'].'">'.strip_tags($row['date_registered']).'</div>';
	echo '</div></div>
	';
}
}
echo '<div class = "keywords_category">Search Count: '.$data_count.'</div>';
echo '</div>';
?>