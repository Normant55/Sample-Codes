<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
$attribute = $_POST['attribute'];
$colspan = $_POST['colspan'];
$description = $_POST['textarea'];
$publisher = $_POST['publisher'];
$imagepriority = $_POST['imagepriority'];
$selectortitlecover = $_POST['selectortitlecover'];
$description = str_replace("e1p1", "<", $description);
$description = str_replace("e1p2", ">", $description);
$description = str_replace("e1p3", "\"", $description);
$description = str_replace("e1p4", "#", $description);
$description = str_replace("e1p5", "(", $description);
$description = str_replace("e1p6", ")", $description);
$description = str_replace("e1p7", "-", $description);
$description = str_replace("e1p8", ":", $description);
$description = str_replace("e1p9", "&", $description);
if($attribute == 'maintitle'){
$statement = $dbhsub -> prepare("INSERT INTO covertitleimage(imagetitle, sizeposition, dateuploaded)VALUES(:textarea, :colspan, GETDATE())");
$statement -> bindParam(":textarea", $description);
$statement -> bindParam(":colspan", $colspan);
$statement -> execute();

$filestatement = $dbhsub -> query("SELECT TOP 1 imageid FROM covertitleimage ORDER BY imageid DESC");
	while($filerow = $filestatement ->fetch(PDO::FETCH_ASSOC)){
		$currentidea = $filerow['imageid'];
	}

$titleformeta = strip_tags($description);
$myfile = fopen("../coverthumbs/coverfile".$currentidea.".html", "w");
$txt = "
<!DOCTYPE HTML>
<html lang = \"en\">
<meta charset = \"utf-8\">
<meta property=\"og:description\" content=\"end description\" />
<meta property=\"og:title\" content=\"".$titleformeta."\" />
<script type = \"text/javascript\">
        function viewthiscover(){
        window.location.href = \"../../index\";
        }
        window.onload = viewthiscover;
</script>
".$description."
";

fwrite($myfile, $txt);
fclose($myfile);


}else{
$statement = $dbhsub -> prepare("INSERT INTO coverextender(imageid, description, type, sizeposition, dateuploaded, imagepath, prioritycode)VALUES(:selectortitlecover, :textarea, :attribute, :colspan, GETDATE(), 'none', :imagepriority)");
$statement -> bindParam(":selectortitlecover", $selectortitlecover);
$statement -> bindParam(":textarea", $description);
$statement -> bindParam(":attribute", $attribute);
$statement -> bindParam(":colspan", $colspan);
$statement -> bindParam(":imagepriority", $imagepriority);
$statement -> execute();

$oldfile = file_get_contents("../coverthumbs/coverfile".$selectortitlecover.".html");

$myfile = fopen("../coverthumbs/coverfile".$selectortitlecover.".html", "w");



$description = strip_tags($description);

$oldfile = str_replace("<meta property=\"og:description\" content=\"", "<meta property=\"og:description\" content=\"".$description." ", $oldfile);
$oldfile = str_replace("</script>", "</script> ".$description, $oldfile);

fwrite($myfile, $oldfile);
fclose($myfile);
}
?>