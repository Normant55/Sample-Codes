<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$ok = $_GET['idea'];
  $statement = $dbhsub -> query("SELECT * FROM mainnews WHERE newsid = '$ok'");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
      // [newscontentid]
      // ,[newsid]
      // ,[description]
      // ,[type]
      // ,[sizeposition]
      // ,[imagepath]
      // ,[dateuploaded]

      // [newsid]
      // ,[title]
      // ,[type]
      // ,[sizeposition]
      // ,[dateuploaded]
      // ,[publisher]
    echo 'Featured: ';
    if($row['featured']!='yes'){
    echo ' <img id="frontimagedesign" onclick = "updatefeature('.$row['newsid'].')" src="../images/uncheckedf.png" alt="image test" style = "background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  width: 2%;
  height: 3.5vh;
  cursor:pointer;
           " />';}
           else{
    echo ' <img id="frontimagedesign" onclick = "removefeature('.$row['newsid'].')" src="../images/checkedf.png" alt="image test" style = "background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  width: 2%;
  height: 3.5vh;
  cursor:pointer;
           " />';
           }

    echo '<div class = "container">';
    if($row['sizeposition'] == 'half'){
    echo '<div class = "col-md-6" onclick = "optionmain('.$row['newsid'].')" style = "cursor:pointer;">';}else{
    echo '<div class = "col-md-12" onclick = "optionmain('.$row['newsid'].')" style = "cursor:pointer;">';     
    }
           $fulldesc = str_replace("hexor", "normalize", $row['title']);

         echo '<h1 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h1>';
         echo '<h4>Uploaded on '.$row['dateuploaded'].' by '.$row['publisher'].'</h4>';
echo'</div>';

  }

  // <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  //     <!-- Indicators -->
  //     <ol class="carousel-indicators">
  //       <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
  //       <li data-target="#carousel-example-generic" data-slide-to="1"></li>
  //       <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  //     </ol>

  //     <!-- Wrapper for slides -->
  //     <div class="carousel-inner">
  //       <div class="item active">
  //         <img src="http://placehold.it/800x400" alt="...">
  //         <div class="carousel-caption">
  //           <h2>Heading</h2>
  //         </div>
  //       </div>
  //       <div class="item">
  //         <img src="http://placehold.it/800x400" alt="...">
  //         <div class="carousel-caption">
  //           <h2>Heading</h2>
  //         </div>
  //       </div>
  //       <div class="item">
  //         <img src="http://placehold.it/800x400" alt="...">
  //         <div class="carousel-caption">
  //           <h2>Heading</h2>
  //         </div>
  //       </div>
  //     </div>

  //     <!-- Controls -->
  //     <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
  //       <span class="glyphicon glyphicon-chevron-left"></span>
  //     </a>
  //     <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
  //       <span class="glyphicon glyphicon-chevron-right"></span>
  //     </a>
  //   </div>

$carouselcount = 0;
  $statement = $dbhsub -> query("SELECT * FROM newsextension WHERE newsid = '$ok' AND sizeposition = 'carousel' ORDER BY prioritycode ASC, dateuploaded DESC");
   while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
    $carouselcount++;
   }
if($carouselcount>1){
echo '<section class="section-white">';
echo ' <div class="container carouscontainer">';
echo '  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
      <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>';

  $nowcount = 1;
  while($nowcount<$carouselcount){
   echo '
        <li data-target="#carousel-example-generic" data-slide-to="'.$nowcount.'"></li>';
   $nowcount++;
  }

  echo '       </ol>

      <!-- Wrapper for slides -->
      <div class="carousel-inner">';
$shincount = 1;
  $statement = $dbhsub -> query("SELECT * FROM newsextension WHERE newsid = '$ok' AND sizeposition = 'carousel' ORDER BY prioritycode ASC, dateuploaded DESC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){

if($shincount == 1){
      echo '
       <div class="item imgvlg active" onclick = "optionsub('.$row['newscontentid'].')">
      <img src="../images/newsimages/'.$row['newscontentid'].'.png" alt="image" class = "imgvlg">
        </div>';
}else{
      echo '
       <div class="item imgvlg" onclick = "optionsub('.$row['newscontentid'].')">
      <img src="../images/newsimages/'.$row['newscontentid'].'.png" alt="image" class = "imgvlg">
        </div>';}
    $shincount++;
}
    echo '
  </div>
    <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
      </a>
      <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
      </a>
    </div>';
echo '  </div>
</section>';
}




  $statement = $dbhsub -> query("SELECT * FROM newsextension WHERE newsid = '$ok' AND sizeposition != 'carousel' ORDER BY prioritycode ASC, dateuploaded DESC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
 



  if($row['sizeposition']=='half'||$row['sizeposition']=='halfl'||$row['sizeposition']=='halfl2'||$row['sizeposition']=='halfl3'){
  echo '<div class = "col-md-6" onclick = "optionsub('.$row['newscontentid'].')" style = "cursor:pointer;">';}else{
  echo '<div class = "col-md-12" onclick = "optionsub('.$row['newscontentid'].')" style = "cursor:pointer;">';  
  }
    if($row['type'] == 'none'){
  echo ' <img ';
if($row['sizeposition']=='half'||$row['sizeposition']=='full'){
  echo 'class = "imgvsm"';
}elseif($row['sizeposition']=='halfl'||$row['sizeposition']=='fullt'){
  echo 'class = "imgvlg"';
}elseif($row['sizeposition']=='halfl2'||$row['sizeposition']=='fullt2'){
  echo 'class = "imgvlg2"';
}elseif($row['sizeposition']=='halfl3'||$row['sizeposition']=='fullt3'){
  echo 'class = "imgvlg3"';
}

echo ' id="frontimagedesign" src="../images/newsimages/'.$row['newscontentid'].'.png" alt="image test" style = "background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);';
echo 'width: 100%;

           " />';}

           $fulldesc = str_replace("hexor", "normalize", $row['description']);
           if($row['type'] == 'paragraph'){
         
         echo '<p style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</p>';
       }elseif($row['type'] == 's1'){
         echo '<h1 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h1>';      
         }
         elseif($row['type'] == 's2'){
         echo '<h2 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h2>';      
         }
         elseif($row['type'] == 's3'){
         echo '<h3 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h3>';      
         }
         elseif($row['type'] == 's4'){
         echo '<h4 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h4>';      
         }
         elseif($row['type'] == 's5'){
         echo '<h5 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h5>';      
         }
         elseif($row['type'] == 's6'){
         echo '<h6 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h6>';      
         }
echo'</div>';


  }
  echo '</div>';
?>



        