<ul>
<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');

if(!empty($_GET['choosenvalue'])){
	$choosenvalue = $_GET['choosenvalue'];
}
if(!empty($_GET['addedvalues'])){
	$addedvalues = $_GET['addedvalues'];
	$mainvalue = str_replace("<li><a>", "", $addedvalues);
	$myarray = explode("</a></li>", $mainvalue);
}


		if(!empty($choosenvalue)){
	$query = "select position, item_code from recruitment ORDER BY item_code ASC";
	$stmt = $dbh -> query($query);
	while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
		$department = ''.$row['item_code'].':'.$row['position'];
		$department = ltrim(rtrim($department));
		if($department == 'OFFICE OF THE CITY COOPERATIVE DEVELOPMENT & LIVELIHOOD OFFICER'){
			$department = 'OFFICE OF THE CITY COOPERATIVE DEVELOPMENT N LIVELIHOOD OFFICER';
		}

		if(!empty($myarray)){
		if(!in_array($department, $myarray)){

			if($department == ltrim(rtrim($choosenvalue))){
		echo '<li style = "background-color: rgba(100,100,240, 0.5);"><a onclick = "addthis(\''.$department.'\')">'.$department.'</a></li>';
		}else{
		echo '<li><a onclick = "addthis(\''.$department.'\')">'.$department.'</a></li>';
	}}}
	else{

if($department == ltrim(rtrim($choosenvalue))){
		echo '<li style = "background-color: rgba(100,100,240, 0.5);"><a onclick = "addthis(\''.$department.'\')">'.$department.'</a></li>';
		}else{
		echo '<li><a onclick = "addthis(\''.$department.'\')">'.$department.'</a></li>';
	}

	}


	}
}else{
$query = "select position, item_code from recruitment ORDER BY item_code ASC";
	$stmt = $dbh -> query($query);
	while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
		$department = ''.$row['item_code'].':'.$row['position'];
		$department = ltrim(rtrim($department));
		if($department == 'OFFICE OF THE CITY COOPERATIVE DEVELOPMENT & LIVELIHOOD OFFICER'){
			$department = 'OFFICE OF THE CITY COOPERATIVE DEVELOPMENT N LIVELIHOOD OFFICER';
		}

		echo '<li><a onclick = "addthis(\''.$department.'\')">'.$department.'</a></li>';
	}

}
?>
</ul>