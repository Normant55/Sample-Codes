<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$ok = $_POST['ok'];

echo '<button class = "btn btn-info" data-toggle="collapse" data-target="#customurl">Share</button>

<input class = "customurl" type = "text" id="customurl" class="collapse" value = "newsarchivethumbs/newsfile'.$ok.'">';
  $statement = $dbhsub -> query("SELECT * FROM mainnews WHERE newsid = '$ok'");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
      // [newscontentid]
      // ,[newsid]
      // ,[description]
      // ,[type]
      // ,[sizeposition]
      // ,[imagepath]
      // ,[dateuploaded]

      // [newsid]
      // ,[title]
      // ,[type]
      // ,[sizeposition]
      // ,[dateuploaded]
      // ,[publisher]
    $username = $row['username'];
    echo '<div class = "col-md-12">';
    if($row['sizeposition'] == 'half'){
    echo '<div class = "col-md-6">';}else{
    echo '<div class = "col-md-12">';     
    }
           $fulldesc = str_replace("hexor", "normalize", preg_replace('#<script(.*?)>(.*?)</script>#is', '', $row['title']));

         echo '<h1 style = "font-family: \'Julius Sans One\', sans-serif; font-weight: bold;">'.$fulldesc.'</h1>';
         if($row['username']=='administrator'){
        echo '<h4 style = "font-family: \'Lato\', sans-serif; text-transform: uppercase;">Uploaded on '.$row['dateuploaded'].' by '.$row['publisher'].'</h4>';}else{
  $userstatement = $dbh -> query("SELECT [employeeid] FROM [userlogn] WHERE [username] = '$username'");
  while($userrow = $userstatement ->fetch(PDO::FETCH_ASSOC)){
    $thekey = $userrow['employeeid'];
  }
  //       echo '<h4 style = "font-family: \'Lato\', sans-serif; text-transform: uppercase;">Uploaded on '.$row['dateuploaded'].' by <a href="profilethumbs/profilefile'.$thekey.'" style = "text-decoration: none;">'.$row['publisher'].'
  //         <img class = "profilepicture" id="frontimagedesign" src="../images/employeeimages/profile'.$thekey.'.jpg" alt="image test" style = "
  // background-repeat: no-repeat;
  // background-size: 100% 100%;
  // background-position: 20% 50%;
  // background-color: rgba(200,200,200, 0);
  // border-radius: 50%;
  //          " /></a></h4>
  //       ';
$publisher = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $row['publisher']);
          echo '<h4 style = "font-family: \'Lato\', sans-serif; text-transform: uppercase;">Uploaded on '.$row['dateuploaded'].' by '.$publisher.'';
echo'</div>';




         }
echo'</div>';

  }


$carouselcount = 0;
  $statement = $dbhsub -> query("SELECT * FROM newsextension WHERE newsid = '$ok' AND sizeposition = 'carousel' ORDER BY prioritycode ASC, dateuploaded DESC");
   while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
    $carouselcount++;
   }
if($carouselcount>1){
echo '<section class="section-white">';
echo ' <div class="container carouscontainer">';
echo '  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
      <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>';

  $nowcount = 1;
  while($nowcount<$carouselcount){
   echo '
        <li data-target="#carousel-example-generic" data-slide-to="'.$nowcount.'"></li>';
   $nowcount++;
  }

  echo '       </ol>

      <!-- Wrapper for slides -->
      <div class="carousel-inner">';
$shincount = 1;
  $statement = $dbhsub -> query("SELECT * FROM newsextension WHERE newsid = '$ok' AND sizeposition = 'carousel' ORDER BY prioritycode ASC, dateuploaded DESC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){

if($shincount == 1){
      echo '
       <div class="item imgvlg active" onclick = "optionsub('.$row['newscontentid'].')">
      <img src="../images/newsimages/'.$row['newscontentid'].'.png" alt="image" class = "imgvlg">
        </div>';
}else{
      echo '
       <div class="item imgvlg" onclick = "optionsub('.$row['newscontentid'].')">
      <img src="../images/newsimages/'.$row['newscontentid'].'.png" alt="image" class = "imgvlg">
        </div>';}
    $shincount++;
}
    echo '
  </div>
    <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
      </a>
      <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
      </a>
    </div>';
echo '  </div>
</section>';
}



  $statement = $dbhsub -> query("SELECT * FROM newsextension WHERE newsid = '$ok' AND sizeposition != 'carousel' ORDER BY prioritycode ASC, dateuploaded DESC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
 



    if($row['type'] == 'none'){

  if($row['sizeposition']=='half'||$row['sizeposition']=='halfl'||$row['sizeposition']=='halfl2'||$row['sizeposition']=='halfl3'){
  echo '<div class = "col-md-6" onclick = "optionsub('.$row['newscontentid'].')">';}else{
  echo '<div class = "col-md-12" onclick = "optionsub('.$row['newscontentid'].')">';  
  }


  echo ' <img ';
if($row['sizeposition']=='half'||$row['sizeposition']=='full'){
  echo 'class = "imgvsm"';
}elseif($row['sizeposition']=='halfl'||$row['sizeposition']=='fullt'){
  echo 'class = "imgvlg"';
}elseif($row['sizeposition']=='halfl2'||$row['sizeposition']=='fullt2'){
  echo 'class = "imgvlg2"';
}elseif($row['sizeposition']=='halfl3'||$row['sizeposition']=='fullt3'){
  echo 'class = "imgvlg3"';
}
 echo  ' id="frontimagedesign" src="../images/newsimages/'.$row['newscontentid'].'.png" alt="image test" style = "background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);';
echo 'width: 100%;
           " />';}else{
              if($row['sizeposition']=='half'||$row['sizeposition']=='halfl'||$row['sizeposition']=='halfl2'||$row['sizeposition']=='halfl3'){
  echo '<div class = "col-md-6">';}else{
  echo '<div class = "col-md-12">';  
  }
           }
          $description = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $row['description']);
           $fulldesc = str_replace("hexor", "normalize", $description);
           if($row['type'] == 'paragraph'){
        
         echo '<p style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</p>';
       }elseif($row['type'] == 's1'){
         echo '<h1 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h1>';      
         }
         elseif($row['type'] == 's2'){
         echo '<h2 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h2>';      
         }
         elseif($row['type'] == 's3'){
         echo '<h3 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h3>';      
         }
         elseif($row['type'] == 's4'){
         echo '<h4 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h4>';      
         }
         elseif($row['type'] == 's5'){
         echo '<h5 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h5>';      
         }
         elseif($row['type'] == 's6'){
         echo '<h6 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h6>';      
         }
echo'</div>';


  }
  echo '</div>';
?>



        