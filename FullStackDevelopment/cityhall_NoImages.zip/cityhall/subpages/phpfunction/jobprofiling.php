<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$jobvalue = $_GET['jobvalue'];


echo '<div class = "container"><div class = "col-md-12"><img src = ""></div>';
echo '</div>';
$query = $dbhhris -> query("SELECT * FROM ITEMS  WHERE Itemnos = '$jobvalue'");
while($row = $query -> fetch(PDO::FETCH_ASSOC)){

echo '<li>Item No: <a>'.$row['Itemnos'].'</a></li>';
echo '<li>Position Code: <a>'.$row['Poscode'].'</a></li>';
echo '<li><a>'.$row['PositionN'].'</a></li>';
echo '<li>Department: <a>'.$row['DeptDesc'].'</a></li>';
echo '<li>Grade: <a>'.$row['Grade'].'</a></li>';
echo '<li>Rate: <a>'.$row['Rate'].'</a></li>';

	}

?>
