<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
$attribute = $_POST['attribute'];
$colspan = $_POST['colspan'];
$description = $_POST['textarea'];
$publisher = $_POST['publisher'];
$imagepriority = $_POST['imagepriority'];
$usertype = $_POST['usertype'];
$userprof = $_POST['userprof'];
if($publisher == 'employee'){
$statement = $dbhsub -> query("SELECT firstname, middlename,lastname FROM [profiletable] WHERE [username] = '$userprof'");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
        $publisher = $row['firstname'].' '.$row['middlename'].' '.$row['lastname'];
  }
}
$selectortitlecover = $_POST['selectortitlecover'];
$description = str_replace("e1p1", "<", $description);
$description = str_replace("e1p2", ">", $description);
$description = str_replace("e1p3", "\"", $description);
$description = str_replace("e1p4", "#", $description);
$description = str_replace("e1p5", "(", $description);
$description = str_replace("e1p6", ")", $description);
$description = str_replace("e1p7", "-", $description);
$description = str_replace("e1p8", ":", $description);
$description = str_replace("e1p9", "&", $description);
$description = str_replace("<head>", " ", $description);
$description = str_replace("<body>", " ", $description);
if($usertype == 'admin'){
	$stats = 'covered';
}else{
	$stats = 'pending';
}
if($attribute == 'maintitle'){
$statement = $dbhsub -> prepare("INSERT INTO mainnews(title, type, sizeposition, dateuploaded, publisher, featured, username, status, datestatuschange)VALUES(:textarea, :attribute, :colspan, GETDATE(), :publisher, 'no', '$userprof', '$stats', GETDATE())");
$statement -> bindParam(":textarea", $description);
$statement -> bindParam(":attribute", $attribute);
$statement -> bindParam(":colspan", $colspan);
$statement -> bindParam(":publisher", $publisher);
$statement -> execute();

$filestatement = $dbhsub -> query("SELECT TOP 1 newsid FROM mainnews ORDER BY newsid DESC");
	while($filerow = $filestatement ->fetch(PDO::FETCH_ASSOC)){
		$currentidea = $filerow['newsid'];
	}
if($usertype == 'admin'){
$titleformeta = strip_tags($description);
$myfile = fopen("../newsarchivethumbs/newsfile".$currentidea.".html", "w");
$txt = "
<!DOCTYPE HTML>
<html lang = \"en\">
<meta charset = \"utf-8\">
<meta property=\"og:description\" content=\"end description\" />
<meta property=\"og:title\" content=\"".$titleformeta."\" />
<script type = \"text/javascript\">
        function viewthisnews(){
        window.localStorage.setItem(\"newsdefault\", ".$currentidea.");
        window.location.href = \"../newsarchive\";
        }
        window.onload = viewthisnews;
</script>
".$description."
";

fwrite($myfile, $txt);
fclose($myfile);}else{
$titleformeta = strip_tags($description);
$myfile = fopen("../newsarchivethumbs/newsfile".$currentidea.".html", "w");
$txt = "
<!DOCTYPE HTML>
<html lang = \"en\">
<meta charset = \"utf-8\">
<meta property=\"og:description\" content=\"end description\" />
<meta property=\"og:title\" content=\"".$titleformeta."\" />
<script type = \"text/javascript\">
        function viewthisnews(){
        window.localStorage.setItem(\"newsdefault\", ".$currentidea.");
        window.location.href = \"personalarchive\";
        }
        window.onload = viewthisnews;
</script>
".$description."
";

fwrite($myfile, $txt);
fclose($myfile);	
}

}else{
$statement = $dbhsub -> prepare("INSERT INTO newsextension(newsid, description, type, sizeposition, dateuploaded, imagepath,prioritycode)VALUES(:selectortitlecover, :textarea, :attribute, :colspan, GETDATE(), 'none', :imagepriority)");
$statement -> bindParam(":selectortitlecover", $selectortitlecover);
$statement -> bindParam(":textarea", $description);
$statement -> bindParam(":attribute", $attribute);
$statement -> bindParam(":colspan", $colspan);
$statement -> bindParam(":imagepriority", $imagepriority);
$statement -> execute();
if($usertype == 'admin'){
$oldfile = file_get_contents("../newsarchivethumbs/newsfile".$selectortitlecover.".html");

$myfile = fopen("../newsarchivethumbs/newsfile".$selectortitlecover.".html", "w");



$description = strip_tags($description);

$oldfile = str_replace("<meta property=\"og:description\" content=\"", "<meta property=\"og:description\" content=\"".$description." ", $oldfile);
$oldfile = str_replace("</script>", "</script> ".$description, $oldfile);

fwrite($myfile, $oldfile);
fclose($myfile);}
}
?>