<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");

$divid = $_GET['divid'];
$dividname = $_GET['dividname'];
$divdescription = $_GET['divdescription'];

$insertuser = $dbhsub -> query("UPDATE customdescriptions SET dividname = '$dividname', divdescription = '$divdescription', datemodified = GETDATE() WHERE descriptid = '$divid'");
if($insertuser){
}
// echo $divid.$dividname.$divdescription;
// 		  [descriptid]
//       ,[dividname]
//       ,[divdescription]
//       ,[datemodified] 

?>