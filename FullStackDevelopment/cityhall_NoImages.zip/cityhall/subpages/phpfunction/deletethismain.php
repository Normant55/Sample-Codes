<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
$idea = $_POST['idea'];
$thequery = $dbhsub -> query("DELETE FROM mainnews WHERE newsid = '$idea'");
if($thequery){
	echo 'Successfully Deleted News';
}
$allthere = $dbhsub -> query("SELECT newscontentid FROM newsextension WHERE newsid = '$idea'");
while($row = $allthere -> fetch(PDO::FETCH_ASSOC)){
if(file_exists("../../images/newsimages/".$row['newscontentid'].".png")){
$deleterpath = "../../images/newsimages/".$row['newscontentid'].".png";
unlink($deleterpath);
}
}
$thequery = $dbhsub -> query("DELETE FROM newsextension WHERE newsid = '$idea'");
if($thequery){
}

?>