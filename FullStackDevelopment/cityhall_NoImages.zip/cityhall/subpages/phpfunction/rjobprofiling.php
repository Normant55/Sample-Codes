<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$jobvalue = $_GET['jobvalue'];
echo '<div class = "container"><div class = "col-md-12"><img src = ""></div>';
echo '</div>';
$query = $dbh -> query("SELECT * FROM recruitment WHERE item_code = '$jobvalue'");
while($row = $query -> fetch(PDO::FETCH_ASSOC)){
echo '<li>Item No: <a>'.$row['item_code'].'</a></li>';
echo '<li><a>'.$row['position'].'</a></li>';
echo '<li>Department: <a>'.$row['department'].'</a></li>';
echo '<li>Grade: <a>'.$row['job_grade'].'</a></li>';
echo '<li>Level: <a>'.$row['job_level'].'</a></li>';
echo '<li>Education: <a>'.$row['education'].'</a></li>';
echo '<li>Experience: <a>'.$row['experience'].'</a></li>';
echo '<li>Training: <a>'.$row['training'].'</a></li>';
echo '<li>Eligibility: <a>'.$row['eligibility'].'</a></li>';
	}
?>
