<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$ok = $_GET['idea'];
$mode = $_GET['mode'];
	if($mode == 'title'){
	$statement = $dbhsub -> prepare("SELECT title FROM mainnews WHERE newsid = :ok");
	$statement->bindParam(':ok', $ok);
	$statement -> execute();
	while($row = $statement ->fetch(PDO::FETCH_ASSOC)){

	echo '
	<textarea id = "contentforedit">'.$row['title'].'</textarea>
	<button class = "btnSuccess" onclick="deletemain('.$ok.')">Delete</button>
	<button class = "btnSuccess" onclick="editmain('.$ok.')">Edit</button>
	<button class = "btnSuccess" onclick="canceledit()">Cancel</button>';
	}

	}
	else{
	$statement = $dbhsub -> prepare("SELECT prioritycode, description, type FROM newsextension WHERE newscontentid = :ok");
	$statement->bindParam(':ok', $ok);
	$statement -> execute();
	while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
	if($row['type']=='none'){		
	echo '<img class = "imgvlgs" id="frontimagedesign" src="../images/newsimages/'.$ok.'.png" alt="image test" style = "
 	float: left;
  	background-repeat: no-repeat;
  	background-size: 100% 100%;
  	background-color: rgba(200,200,200, 0);
  	margin-top: 0%;
  	margin-bottom: 0;
  	margin-left: 0%;
  	width: 75%
           " />
          <div class = "col-xs-12">
    PriorityCode<input type = "text" id = "editimagepriority2" value = "'.$row['prioritycode'].'"></div>          <div class = "col-xs-12">
    <button class = "btnSuccess" onclick="deletesub('.$ok.')">Delete</button>
	<button class = "btnSuccess" onclick="editsubpic('.$ok.')">Edit</button>
	<button class = "btnSuccess" onclick="canceledit()">Cancel</button></div>
           ';
	}else{
	echo'
    PriorityCode<input type = "text" id = "editimagepriority" value = "'.$row['prioritycode'].'">
	<textarea id = "contentforedit">'.$row['description'].'</textarea>
	<button class = "btnSuccess" onclick="deletesub('.$ok.')">Delete</button>
	<button class = "btnSuccess" onclick="editsub('.$ok.')">Edit</button>
	<button class = "btnSuccess" onclick="canceledit()">Cancel</button>';
	}
	}
	}
?>