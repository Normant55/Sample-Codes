<div class = "col-xs-12">
<h4>Existing Posts:<select id = "selectortitlecover" onchange = "selectnewstitle()">
</h4></div>
	<option value = 'none'>Select Title</option>
<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
$determine = $_GET['determine'];
$count = 0;
if($determine == 'maintitle'){
	$search = $dbhsub ->query("SELECT imageid, imagetitle FROM covertitleimage ORDER BY imageid DESC");
	while($row = $search -> fetch(PDO:: FETCH_ASSOC)){
   if(strlen($row['imagetitle'])>25){
   $finaltitle = substr($row['imagetitle'], 0, 25).'...';}
   else{
   $finaltitle = $row['imagetitle'];
   }
	echo '<option value = '.$row['imageid'].' ';if($count == 0){echo 'selected'; $count++;} echo'>'.$finaltitle.'</option>';
}}else{
if(isset($_GET['currency'])){
	$currency = $_GET['currency'];
	$search = $dbhsub ->query("SELECT imageid, imagetitle FROM covertitleimage");
	while($row = $search -> fetch(PDO:: FETCH_ASSOC)){
   if(strlen($row['imagetitle'])>25){
   $finaltitle = substr($row['imagetitle'], 0, 25).'...';}
   else{
   $finaltitle = $row['imagetitle'];
   }
	echo '<option value = '.$row['imageid'].' ';if($currency == $row['imageid']){echo 'selected';} echo'>'.$finaltitle.'</option>';
}
}else{
$search = $dbhsub ->query("SELECT imageid, imagetitle FROM covertitleimage");
while($row = $search -> fetch(PDO:: FETCH_ASSOC)){
   if(strlen($row['imagetitle'])>25){
   $finaltitle = substr($row['imagetitle'], 0, 25).'...';}
   else{
   $finaltitle = $row['imagetitle'];
   }
	echo '<option value = '.$row['imageid'].'>'.$finaltitle.'</option>';
}}}
?>
</select>