<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
    $statement = $dbhsub -> query("SELECT * FROM mainnews ORDER BY dateuploaded DESC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
      echo $row['newsid'].', ';
  }
?>