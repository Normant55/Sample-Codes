<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$depvalue = $_GET['depvalue'];
echo '<h2>'.$depvalue.'</h2>';
echo '<h4 onclick = "rredisplayjobdep()">Back</h4>';

$depvalue = str_replace('`', '\'\'', $depvalue);

$query = $dbh -> query("SELECT Count(Distinct[position]) FROM recruitment WHERE department = '$depvalue'");
$amount = $query -> fetchColumn();
echo '<div class="tab">';
$counter = $amount/12;
$starting = 1;
while($starting<=$counter+1){
echo ' <button class="tablinks" onclick="openCity(event, \'rainz'.$starting.'\')">'.$starting.'</button>';
$starting++;
}
echo '</div>';

if($amount == 0){
	echo '<h1>None Available</h1>';
}

$counterlimit = 1;
$bash = 1;
$query = $dbh -> query("SELECT Distinct[position], [item_code] FROM recruitment  WHERE department = '$depvalue'");
while($row = $query -> fetch(PDO::FETCH_ASSOC)){

	if($counterlimit==13){
		$counterlimit = 1;
			echo '</div>';
	}

	if($counterlimit == 1){
		echo '<div id="rainz'.$bash.'" class="tabcontent">';
		$bash++;
	}

echo '<li><a href = "subpages/jobapplicant" onmouseover="rjobprofiling(\''.$row['item_code'].'\')" onmouseout="rjobprofilingout()">'.$row['position'].'</a></li>';



	$counterlimit ++;



}
echo '</div>';






?>
<!-- Tab content -->