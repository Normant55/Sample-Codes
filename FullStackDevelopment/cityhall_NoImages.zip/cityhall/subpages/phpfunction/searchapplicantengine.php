<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');

$searchvalue = $_GET['searchvalue'];
echo '<ul>';
$stmt = $dbh -> query("SELECT * FROM Applicants WHERE lastname LIKE '%$searchvalue%' OR firstname LIKE '%$searchvalue%' OR middle LIKE '%$searchvalue%' ORDER BY lastname ASC");
while($row = $stmt -> fetch(PDO::FETCH_ASSOC)){
	echo '<li><a onmouseover="gozaimasen('.$row['employeeid'].')" onmouseout="saiyonara()">'.$row['fullname'].'</a></li>';
}
echo '</ul>';


?>