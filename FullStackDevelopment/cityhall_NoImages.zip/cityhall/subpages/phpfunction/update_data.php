<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
include("../../php/QueryEngine.php");
$itemhandle = new Query();
// $data_word = $_POST['database'];
// eval("\$itemhandle->db = \"$data_word\";");
$itemhandle->db = $dbh;
if($_POST['database']=='dbhsub'){
$itemhandle->db = $dbhsub;    
}elseif($_POST['database']=='dbh_leave'){
$itemhandle->db = $dbh_leave;       
}
$itemhandle->table = $_POST['table'];
if(isset($_POST['condition'])){
$itemhandle->condition = $_POST['condition'];
}
if(isset($_POST['condition_targets'])){
$itemhandle->condition_targets = $_POST['condition_targets'];
}
if(isset($_POST['operation_columns'])){
$itemhandle->operation_columns = $_POST['operation_columns'];
}
if(isset($_POST['operation_targets'])){
$itemhandle->operation_targets = $_POST['operation_targets'];
}
if(isset($_POST['preset_targets'])){
$itemhandle->preset_targets = $_POST['preset_targets'];
}
if(isset($_POST['preset_columns'])){
$itemhandle->preset_columns = $_POST['preset_columns'];
}
if(isset($_POST['message'])){
$itemhandle->message = $_POST['message'];
}
$user_delete = "no";
    if($_POST['crud']=='UPDATE')
    {
        $itemhandle->crud = "UPDATE";
        $itemhandle->message = $_POST['message'];
        $itemhandle_run = "yes";
    }
    if($_POST['crud']=='INSERT')
    {
        $itemhandle->crud = "INSERT";
        $itemhandle_run = "yes";
    }
    if($_POST['crud']=='DELETE')
    {   
        $itemhandle->crud = "DELETE";    
        $itemhandle_run = "yes";    
    }
    if($user_delete=="yes")
    {
        $suffix = '';
        $operation_columns = 'username';
        $condition= "account_no = :account_no";
        $delete_username = '';
        $delete_object = Query::selectallby($dbh, $operation_columns, $condition, $suffix, $_SESSION['table_id'], 'staff_information');
        foreach($delete_object as $username_found)
        {
            $delete_username = $username_found->username;
        }
        $itemhandle->table = "staff_login";
        $itemhandle->condition = "username = :username";
        $itemhandle->condition_targets = $delete_username;
        $forquery = $itemhandle->run();
        $itemhandle->table = "staff_information";
        $itemhandle->condition = "account_no = :account_no";
        $itemhandle->condition_targets = $_SESSION['table_id']; 
    }
    if($itemhandle_run=="yes"){
        $forquery = $itemhandle->run();
        // $confirmhandle->title = "Update";
        // $confirmhandle->message = $forquery;
        // $confirmhandle->button_class = "btn-success";
        // $confirmhandle->confirmonly();
    }
    echo $forquery;
?>