<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
echo '<img id="frontimagedesign" class = "img-responsive" src="../images/cityhall.jpg" alt="image test" style = "
  float: left;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  margin-top: 0%;
  margin-bottom: 0;
  width: 70%;
  margin-left: 0%;
           " />';

?>