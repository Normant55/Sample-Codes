<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");

echo '<div>';
if(isset($_GET['startmonthtoolkit']) AND !empty($_GET['startmonthtoolkit'])){
$startmonth =  $_GET['startmonthtoolkit'];
$startday =  $_GET['startdaytoolkit'];
$startyear =  $_GET['startyeartoolkit'];
$endmonth =  $_GET['endmonthtoolkit'];
$endday =  $_GET['enddaytoolkit'];
$endyear =  $_GET['endyeartoolkit'];
}
echo '<div class = "col-xs-12"><div class = "datesectorover" style = "margin-bottom:20px;">';
echo '<div class = "datesector">';
echo '<div class = "markword col-xs-12 col-md-2 col-lg-2">Starting Date</div>';

echo '<div class = "markwordd">Month</div> <select id = "startmonth" onchange = "datepick()">
<option value = 1 ';if($startmonth == 1){echo'selected';}echo'>January</option>
<option value = 2 ';if($startmonth == 2){echo'selected';}echo'>Febuary</option>
<option value = 3 ';if($startmonth == 3){echo'selected';}echo'>March</option>
<option value = 4 ';if($startmonth == 4){echo'selected';}echo'>April</option>
<option value = 5 ';if($startmonth == 5){echo'selected';}echo'>May</option>
<option value = 6 ';if($startmonth == 6){echo'selected';}echo'>June</option>
<option value = 7 ';if($startmonth == 7){echo'selected';}echo'>July</option>
<option value = 8 ';if($startmonth == 8){echo'selected';}echo'>August</option>
<option value = 9 ';if($startmonth == 9){echo'selected';}echo'>September</option>
<option value = 10 ';if($startmonth == 10){echo'selected';}echo'>October</option>
<option value = 11 ';if($startmonth == 11){echo'selected';}echo'>November</option>
<option value = 12 ';if($startmonth == 12){echo'selected';}echo'>December</option>
</select>';
echo '<div class = "markwordd">Day</div> <select id ="startday" onchange = "datepick()">';
for($x=1; $x<=31; $x++){
	echo '<option value = '.$x.' ';if($startday == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markwordd">Year</div> <select id ="startyear" onchange = "datepick()">';
for($x=1990; $x<=2030; $x++){
	echo '<option value = '.$x.' ';if($startyear == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';

echo '<div class = "markword col-xs-12 col-md-1 col-lg-1"> ----- </div>';

echo '<div class = "markwordd">Month</div> <select id = "endmonth" onchange = "datepick()">
<option value = 1 ';if($endmonth == 1){echo'selected';}echo'>January</option>
<option value = 2 ';if($endmonth == 2){echo'selected';}echo'>Febuary</option>
<option value = 3 ';if($endmonth == 3){echo'selected';}echo'>March</option>
<option value = 4 ';if($endmonth == 4){echo'selected';}echo'>April</option>
<option value = 5 ';if($endmonth == 5){echo'selected';}echo'>May</option>
<option value = 6 ';if($endmonth == 6){echo'selected';}echo'>June</option>
<option value = 7 ';if($endmonth == 7){echo'selected';}echo'>July</option>
<option value = 8 ';if($endmonth == 8){echo'selected';}echo'>August</option>
<option value = 9 ';if($endmonth == 9){echo'selected';}echo'>September</option>
<option value = 10 ';if($endmonth == 10){echo'selected';}echo'>October</option>
<option value = 11 ';if($endmonth == 11){echo'selected';}echo'>November</option>
<option value = 12 ';if($endmonth == 12){echo'selected';}echo'>December</option>
</select>';
echo '<div class = "markwordd">Day</div> <select id ="endday" onchange = "datepick()">';
for($x=1; $x<=31; $x++){
	echo '<option value = '.$x.' ';if($endday == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markwordd">Year</div> <select id ="endyear" onchange = "datepick()">';
for($x=1990; $x<=2030; $x++){
	echo '<option value = '.$x.' ';if($endyear == $x){echo'selected';}echo'>'.$x.'</option>';
}
$newstitlesearch = $_GET['newstitlesearch'];

echo '</select>';
echo '</div></div>';
echo '<div class = "col-md-2">';
if(isset($newstitlesearch) AND ($newstitlesearch!="")){
$newstitlesearch = $_GET['newstitlesearch'];
}else{
$newstitlesearch = "";}
$statement = $dbhsub -> prepare("SELECT newsid, title, CONVERT(VARCHAR(10),dateuploaded, 101) AS dateuploaded, publisher FROM mainnews WHERE title LIKE '%$newstitlesearch%' AND dateuploaded between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' ORDER BY dateuploaded DESC");
$statement ->execute();
while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
echo '<div id = "newsselector'.$row['newsid'].'" style = "margin-bottom: 0%; border-bottom: solid 1px rgba(225,225,225, 1); cursor:pointer;" onclick = "sumondong('.$row['newsid'].')"><a class = "exit_edge_pure" style = "text-decoration:none;">'.$row['dateuploaded'].'<div>'.$row['title'].'</div></a></div>';
}
echo '</div>';


echo '<div class = "col-md-10" id = "thedragon">';
echo '</div>';

echo '</div>';
?>