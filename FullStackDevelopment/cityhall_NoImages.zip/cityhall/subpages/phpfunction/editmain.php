<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$ok = $_POST['idea'];
$entry = $_POST['entry'];
$editimagepriority = $_POST['editimagepriority'];
$usertype = $_POST['usertype'];
$userprof = $_POST['userprof'];
$editimagepriority = strip_tags($editimagepriority);
$entry = str_replace("e1p1", "<", $entry);
$entry = str_replace("e1p2", ">", $entry);
$entry = str_replace("e1p3", "\"", $entry);
$entry = str_replace("e1p4", "#", $entry);
$entry = str_replace("e1p5", "(", $entry);
$entry = str_replace("e1p6", ")", $entry);
$entry = str_replace("e1p7", "-", $entry);
$entry = str_replace("e1p8", ":", $entry);
$entry = str_replace("e1p9", "&", $entry);
$entry = str_replace("<head>", " ", $entry);
$entry = str_replace("<body>", " ", $entry);
$mode = $_POST['mode'];
	if($mode == 'title'){
	$statement = $dbhsub -> prepare("UPDATE mainnews SET title = :entry WHERE newsid = :ok");
	$statement->bindParam(':entry', $entry);	
	$statement->bindParam(':ok', $ok);
	$statement -> execute();
	echo 'Successfully changed to '.$entry.'!';


$filestatement = $dbhsub -> query("SELECT title, status FROM mainnews WHERE newsid = '$ok'");
	while($filerow = $filestatement ->fetch(PDO::FETCH_ASSOC)){
		$title = $filerow['title'];
		$status = $filerow['status'];
	}
$titleformeta = strip_tags($title);
if($usertype == 'admin'){
$myfile = fopen("../newsarchivethumbs/newsfile".$ok.".html", "w");
$oldfile = "
<!DOCTYPE HTML>
<html lang = \"en\">
<meta charset = \"utf-8\">
<meta property=\"og:description\" content=\"end description\" />
<meta property=\"og:title\" content=\"".$titleformeta."\" />
<script type = \"text/javascript\">
        function viewthisnews(){
        window.localStorage.setItem(\"newsdefault\", ".$ok.");
        window.location.href = \"../newsarchive\";
        }
        window.onload = viewthisnews;
</script>
".$title."
";}else{


if($status == 'approved' OR $status == 'pending'){
$myfile = fopen("../newsarchivethumbs/newsfile".$ok.".html", "w");
$oldfile = "
<!DOCTYPE HTML>
<html lang = \"en\">
<meta charset = \"utf-8\">
<meta property=\"og:description\" content=\"end description\" />
<meta property=\"og:title\" content=\"".$titleformeta."\" />
<script type = \"text/javascript\">
        function viewthisnews(){
        window.localStorage.setItem(\"newsdefault\", ".$ok.");
        window.location.href = \"personalarchive\";
        }
        window.onload = viewthisnews;
</script>
".$title."
";
}elseif($status=='covered'){
$myfile = fopen("../newsarchivethumbs/newsfile".$ok.".html", "w");
$oldfile = "
<!DOCTYPE HTML>
<html lang = \"en\">
<meta charset = \"utf-8\">
<meta property=\"og:description\" content=\"end description\" />
<meta property=\"og:title\" content=\"".$titleformeta."\" />
<script type = \"text/javascript\">
        function viewthisnews(){
        window.localStorage.setItem(\"newsdefault\", ".$ok.");
        window.location.href = \"../newsarchive\";
        }
        window.onload = viewthisnews;
</script>
".$title."
";
}else{
}	

}

$statement2 = $dbhsub -> query("SELECT newscontentid, type, description FROM newsextension WHERE newsid = '$ok'");
while($row2 = $statement2 ->fetch(PDO::FETCH_ASSOC)){
	$newscontentid = $row2['newscontentid'];
	$description = $row2['description'];
	if($row2['type']=='none'){


		$oldfile = str_replace("<html lang = \"en\">", " <html lang = \"en\"> <meta property=\"og:image\" content=\"http://79.125.201.223:8080/cityhall/images/newsimages/".$newscontentid.".png\" />", $oldfile);


	}else{

		$description = strip_tags($description);
		$oldfile = str_replace("<meta property=\"og:description\" content=\"", "<meta property=\"og:description\" content=\"".$description." ", $oldfile);
		$oldfile = str_replace("</script>", "</script> ".$description, $oldfile);

	}
}
		fwrite($myfile, $oldfile);
		fclose($myfile);
//$mode
	}else{
	$statement = $dbhsub -> prepare("UPDATE newsextension SET description = :entry, prioritycode = :editimagepriority WHERE newscontentid = :ok");
	$statement->bindParam(':entry', $entry);
	$statement->bindParam(':ok', $ok);
	$statement->bindParam(':editimagepriority', $editimagepriority);
	$statement -> execute();
	if($entry == 'none'){
	echo 'Successfully priority!';		
	}else{
	echo 'Successfully changed to '.$entry.'!';
	}

$statement = $dbhsub -> query("SELECT newsid FROM newsextension WHERE newscontentid = '$ok'");
while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
	$newsid = $row['newsid'];

$filestatement = $dbhsub -> query("SELECT title,status FROM mainnews WHERE newsid = '$newsid'");
	while($filerow = $filestatement ->fetch(PDO::FETCH_ASSOC)){
		$title = $filerow['title'];
		$status = $filerow['status'];
	}
$titleformeta = strip_tags($title);
if($usertype == 'admin'){
$myfile = fopen("../newsarchivethumbs/newsfile".$newsid.".html", "w");
$oldfile = "
<!DOCTYPE HTML>
<html lang = \"en\">
<meta charset = \"utf-8\">
<meta property=\"og:description\" content=\"end description\" />
<meta property=\"og:title\" content=\"".$titleformeta."\" />
<script type = \"text/javascript\">
        function viewthisnews(){
        window.localStorage.setItem(\"newsdefault\", ".$newsid.");
        window.location.href = \"../newsarchive\";
        }
        window.onload = viewthisnews;
</script>
".$title."
";}else{


if($status == 'approved' OR $status == 'pending'){
$myfile = fopen("../newsarchivethumbs/newsfile".$newsid.".html", "w");
$oldfile = "
<!DOCTYPE HTML>
<html lang = \"en\">
<meta charset = \"utf-8\">
<meta property=\"og:description\" content=\"end description\" />
<meta property=\"og:title\" content=\"".$titleformeta."\" />
<script type = \"text/javascript\">
        function viewthisnews(){
        window.localStorage.setItem(\"newsdefault\", ".$newsid.");
        window.location.href = \"../personalarchive\";
        }
        window.onload = viewthisnews;
</script>
".$title."
";
}elseif($status=='covered'){
$myfile = fopen("../newsarchivethumbs/newsfile".$newsid.".html", "w");
$oldfile = "
<!DOCTYPE HTML>
<html lang = \"en\">
<meta charset = \"utf-8\">
<meta property=\"og:description\" content=\"end description\" />
<meta property=\"og:title\" content=\"".$titleformeta."\" />
<script type = \"text/javascript\">
        function viewthisnews(){
        window.localStorage.setItem(\"newsdefault\", ".$newsid.");
        window.location.href = \../newsarchive\";
        }
        window.onload = viewthisnews;
</script>
".$title."
";
}else{
}	

}

$statement2 = $dbhsub -> query("SELECT newscontentid, type, description FROM newsextension WHERE newsid = '$newsid'");
while($row2 = $statement2 ->fetch(PDO::FETCH_ASSOC)){
	$newscontentid = $row2['newscontentid'];
	$description = $row2['description'];
	if($row2['type']=='none'){


		$oldfile = str_replace("<html lang = \"en\">", " <html lang = \"en\"> <meta property=\"og:image\" content=\"../images/newsimages/".$newscontentid.".png\" />", $oldfile);


	}else{

		$description = strip_tags($description);
		$oldfile = str_replace("<meta property=\"og:description\" content=\"", "<meta property=\"og:description\" content=\"".$description." ", $oldfile);
		$oldfile = str_replace("</script>", "</script> ".$description, $oldfile);

	}
}
		fwrite($myfile, $oldfile);
		fclose($myfile);
}


	}



?>