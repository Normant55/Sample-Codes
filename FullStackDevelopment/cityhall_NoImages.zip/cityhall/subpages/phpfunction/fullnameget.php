<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");

$sjaeland = $_GET['theidea'];

$mak = $dbh -> prepare("SELECT firstname, middle, lastname FROM Applicants WHERE employeeid = :sjae");
$mak->bindParam(":sjae", $sjaeland, PDO::PARAM_INT);
$mak->execute();
while($row = $mak -> fetch(PDO::FETCH_ASSOC)){
	echo $row['lastname'].', '.$row['firstname'].' '.$row['middle'];
}

?>