<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../../php/connectPDO.php");
$theid = $_GET['theid'];
$startmonth =  $_GET['startmonthtoolkit'];
$startday =  $_GET['startdaytoolkit'];
$startyear =  $_GET['startyeartoolkit'];
$endmonth =  $_GET['endmonthtoolkit'];
$endday =  $_GET['enddaytoolkit'];
$endyear =  $_GET['endyeartoolkit'];

$statement = $dbh_leave -> prepare("SELECT LEAV_REQNO, EMP_ID, LEAV_STAT_TEXT, A.LEAV_STAT_ID, VL_FLG, SL_FLG, COM_FLG, CONVERT(VARCHAR(10),LEAV_REQDT, 101) AS LEAV_REQDT FROM [LGU_DEV].[hr].[LEAV_REQ_HEADER] AS A INNER JOIN [LGU_DEV].[hr].[LEAV_STATUS] AS B on A.LEAV_STAT_ID = B.LEAV_STAT_ID WHERE LEAV_REQDT between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' AND EMP_ID = '$theid' ORDER BY LEAV_REQDT DESC");
$statement -> execute();
	echo '<div class = "no_lining">
  <a onclick = "reto(\'default\')" style = "cursor:pointer;">
  <img class = "img-responsive" src="images/return_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  "/>
  Exit</a></div>';
  echo '
  <div class = "col-md-12" style = "margin-top: 0%;">
  <h3>Search Leave</h3>';

echo '<div class = "col-xs-12"><div class = "datesectorover" style = "margin-bottom:20px;">';
echo '<div class = "datesector">';
echo '<div class = "markword col-xs-12 col-md-2 col-lg-2">Starting Date</div>';
echo '<div class = "markwordd">Month</div> <select id = "startmonth" onchange = "searchengine_leave()">
<option value = 1 ';if($startmonth == 1){echo'selected';}echo'>January</option>
<option value = 2 ';if($startmonth == 2){echo'selected';}echo'>Febuary</option>
<option value = 3 ';if($startmonth == 3){echo'selected';}echo'>March</option>
<option value = 4 ';if($startmonth == 4){echo'selected';}echo'>April</option>
<option value = 5 ';if($startmonth == 5){echo'selected';}echo'>May</option>
<option value = 6 ';if($startmonth == 6){echo'selected';}echo'>June</option>
<option value = 7 ';if($startmonth == 7){echo'selected';}echo'>July</option>
<option value = 8 ';if($startmonth == 8){echo'selected';}echo'>August</option>
<option value = 9 ';if($startmonth == 9){echo'selected';}echo'>September</option>
<option value = 10 ';if($startmonth == 10){echo'selected';}echo'>October</option>
<option value = 11 ';if($startmonth == 11){echo'selected';}echo'>November</option>
<option value = 12 ';if($startmonth == 12){echo'selected';}echo'>December</option>
</select>';
echo '<div class = "markwordd">Day</div> <select id ="startday" onchange = "searchengine_leave()">';
for($x=1; $x<=31; $x++){
  echo '<option value = '.$x.' ';if($startday == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markwordd">Year</div> <select id ="startyear" onchange = "searchengine_leave()">';
for($x=1990; $x<=2030; $x++){
  echo '<option value = '.$x.' ';if($startyear == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markword col-xs-12 col-md-1 col-lg-1"> ----- </div>';
echo '<div class = "markwordd">Month</div> <select id = "endmonth" onchange = "searchengine_leave()">
<option value = 1 ';if($endmonth == 1){echo'selected';}echo'>January</option>
<option value = 2 ';if($endmonth == 2){echo'selected';}echo'>Febuary</option>
<option value = 3 ';if($endmonth == 3){echo'selected';}echo'>March</option>
<option value = 4 ';if($endmonth == 4){echo'selected';}echo'>April</option>
<option value = 5 ';if($endmonth == 5){echo'selected';}echo'>May</option>
<option value = 6 ';if($endmonth == 6){echo'selected';}echo'>June</option>
<option value = 7 ';if($endmonth == 7){echo'selected';}echo'>July</option>
<option value = 8 ';if($endmonth == 8){echo'selected';}echo'>August</option>
<option value = 9 ';if($endmonth == 9){echo'selected';}echo'>September</option>
<option value = 10 ';if($endmonth == 10){echo'selected';}echo'>October</option>
<option value = 11 ';if($endmonth == 11){echo'selected';}echo'>November</option>
<option value = 12 ';if($endmonth == 12){echo'selected';}echo'>December</option>
</select>';
echo '<div class = "markwordd">Day</div> <select id ="endday" onchange = "searchengine_leave()">';
for($x=1; $x<=31; $x++){
  echo '<option value = '.$x.' ';if($endday == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markwordd">Year</div> <select id ="endyear" onchange = "searchengine_leave()">';
for($x=1990; $x<=2030; $x++){
  echo '<option value = '.$x.' ';if($endyear == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '</div></div>';

  echo'<div class = "col-md-12 standard_margin">
  <div class = "col-md-12">
  <div class = "word_button_sky" style = "cursor: pointer; display: inline-flex; line-height: 30px;"
  href="#demo_leave" data-toggle="collapse">
  <img class = "img-responsive" src="images/email.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />Leave Options</div>

  <div class = "word_button_sky" style = "cursor: pointer; display: inline-flex; line-height: 30px;" onclick = "selectall()">
  <img class = "img-responsive" src="images/logo_add.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />Select All</div>

  <div class = "word_button_sky" style = "cursor: pointer; display: inline-flex; line-height: 30px;" onclick = "deleteselected_leave()">
  <img class = "img-responsive" src="images/delete.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />Delete</div>

  </div>
  <div class = "col-md-12 collapse" id="demo_leave">
  <div class = "col-md-12 type_leave_forms" style = "word-wrap: break-word;"></div>
  <div class = "col-md-12 type_leave" style = "word-wrap: break-word;"></div>
  </div>
  </div>
  </div>

  <div class = "col-md-1 passerbiga"></div>
  <div class = "col-md-11">
  <div class = "col-md-2 passerbiga">Leave ID</div>
  <div class = "col-md-6 passerbiga">Status</div>
  <div class = "col-md-4 passerbiga">Date Created</div> 
  </div>
  <div class = "col-xs-12" id = "leavelist_box">
  ';
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
  echo '<div class = "col-md-12">';
	echo '<div onmouseover = "leave_color('.$row['LEAV_REQNO'].')" onmouseout = "leave_uncolor('.$row['LEAV_REQNO'].')" style = "cursor:pointer;">
  ';
  echo '<div class = "col-md-1 passerbigs"><input type="checkbox" id = "leave_mycheck'.$row['LEAV_REQNO'].'" onclick="leave_checkbox('.$row['LEAV_REQNO'].')"></div>';
  echo '<div class = "col-md-11" href="#demo'.$row['LEAV_REQNO'].'" data-toggle="collapse">
  ';
	echo '<div class = "col-md-2 passerbigs font_eye_catch font_eye_fast" id = "lrn'.$row['LEAV_REQNO'].'">'.$row['LEAV_REQNO'].'</div>';
	echo '<div class = "col-md-6 passerbigs font_eye_catch font_eye_fast" id = "lsi'.$row['LEAV_REQNO'].'">'.$row['LEAV_STAT_TEXT'].'</div>';
	echo '<div class = "col-md-4 passerbigs font_eye_catch font_eye_fast" id = "lrd'.$row['LEAV_REQNO'].'">'.$row['LEAV_REQDT'].'</div>';
	echo '</div>';
	echo '
  </div>
  <div class = "col-md-12 collapse standard_margin_side standard_margin standard_border_side standard_border_horizontal standard_background_lightgrey" id="demo'.$row['LEAV_REQNO'].'">';
  echo '<div class = "col-md-12"><h3>Leave Items</h3></div>';

$statement_sub = $dbh_leave -> prepare("SELECT ROW_ID, B.LEAV_TYPE_TEXT, A.LEAV_ACCNO, CONVERT(VARCHAR(10),DATE_FROM, 101) AS DATE_FROM, CONVERT(VARCHAR(10),DATE_TO, 101) AS DATE_TO, LEAV_STAT_TEXT, DAYS_APPVD, DAYS_APPLD, [REMARKS], [HALF_D_AM], [HALF_D_PM] FROM [LGU_DEV].[hr].[LEAV_REQ_ITEMS] AS A INNER JOIN [LGU_DEV].[hr].[LEAV_TYPES] AS B on A.LEAV_TYPE_ID = B.LEAV_TYPE_ID INNER JOIN [LGU_DEV].[hr].[LEAV_STATUS] AS C on A.LEAV_STAT_ID = C.LEAV_STAT_ID WHERE LEAV_REQNO = ".$row['LEAV_REQNO']);
$statement_sub -> execute();
while($row_sub = $statement_sub -> fetch(PDO::FETCH_ASSOC)){
  echo ' <div class = "col-md-12 passerbigs passerbigs_darker" onmouseover = "leave_color_sub('.$row_sub['ROW_ID'].')" onmouseout = "leave_uncolor_sub('.$row_sub['ROW_ID'].')" style = "cursor:pointer;">';
  echo '<div class = "col-md-1" id = "sr_ri'.$row_sub['ROW_ID'].'">
<input type="checkbox" id = "leave_sub_mycheck'.$row_sub['ROW_ID'].'" onclick="leave_sub_checkbox('.$row_sub['ROW_ID'].')">
  '.$row_sub['ROW_ID'].'</div>';
  echo '<div class = "col-md-5" id = "sr_ltt'.$row_sub['ROW_ID'].'">'.$row_sub['LEAV_TYPE_TEXT'].'</div>';
  echo '<div class = "col-md-2" id = "sr_la'.$row_sub['ROW_ID'].'">Account NO.'.$row_sub['LEAV_ACCNO'].'</div>';
  echo '<div class = "col-md-2" id = "sr_df'.$row_sub['ROW_ID'].'">'.$row_sub['DATE_FROM'].'</div>';
  echo '<div class = "col-md-2" id = "sr_dt'.$row_sub['ROW_ID'].'">'.$row_sub['DATE_TO'].'</div>';
  echo '<div class = "col-md-2" id = "sr_lst'.$row_sub['ROW_ID'].'">'.$row_sub['LEAV_STAT_TEXT'].'</div>';
  $day_length = 'Whole Day';
  if($row_sub['HALF_D_AM']==1){
  $day_length = 'Half Day AM';
  }else if($row_sub['HALF_D_PM']==1){
  $day_length = 'Half Day PM';   
  }
  echo '<div class = "col-md-4" id = "sr_hda'.$row_sub['ROW_ID'].'">'.$day_length.'</div>';
  echo '<div class = "col-md-2" id = "sr_r'.$row_sub['ROW_ID'].'">'.$row_sub['REMARKS'].'</div>';
  echo '<div class = "col-md-2" id = "sr_dal'.$row_sub['ROW_ID'].'">'.$row_sub['DAYS_APPLD'].'</div>';
  echo '<div class = "col-md-2" id = "sr_dav'.$row_sub['ROW_ID'].'">'.$row_sub['DAYS_APPVD'].'</div>';
  echo '</div>';
}

  echo '
  <div class = "col-md-12" style = "word-wrap: break-word;"><h3>Date Created:</h3></div>
  <div class = "col-md-12 message_default" style = "word-wrap: break-word;">'.$row['LEAV_REQDT'].'</div>
  <div class = "col-md-12">
  <a class = "word_button_sky" style = "cursor: pointer; text-decoration:none;" onclick = "delete_leave('.$row['LEAV_REQNO'].')">
  Delete</a>
  </div>
  </div>
  </div>
  ';
}
  echo '</div>';
  // echo '
  // <a class = "word_button_sky" style = "cursor:pointer; text-decoration: none;" onclick = "crud_function_preset(\'\',\'\',\'LEAV_REQNO*-, LEAV_REQDT\',\'(SELECT MAX(LEAV_REQNO) + 1 AS Result FROM [LGU_DEV].[hr].[LEAV_REQ_HEADER])*-, GETDATE()\',\'[LGU_DEV].[hr].[LEAV_REQ_HEADER]\', \'EMP_ID*-, LEAV_STAT_ID*-, VL_FLG*-, SL_FLG*-, COM_FLG\', \''.$theid.'*-, 5*-, 0*-, 0*-, 0 \', \'INSERT\', \'Successfully Added!\', \'dbh_leave\')">
  // <img class = "img-responsive" src="images/target_logo.png" alt="image test" 
  // style = "
  // position: relative;
  // background-repeat: no-repeat;
  // background-size: 100% 100%;
  // background-position: 20% 50%;
  // background-color: rgba(200,200,200, 0);
  // height: 30px;
  // display: inline-block;
  // " />
  // Add Header</a>
  // ';
?>