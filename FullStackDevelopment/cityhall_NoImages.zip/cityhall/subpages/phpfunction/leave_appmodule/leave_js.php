  <?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
header('Content-Type: application/javascript');
?>
                function searchengine_leave(){
                  searchkeyword = '';
                  theid = window.localStorage.getItem("loginid");
                  startmonthtoolkit = document.getElementById("startmonth").value;
                  startdaytoolkit = document.getElementById("startday").value;
                  startyeartoolkit = document.getElementById("startyear").value;
                  endmonthtoolkit = document.getElementById("endmonth").value;
                  enddaytoolkit = document.getElementById("endday").value;
                  endyeartoolkit = document.getElementById("endyear").value;

                  if(searchkeyword != ''){
                    var xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function(){
                      if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("leavelist_box").innerHTML = this.responseText;
                        function return_typeleave(data){
                          button_html = '<a class = "word_button_sky" style = "cursor:pointer; text-decoration: none;" onclick = "multi_tick()"><img class = "img-responsive" src="images/subtarget_logo.png" alt="image test" style = "position: relative;background-repeat: no-repeat; background-size: 100% 100%;background-position: 20% 50%;background-color: rgba(200,200,200, 0);height: 30px;display: inline-block;"/>Add Item</a>';
                          $('.type_leave_forms').html(button_html);
                          write_html = '';
                          // write_html = 'Header ID: <div class = "id_leave" style = "display: inline-flex;"></div>';
                          // function return_header_ids(data){
                          //   write_select_html = select_maker(data, 'my_leave_id');
                          //   $('.id_leave').html(write_select_html);
                          // }
                          // search_query('LEAV_STAT_ID=:LEAV_STAT_ID', '[LGU_DEV].[hr].[LEAV_REQ_HEADER]', 'LEAV_REQNO*-, LEAV_REQNO', '5', '', 'select_allby', '', 'dbh_leave', return_header_ids);
                          write_html = write_html+'<div class = "col-xs-12">Leave Type: ';
                          write_html = write_html+select_maker(data, 'my_select')+'</div>';
                  write_html = write_html+'<div class = "col-md-2">Time: ';
                  write_html = write_html + '<select class = "input_standard" id = \'time_pick\'><option value = \'0\'>Whole Day</option><option value = \'1\'>Half AM</option><option value = \'2\'>Half PM</option></select>';
                  write_html = write_html+'</div><div class = "col-md-3">Date From: ';
                  write_html = write_html + '<input class = "input_standard" type = \'date\' id = \'date_from\'>';
                  write_html = write_html+'</div><div class = "col-md-3">Date To: ';
                  write_html = write_html + '<input class = "input_standard" type = \'date\' id = \'date_to\'></div>';
                          $('.type_leave').html(write_html);
                        }
                        search_query('', '[LGU_DEV].[hr].[LEAV_TYPES]', 'LEAV_TYPE_ID*-, LEAV_TYPE_TEXT', '', '', 'select_allby', '', 'dbh_leave', return_typeleave);
                      }
                    };
                    xmlhttp.open("GET", "subpages/phpfunction/leave_appmodule/searchengine.php?startmonthtoolkit="+startmonthtoolkit+"&startdaytoolkit="+startdaytoolkit+"&enddaytoolkit="+enddaytoolkit+"&endyeartoolkit="+endyeartoolkit+"&startyeartoolkit="+startyeartoolkit+"&endmonthtoolkit="+endmonthtoolkit+"&theid="+theid, true);
                    xmlhttp.send();
                  }else{
                    var xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function() {
                      if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("leave_application").innerHTML = this.responseText;
                        function return_typeleave(data){
                          button_html = '<a class = "word_button_sky" style = "cursor:pointer; text-decoration: none;" onclick = "multi_tick()"><img class = "img-responsive" src="images/subtarget_logo.png" alt="image test" style = "position: relative;background-repeat: no-repeat; background-size: 100% 100%;background-position: 20% 50%;background-color: rgba(200,200,200, 0);height: 30px;display: inline-block;"/>Add Item</a>';
                          $('.type_leave_forms').html(button_html);
                          write_html = '';
                          // write_html = 'Header ID: <div class = "id_leave" style = "display: inline-flex;"></div>';
                          // function return_header_ids(data){
                          //   write_select_html = select_maker(data, 'my_leave_id');
                          //   $('.id_leave').html(write_select_html);
                          // }
                          // search_query('LEAV_STAT_ID=:LEAV_STAT_ID', '[LGU_DEV].[hr].[LEAV_REQ_HEADER]', 'LEAV_REQNO*-, LEAV_REQNO', '5', '', 'select_allby', '', 'dbh_leave', return_header_ids);
                          write_html = write_html+'<div class = "col-md-4">Leave Type: ';
                          write_html = write_html+select_maker(data, 'my_select')+'</div>';
                  write_html = write_html+'<div class = "col-md-2">Time: ';
                  write_html = write_html + '<select class = "input_standard" id = \'time_pick\'><option value = \'0\'>Whole Day</option><option value = \'1\'>Half AM</option><option value = \'2\'>Half PM</option></select>';
                  write_html = write_html+'</div><div class = "col-md-3">Date From: ';
                  write_html = write_html + '<input class = "input_standard" type = \'date\' id = \'date_from\'>';
                  write_html = write_html+'</div><div class = "col-md-3">Date To: ';
                  write_html = write_html + '<input class = "input_standard" type = \'date\' id = \'date_to\'></div>';
                          $('.type_leave').html(write_html);
                        }
                        search_query('', '[LGU_DEV].[hr].[LEAV_TYPES]', 'LEAV_TYPE_ID*-, LEAV_TYPE_TEXT', '', '', 'select_allby', '', 'dbh_leave', return_typeleave);
                      }
                    };
                    xmlhttp.open("GET", "subpages/phpfunction/leave_appmodule/leave_list.php?startmonthtoolkit="+startmonthtoolkit+"&startdaytoolkit="+startdaytoolkit+"&enddaytoolkit="+enddaytoolkit+"&endyeartoolkit="+endyeartoolkit+"&startyeartoolkit="+startyeartoolkit+"&endmonthtoolkit="+endmonthtoolkit+"&theid="+theid, true);
                    xmlhttp.send();
                  }
                }

                function leave_color(highlight){
                  document.getElementById("lrn"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("lsi"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("lrd"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                }

                function leave_uncolor(highlight){
                  document.getElementById("lrn"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("lsi"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("lrd"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                }

                function leave_color_sub(highlight){
                  document.getElementById("sr_ri"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_ltt"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_la"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_df"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_dt"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_lst"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_dal"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_dav"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_hda"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  // document.getElementById("sr_hdp"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_r"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                }

                function leave_uncolor_sub(highlight){
                  document.getElementById("sr_ri"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_ltt"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_la"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_df"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_dt"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_lst"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_dal"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_dav"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_hda"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  // document.getElementById("sr_hdp"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_r"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                }

                function delete_leave(targetid){
                  if(confirm("Are you sure you want to delete the item?")){
                    var xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function(){
                      if(this.readyState == 4 && this.status == 200) {
                          alert(this.responseText);
                          searchengine_leave();
                      } 
                    };
                    xmlhttp.open("GET", "subpages/phpfunction/leave_appmodule/delete.php?deletevalue="+targetid, true);
                    xmlhttp.send();
                  }
                }

                function deleteselected_leave(){
                  if(confirm("Are you sure you want to delete the selected?")){
                    mashael_leave = window.localStorage.getItem("mashael_leave");
                    mashael_leave = mashael_leave.slice(0, -1);
                    var xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function(){
                      if(this.readyState == 4 && this.status == 200){
                        window.localStorage.setItem("mashael_leave", "");
                        deleteselected_leave_sub();
                      }
                    };
                    xmlhttp.open("GET", "subpages/phpfunction/leave_appmodule/deletebulk_sub.php?deletevalue="+mashael_leave, true);
                    xmlhttp.send();
                  }
                }

                function leave_checkbox(thisa){
                if(document.getElementById("leave_mycheck"+thisa).checked === true){
                  mashael_leave_sub = window.localStorage.getItem("mashael_leave_sub");
                  window.localStorage.setItem("mashael_leave_sub", mashael_leave_sub+thisa+",");
                  mashael_leave_sub = window.localStorage.getItem("mashael_leave_sub");
                }else{
                  mashael_leave_sub = window.localStorage.getItem("mashael_leave_sub");
                  tempshell_inbox = ","+mashael_leave_sub;
                  mashael_leave_sub = tempshell_inbox.replace(","+thisa+",", ",");
                  mashael_leave_sub = mashael_leave_sub.substr(1);
                  window.localStorage.setItem("mashael_leave_sub", mashael_leave_sub);
                }
                }

                function multi_tick(){
                    theid = window.localStorage.getItem("loginid");
                    time_pick = document.getElementById('time_pick').value;
                    date_from = document.getElementById('date_from').value;
                    date_to = document.getElementById('date_to').value;
                    date_text = ''+date_from;
                    if(date_from != date_to){
                    date_text = ''+date_from+' to '+date_to;
                    }
                    flag_text = 'w';
                    wholeday_flag = 0;
                    halfday_AM_flag = 0;
                    halfday_PM_flag = 0;
                    if(time_pick == 0){
                      wholeday_flag = 1;
                      flag_text = 'w';
                    }else if(time_pick == 1){
                      halfday_AM_flag = 1;
                      flag_text = 'AM';
                    }else if(time_pick == 2){
                      halfday_PM_flag = 1;
                      flag_text = 'PM';
                    }
                    overall_text = date_text+''+flag_text;

                  function return_countdata(data){
                    amount = data;
                    if(amount!=0){
                      function return_latest_id(data_id){
                        var data_id = data_id.substring(0, data_id.length - 2);
                        crud_function('','','[LGU_DEV].[hr].[LEAV_REQ_ITEMS]', 'LEAV_REQNO*-, LEAV_TYPE_ID*-, LEAV_ACCNO*-, DATE_FROM*-, DATE_TO*-, HALF_D_FLG*-, HALF_D_AM*-, HALF_D_PM*-, DAYS_APPLD*-, DAYS_APPVD*-, POSTED_FLG*-, REMARKS*-, LEAV_STAT_ID*-, BY_RANGE', data_id+'*-, '+document.getElementById('my_select').value+'*-, 10'+data_id+'*-, '+document.getElementById('date_from').value+'*-, '+document.getElementById('date_to').value+'*-, '+wholeday_flag+'*-, '+halfday_AM_flag+'*-, '+halfday_PM_flag+'*-, 0*-, 0*-, 0*-, '+overall_text+'*-, 5*-, 0', 'INSERT', 'Successfully Added Leave Data!', 'dbh_leave');
                      }
                      search_query('EMP_ID=:EMP_ID AND LEAV_STAT_ID = 5 AND CONVERT(VARCHAR(10),LEAV_REQDT,101)=CONVERT(VARCHAR(10),GETDATE(),101)', '[LGU_DEV].[hr].[LEAV_REQ_HEADER]', 'LEAV_REQNO', ''+theid, '', 'select_allby', '', 'dbh_leave', return_latest_id);
                    }else{
                      crud_function_preset('','','LEAV_REQNO*-, LEAV_REQDT','(SELECT MAX(LEAV_REQNO) + 1 AS Result FROM [LGU_DEV].[hr].[LEAV_REQ_HEADER])*-, GETDATE()','[LGU_DEV].[hr].[LEAV_REQ_HEADER]', 'EMP_ID*-, LEAV_STAT_ID*-, VL_FLG*-, SL_FLG*-, COM_FLG', ''+theid+'*-, 5*-, 0*-, 0*-, 0 ', 'INSERT', 'Successfully Added New Header!', 'dbh_leave');
                      function return_latest_id(data_id){
                        var data_id = data_id.substring(0, data_id.length - 2);
                        crud_function('','','[LGU_DEV].[hr].[LEAV_REQ_ITEMS]', 'LEAV_REQNO*-, LEAV_TYPE_ID*-, LEAV_ACCNO*-, DATE_FROM*-, DATE_TO*-, HALF_D_FLG*-, HALF_D_AM*-, HALF_D_PM*-, DAYS_APPLD*-, DAYS_APPVD*-, POSTED_FLG*-, REMARKS*-, LEAV_STAT_ID*-, BY_RANGE', data_id+'*-, '+document.getElementById('my_select').value+'*-, 10'+data_id+'*-, '+document.getElementById('date_from').value+'*-, '+document.getElementById('date_to').value+'*-, '+wholeday_flag+'*-, '+halfday_AM_flag+'*-, '+halfday_PM_flag+'*-, 0*-, 0*-, 0*-, '+overall_text+'*-, 5*-, 0', 'INSERT', 'Successfully Added Leave Data!', 'dbh_leave');
                      }
                      search_query('EMP_ID=:EMP_ID AND LEAV_STAT_ID = 5 AND CONVERT(VARCHAR(10),LEAV_REQDT,101)=CONVERT(VARCHAR(10),GETDATE(),101)', '[LGU_DEV].[hr].[LEAV_REQ_HEADER]', 'LEAV_REQNO', ''+theid, '', 'select_allby', '', 'dbh_leave', return_latest_id);
                    }
                  }
                  search_query('EMP_ID=:EMP_ID AND LEAV_STAT_ID = 5 AND CONVERT(VARCHAR(10),LEAV_REQDT,101)=CONVERT(VARCHAR(10),GETDATE(),101)', '[LGU_DEV].[hr].[LEAV_REQ_HEADER]', '', ''+theid+'', '', 'countallby', '', 'dbh_leave', return_countdata);
                }

                function delete_sub_leave(id_delete){
                  if(confirm("Would you like to delete the selected?")){
                    crud_function('ROW_ID=:ROW_ID', ''+id_delete, '[LGU_DEV].[hr].[LEAV_REQ_ITEMS]', '', '', 'DELETE', 'Successfully Deleted the Data', 'dbh_leave');
                  }
                }

                function leave_sub_checkbox(thisa_sub){
                if(document.getElementById("leave_sub_mycheck"+thisa_sub).checked === true){
                  mashael_leave = window.localStorage.getItem("mashael_leave");
                  window.localStorage.setItem("mashael_leave", mashael_leave+thisa_sub+",");
                  mashael_leave = window.localStorage.getItem("mashael_leave");
                }else{
                  mashael_leave = window.localStorage.getItem("mashael_leave");
                  tempshell_ls = ","+mashael_leave;
                  mashael_leave = tempshell_ls.replace(","+thisa_sub+",", ",");
                  mashael_leave = mashael_leave.substr(1);
                  window.localStorage.setItem("mashael_leave", mashael_leave);
                }
                }

                function deleteselected_leave_sub(){
                    mashael_leave_sub = window.localStorage.getItem("mashael_leave_sub");
                    mashael_leave_sub = mashael_leave_sub.slice(0, -1);
                    var xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function(){
                      if(this.readyState == 4 && this.status == 200){
                        alert(this.responseText);
                        window.localStorage.setItem("mashael_leave_sub", "");
                        searchengine_leave();
                      }
                    };
                    xmlhttp.open("GET", "subpages/phpfunction/leave_appmodule/deletebulk.php?deletevalue="+mashael_leave_sub, true);
                    xmlhttp.send();
                }             