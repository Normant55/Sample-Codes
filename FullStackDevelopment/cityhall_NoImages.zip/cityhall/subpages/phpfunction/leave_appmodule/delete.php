<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
$delete = $_GET['deletevalue'];
include("../../../php/connectPDO.php");

$statement = $dbh_leave -> prepare("DELETE FROM [LGU_DEV].[hr].[LEAV_REQ_HEADER] WHERE [LEAV_REQNO] = :delete");
$statement -> bindParam(":delete", $delete);
$statement -> execute();
if($statement){
	echo 'Successfully Deleted Object!';
}


?>