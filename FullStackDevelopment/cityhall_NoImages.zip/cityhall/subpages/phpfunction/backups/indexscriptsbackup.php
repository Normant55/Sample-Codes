<?php
include('../../php/connectPDO.php');

$these = array();
$numberthese = array();
	$statement = $dbhsub -> query("SELECT * FROM covertitleimage ORDER BY imageid DESC");
	while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
		$currentidea = $row['imageid'];
		$fordiv = '#processdiv'.$currentidea;
		array_push($numberthese, $fordiv);
		$currentidea = "'images/coverimages/".$currentidea.".png'";
		array_push($these, $currentidea);
	}
#var images = new Array (\'images/coverimages/33.png\', \'images/coverimages/32.png\', \'images/coverimages/31.png\');
#var images = new Array (\'images/coverimages/31.png\', \'images/coverimages/32.png\', \'images/coverimages/33.png\');
echo ' var images = new Array ('.implode(", ", $these).');
var index = 1;
function rotateImage()
{
  $(\'#frontimagedesign\').fadeOut(\'slow\', function() 
  {
    $(this).attr(\'src\', images[index]);
    
    $(this).fadeIn(\'slow\', function() 
    {
      if (index == images.length-1)
      {
        index = 0;
      }
      else
      {
        index++;
      }
    });
  


  });
} 
 function showDiv() {
    if (counter ==36) { counter--; return; }

    $(\''.implode(", ", $numberthese).'\')
      .stop()
      .hide()
      .filter( function() { return this.id.match(\'processdiv\' + counter); })   
      .show(\'fast\');
    counter == 34? counter = 36 : counter--; 

  }
 
$(document).ready(function()
{
  setInterval (rotateImage, 12000);
});';


echo '$(\'html\').addClass(\'js\');

$(function() {

  var timer = setInterval( showDiv, 12000);

  var counter = 36;

  function showDiv() {
    if (counter ==36) { counter--; return; }

    $(\''.implode(", ", $numberthese).'\')
      .stop()
      .hide()
      .filter( function() { return this.id.match(\'processdiv\' + counter); })   
      .show(\'fast\');
    counter == 34? counter = 36 : counter--; 

  }

});';
?>