<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
$idea = $_POST['idea'];
$thequery = $dbhsub -> query("DELETE FROM covertitleimage WHERE imageid = '$idea'");
if($thequery){
	echo 'Successfully Deleted News';
}
$allthere = $dbhsub -> query("SELECT extenderid FROM coverextender WHERE imageid = '$idea'");
while($row = $allthere -> fetch(PDO::FETCH_ASSOC)){
if(file_exists("../../images/coverimages/".$row['extenderid'].".png")){
$deleterpath = "../../images/coverimages/".$row['extenderid'].".png";
unlink($deleterpath);
}
}
$thequery = $dbhsub -> query("DELETE FROM coverextender WHERE imageid = '$idea'");
if($thequery){
}

?>