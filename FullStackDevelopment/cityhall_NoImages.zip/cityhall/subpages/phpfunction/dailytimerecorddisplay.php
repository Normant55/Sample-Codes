<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');

$theids =  $_GET['studID'];
$startmonth =  $_GET['startmonth'];
$startday =  $_GET['startday'];
$startyear =  $_GET['startyear'];
$endmonth =  $_GET['endmonth'];
$endday =  $_GET['endday'];
$endyear =  $_GET['endyear'];
$viewingmode = $_GET['viewingmode'];

$keypointarrays = array();
echo '<div class = "col-xs-12"><div class = "datesectorover"  style = "margin-bottom:20px;">';
echo '<div class = "datesector">';
echo '<div class = "markword col-xs-12 col-md-2 col-lg-2">Starting Date</div>';

echo '<div class = "markwordd">Month</div> <select id = "startmonth" onchange = "displaydtr()">
<option value = 1 ';if($startmonth == 1){echo'selected';}echo'>January</option>
<option value = 2 ';if($startmonth == 2){echo'selected';}echo'>Febuary</option>
<option value = 3 ';if($startmonth == 3){echo'selected';}echo'>March</option>
<option value = 4 ';if($startmonth == 4){echo'selected';}echo'>April</option>
<option value = 5 ';if($startmonth == 5){echo'selected';}echo'>May</option>
<option value = 6 ';if($startmonth == 6){echo'selected';}echo'>June</option>
<option value = 7 ';if($startmonth == 7){echo'selected';}echo'>July</option>
<option value = 8 ';if($startmonth == 8){echo'selected';}echo'>August</option>
<option value = 9 ';if($startmonth == 9){echo'selected';}echo'>September</option>
<option value = 10 ';if($startmonth == 10){echo'selected';}echo'>October</option>
<option value = 11 ';if($startmonth == 11){echo'selected';}echo'>November</option>
<option value = 12 ';if($startmonth == 12){echo'selected';}echo'>December</option>
</select>';
echo '<div class = "markwordd">Day</div> <select id ="startday" onchange = "displaydtr()">';
for($x=1; $x<=31; $x++){
	echo '<option value = '.$x.' ';if($startday == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markwordd">Year</div> <select id ="startyear" onchange = "displaydtr()">';
for($x=1990; $x<=2999; $x++){
	echo '<option value = '.$x.' ';if($startyear == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';

echo '<div class = "markword col-xs-12 col-md-2 col-lg-2"> ----- </div>';

echo '<div class = "markwordd">Month</div> <select id = "endmonth" onchange = "displaydtr()">
<option value = 1 ';if($endmonth == 1){echo'selected';}echo'>January</option>
<option value = 2 ';if($endmonth == 2){echo'selected';}echo'>Febuary</option>
<option value = 3 ';if($endmonth == 3){echo'selected';}echo'>March</option>
<option value = 4 ';if($endmonth == 4){echo'selected';}echo'>April</option>
<option value = 5 ';if($endmonth == 5){echo'selected';}echo'>May</option>
<option value = 6 ';if($endmonth == 6){echo'selected';}echo'>June</option>
<option value = 7 ';if($endmonth == 7){echo'selected';}echo'>July</option>
<option value = 8 ';if($endmonth == 8){echo'selected';}echo'>August</option>
<option value = 9 ';if($endmonth == 9){echo'selected';}echo'>September</option>
<option value = 10 ';if($endmonth == 10){echo'selected';}echo'>October</option>
<option value = 11 ';if($endmonth == 11){echo'selected';}echo'>November</option>
<option value = 12 ';if($endmonth == 12){echo'selected';}echo'>December</option>
</select>';
echo '<div class = "markwordd">Day</div> <select id ="endday" onchange = "displaydtr()">';
for($x=1; $x<=31; $x++){
	echo '<option value = '.$x.' ';if($endday == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markwordd">Year</div> <select id ="endyear" onchange = "displaydtr()">';
for($x=1990; $x<=2999; $x++){
	echo '<option value = '.$x.' ';if($endyear == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '</div>';
// echo '<button class = "showrecords" onclick = "displaydtr()">Show Records</button>';
echo '</div>';

        // echo 'hi';


 // echo '<div class = "description">Displaying from '.$startyear.'-'.$startmonth.'-'.$startday.' to '.$endyear.'-'.$endmonth.'-'.$endday.'</div>';
echo '<div class ="description"></div>';
$query = "SELECT CONVERT(VARCHAR(10),dtr_date, 101) AS dtrdt
      ,[arrival_am]
      ,[departure_am]
      ,[arrival_pm]
      ,[departure_pm]
      ,[lut_freq]
      ,[ttl_lut]
      ,[key_seq]
      
  FROM [BIOMETRICS].[dbo].[dtr_final] WHERE employeeid = '$theids' AND dtr_date between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000'
  ORDER BY dtr_date asc
  "; 

  $stmt = $dbh_dtr -> query($query);
// echo $theids;
// echo 'ahahah';
$lutfreq = 0;
$totlut = 0;

  echo '<div class ="col-md-2 passerinv"></div>';
echo '<div class = "col-md-1 passerbiga"><div class ="uppercontenttab">Date</div></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab">Day</div></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab">Arrival AM</div></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab">Departure AM</div></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab">Arrival PM</div></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab">Departure PM</div></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab">L&UT.Freq</div></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab">Tot.L&UT</div></div>';
   echo '<div class ="col-md-2 passerinv"></div>';
$loopstring = 'start';  
while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
  if($loopstring != $row['dtrdt']){
	  echo '<div class ="col-md-2 passerinv"></div>';

echo '<div class = "col-md-1 passerbig">'.str_replace("/", "-", $row['dtrdt']).'</div>';

$month = substr($row['dtrdt'], 0, 2);
$day = substr($row['dtrdt'], 3, 2);
$year = substr($row['dtrdt'], 6, 4); 
$combined = $year.'-'.$month.'-'.$day;
$dayOfWeek = date("l", strtotime($combined));
  
  echo '<div class = "col-md-1 passerbig">'.$dayOfWeek.'</div>';
if($viewingmode != 'normal'){
$tosh = $dbhsub -> prepare("SELECT * FROM dtr_foreditrequest WHERE idspeci = :keysq");
$tosh->bindParam(':keysq', $row['key_seq']);
$tosh->execute();
if($tosh->fetchColumn()>0){
$tosh = $dbhsub -> prepare("SELECT * FROM dtr_foreditrequest WHERE idspeci = :keysq");
$tosh->bindParam(':keysq', $row['key_seq']);
$tosh->execute();
while($rowfinder = $tosh->fetch(PDO::FETCH_ASSOC)){

  if(!empty($rowfinder['arrival_am'])){
echo '<div class = "col-md-1 passerbig timeeditor" style = "color: red" onclick = "arrivalamedit(\''.$rowfinder['arrival_am'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$rowfinder['arrival_am'].'</div>';
}
else{
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "arrivalamedit(\''.$row['arrival_am'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['arrival_am'].'</div>';
}

  if(!empty($rowfinder['departure_am'])){
echo '<div class = "col-md-1 passerbig timeeditor" style = "color: red" onclick = "departureamedit(\''.$rowfinder['departure_am'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$rowfinder['departure_am'].'</div>';
}
else{
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "departureamedit(\''.$row['departure_am'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['departure_am'].'</div>';
}

  if(!empty($rowfinder['arrival_pm'])){
echo '<div class = "col-md-1 passerbig timeeditor" style = "color: red" onclick = "arrivalpmedit(\''.$rowfinder['arrival_pm'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$rowfinder['arrival_pm'].'</div>';
}
else{
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "arrivalpmedit(\''.$row['arrival_pm'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['arrival_pm'].'</div>';
}

  if(!empty($rowfinder['departure_pm'])){
echo '<div class = "col-md-1 passerbig timeeditor" style = "color: red" onclick = "departurepmedit(\''.$rowfinder['departure_pm'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$rowfinder['departure_pm'].'</div>';
}
else{
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "departurepmedit(\''.$row['departure_pm'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['departure_pm'].'</div>';
}

}}else{
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "arrivalamedit(\''.$row['arrival_am'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['arrival_am'].'</div>';
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "departureamedit(\''.$row['departure_am'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['departure_am'].'</div>';
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "arrivalpmedit(\''.$row['arrival_pm'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['arrival_pm'].'</div>';
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "departurepmedit(\''.$row['departure_pm'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['departure_pm'].'</div>';

}



}else{
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "arrivalamedit(\''.$row['arrival_am'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['arrival_am'].'</div>';
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "departureamedit(\''.$row['departure_am'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['departure_am'].'</div>';
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "arrivalpmedit(\''.$row['arrival_pm'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['arrival_pm'].'</div>';
echo '<div class = "col-md-1 passerbig timeeditor" onclick = "departurepmedit(\''.$row['departure_pm'].'\', \''.$row['dtrdt'].'\', \''.$dayOfWeek.'\', \''.$row['key_seq'].'\')">'.$row['departure_pm'].'</div>';
}


echo '<div class = "col-md-1 passerbig">'.$row['lut_freq'].'</div>';
echo '<div class = "col-md-1 passerbig">'.$row['ttl_lut'].'</div>';
   echo '<div class ="col-md-2 passerinv"></div>';
   if($row['lut_freq'] != 0){
   	$lutfreq += $row['lut_freq'];
   }
   if($row['ttl_lut'] != 0){
   	$totlut += $row['ttl_lut'];
   }



$loopstring = $row['dtrdt'];}
}
  echo '<div class ="col-md-2 passerinv"></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab"></div></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab"></div></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab"></div></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab"></div></div>';
echo '<div class = "col-md-1 passer"><div class ="uppercontenttab"></div></div>';
echo '<div class = "col-md-1 passer" style = "font-size: 110%;"><div class ="uppercontenttab">Total</div></div>';
echo '<div class = "col-md-1 passer" style = "font-size: 110%;"><div class ="uppercontenttab">'.$lutfreq.'</div></div>';
echo '<div class = "col-md-1 passer" style = "font-size: 110%;"><div class ="uppercontenttab">'.$totlut.'</div></div>';
   echo '<div class ="col-md-2 passerinv"></div>';
 //MM - DD -YYYY
//Our YYYY-MM-DD date string.
// $date = "2012-01-21";
// //Get the day of the week using PHP's date function.
// $dayOfWeek = date("l", strtotime($combined));
// //Print out the day that our date fell on.
// echo $date . ' fell on a ' . $dayOfWeek;

   echo '<div class = "container-fluid"><a class = "word_button" style = "cursor: pointer; text-decoration: none;" onclick = "printpreview()">print preview</a></div>';

?>