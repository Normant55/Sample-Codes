<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
echo '<div class = "container watchnews"  style = " min-height: 200px">';
echo '<div class = "col-xs-12 col-md-12" style = "min-height: 200px; padding: 0;">';

  $statement = $dbhsub -> query("SELECT TOP 4 * FROM mainnews WHERE featured = 'yes' ORDER BY dateuploaded DESC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
  $ok = $row['newsid'];
  $innerstatement = $dbhsub -> query("SELECT TOP 1 * FROM newsextension WHERE type ='none' AND newsid = '$ok' ORDER BY dateuploaded ASC");
  while($innerrow = $innerstatement ->fetch(PDO::FETCH_ASSOC)){
  $size = $innerrow['sizeposition'];
  if(substr($size, 0, 1) == 'f'){
  echo '<div class = "col-xs-12 col-md-6 col-lg-6 featuredbox" onclick = "viewthisnews('.$row['newsid'].')" style = "margin-top: 10px; cursor:pointer; position: relative; padding: 0;">';
}else{
  echo '<div class = "col-xs-12 col-md-6 col-lg-6 featuredbox" onclick = "viewthisnews('.$row['newsid'].')" style = "margin-top: 10px; cursor:pointer; position: relative; padding: 0;">';
}

echo '<div class = "col-xs-12 col-md-12 col-lg-12 whitebg transition_box" id = "vortex'.$row['newsid'].'" style = "padding: 0px">';

  echo '<div class = "col-xs-12 col-md-12 col-lg-12" id = "vortax'.$row['newsid'].'" style = "position: relative; min-height: 200px; padding: 0;">';

  echo '<img class = "featuredimage" src="images/newsimages/'.$innerrow['newscontentid'].'.png" alt="image test" style = "background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;';
echo 'width: 100%;
           " />';
  // echo '<div class = "col-xs-12"  onclick = "viewthisnews('.$row['newsid'].')" id = "vortex'.$row['newsid'].'" style = "cursor:pointer; background-color:rgba(200,200,200, 0); min-height: 200px; position: absolute;" onmouseover = "priyata('.$row['newsid'].');">';
  // echo '</div>';
      // [newscontentid]
      // ,[newsid]
      // ,[description]
      // ,[type]
      // ,[sizeposition]
      // ,[imagepath]
      // ,[dateuploaded]
      // [newsid]
      // ,[title]
      // ,[type]
      // ,[sizeposition]
      // ,[dateuploaded]
      // ,[publisher]
           echo'</div>';
echo '<div class = "col-xs-12 col-md-12 col-lg-12 imagedescriptions" style = "background-color:rgba(200,200,200, 0); min-height: 0px; overflow: auto; position: relative;">';
if(strlen($row['title'])>100){
  $finaltitle = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $row['title']);
   $finaltitle = substr($finaltitle, 0, 100).'...';}
   else{
  $finaltitle = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $row['title']);
   }
         echo '<h2 id = "vorturb'.$row['newsid'].'" class = "transition_text" style = "text-align: center;">'.$finaltitle.'</h2>';
echo'</div>';





echo '</div>';



    


  }
   echo '</div>';
  }
    echo '</div>';
//     echo '<div class = "col-xs-2" style = "height: 75vh; display: block;">';
//   $statement = $dbhsub -> query("SELECT TOP 12 * FROM mainnews WHERE featured = 'yes' ORDER BY dateuploaded DESC");
//   while($row = $statement ->fetch(PDO::FETCH_ASSOC)){

// if(strlen($row['title'])>25){
//    $finaltitle = substr($row['title'], 0, 25).'...';}
//    else{
//     $finaltitle = $row['title'];
//    }
//          echo '<h4 id = "newsselector'.$row['newsid'].'" style = "overflow: auto;"><a style = "cursor:pointer; text-decoration:none;" onclick = "sumondong('.$row['newsid'].')">'.$finaltitle.'</a></h4>';
//   }
//    echo '<h3><a href = "subpages/newsarchive" style = "cursor:pointer; text-decoration:none; color: rgba(40, 210, 240, 1);">View All</a></h3>';
//   echo '</div>';


echo '<div class = "col-xs-12 col-md-8 watchnewsnonlatest" style = "min-height: 200px; padding: 0;">';

  $statement = $dbhsub -> query("SELECT TOP 2 * FROM mainnews WHERE featured != 'yes' ORDER BY dateuploaded DESC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
    echo '<div class = "row whitebg nonfeaturedbox transition_box" onclick = "viewthisnews('.$row['newsid'].')" id = "vortex'.$row['newsid'].'" style = "margin-top: 10px; cursor:pointer; min-height: 200px; position: relative;">';

    echo '<div class = "col-xs-12 col-md-6 col-lg-6 imagedescriptions" style = "background-color:rgba(200,200,200, 0); min-height: 0px; position: relative;">';
if(strlen($row['title'])>100){
   $finaltitle = substr($row['title'], 0, 100).'...';}
   else{
    $finaltitle = $row['title'];
   }
         echo '<h4 id = "vorturb'.$row['newsid'].'" class = "transition_text" style = "color: rgba(10, 10, 10, 1)">'.$finaltitle.'</h4>';
$ok = $row['newsid'];
  $innerstatement = $dbhsub -> query("SELECT TOP 1 * FROM newsextension WHERE type !='none' AND newsid = '$ok' ORDER BY dateuploaded ASC");
  while($innerrow = $innerstatement ->fetch(PDO::FETCH_ASSOC)){
         $fulldesc = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $innerrow['description']);
         $fulldesc = str_replace("hexor", "hexor", $innerrow['description']);
         echo '<h5>'.$fulldesc.'</h5>';
}
echo'</div>';


  $innerstatement = $dbhsub -> query("SELECT TOP 1 * FROM newsextension WHERE type ='none' AND newsid = '$ok' ORDER BY dateuploaded ASC");
  while($innerrow = $innerstatement ->fetch(PDO::FETCH_ASSOC)){
  echo '<div class = "col-xs-12 col-md-6 col-lg-6" id = "vortax'.$row['newsid'].'" style = "position: relative; height: 200px;">';

  echo '<img class = "nonfeaturedimage" src="images/newsimages/'.$innerrow['newscontentid'].'.png" alt="image test" style = "background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;';
  echo 'height: 200px;';  
echo 'width: 100%;
           " />';

    
echo'</div>';


  }
    echo '</div>';
  }
    echo '</div>';






  echo '</div>';
?>



        