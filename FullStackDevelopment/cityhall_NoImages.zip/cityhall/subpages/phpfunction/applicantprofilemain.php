<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$theconnection =  $_GET['connection'];
$theids =  $_GET['studID'];
$userprof =  $_GET['userprof'];
$username_query = "select username from applicantlogin WHERE employeeid = '$theids'";
$user_statement = $dbh -> query($username_query);
while($user_row = $user_statement -> fetch( PDO::FETCH_ASSOC )){
  $my_user = strip_tags($user_row['username']);
}

$query = "select * from Applicants WHERE employeeid = '$theids'";
$stmt = $dbh -> query($query);
// echo $theids;
// echo 'ahahah';
while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
$pdfname = strip_tags($row['lastname']).", ".strip_tags($row['firstname'])." ".strip_tags($row['middle']).".pdf";
$filename = "C:\\xampp\\htdocs\\cityhall\\uploads\\".strip_tags($row['lastname']).", ".strip_tags($row['firstname'])." ".strip_tags($row['middle']).".pdf";
                 //echo '<div class = "infotab"> Database ID: '.$row['Student_ID'];
if(!isset($_GET['adminview'])){
echo '
  <ul class="nav nav-tabs">
    <li class="active"><a class = "word_button_sky" data-toggle="tab" href="#home">Overview</a></li>
    <li><a class = "word_button_sky" data-toggle="tab" href="#menu1">Application</a></li>
    <li><a class = "word_button_sky" data-toggle="tab" href="#menu2">Information</a></li>
    <li><a class = "word_button_sky" data-toggle="tab" href="#menu3">Actions</a></li>
    <li><a class = "word_button_sky" data-toggle="tab" href="#menu4">Files</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
  ';
  if(isset($_GET['adminview'])){
echo '
<div class = "no_lining_standard_margin"><a style = "text-decoration:none; cursor:pointer;" onclick = "reto(\'overview\')">
 <img class = "img-responsive" src="images/return_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
Back</a></div>';}


if($theconnection != 'fixed'){
                echo '
                        <div class="jumbotron name_space information_eye">
                            <a class="navbar-brand">'.strip_tags($row['fullname']).'</a> <div class = "col-md-12">
<h4>
<img src="images/menu_profile.png" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>
'.$my_user.' ID no.'.$row['employeeid'].'
                            </h4></div></div>
        </div>
           <div class = "buttons">
        <div class = "boxforpicture" id = "thepic">
            <div class = "picturebox"><img src = "http://'.$theconnection.'/cityhall/images/applicantprofile/'.$theids.'.png" style = "
            width: 150px;
           height: 150px;
            ">
         </div></div>
                <div class = "picture" id = "editpictureb" onclick = "picture()">Image Upload</div>
                <div class = "button_positive" onclick = "rejobapply()">Job Application</div>
                <div class = "button_positive" onclick = "viewpdfen()">View Application</div>
                ';         
 // echo'<div class = "editor" onclick = "editprofile()">Edit Profile</div>
 //                <div class = "editor" onclick = "rejobapply()">Job Application<div style = "position: absolute;">Re-submit or finalize your submission of eligibility, school graduated, educational attainment and job titles</div></div>
 //                </div>
 //            <form class = "sagara" action="php/uploadfile.php?thislove='.$row['lastname'].', '.$row['firstname'].' '.$row['middle'].'" method ="post" enctype = "multipart/form-data" target = "uploadTarget" onsubmit = "startUpload();"><p id = "uploadForm"><br/><label> Upload Resume: <input name = "myfile" type = "file" size = "30"/></label></p><input id = "saela" type = "submit" name = "submitBtn" class = "sbtn" value = "Submit"/></form>;
 //                ';
}
else{
 echo '

                        <div class="jumbotron name_space">
                            <a class="navbar-brand information_eye_large">'.strip_tags($row['fullname']).'</a> <div class = "col-md-12">
<h4 class = "information_eye_large">
<img src="images/menu_profile.png" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>ID no.'.$row['employeeid'].'
                            </h4></div>
        </div>
           <div class = "buttons">
        <div class = "boxforpicture" id = "thepic">
            <div class = "picturebox"><img src = "images/applicantprofile/'.$theids.'.png?v=1.2" style = "
            width: 150px;
           height: 150px;
            ">
            </div></div></div>

                
                <div class = "button_positive" id = "editpictureb" onclick = "picture()">Image Upload</div>
                <div class = "button_positive" onclick = "rejobapply()">Job Application</div>
                <div class = "button_positive" onclick = "viewpdfen()">View Application</div>';         


}}else{
 echo '
  <ul class="nav nav-tabs">
    <li class="active"><a class = "word_button_sky" data-toggle="tab" href="#home">Overview</a></li>
    <li><a class = "word_button_sky" data-toggle="tab" href="#menu1">Application</a></li>
    <li><a class = "word_button_sky" data-toggle="tab" href="#menu2">Information</a></li>
    <li><a class = "word_button_sky" data-toggle="tab" href="#menu3">Actions</a></li>
    <li><a class = "word_button_sky" data-toggle="tab" href="#menu4" onclick = " applicantshow_admin('.$theids.')">Files</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">';
    if(isset($_GET['adminview'])){
echo '
<div class = "no_lining_standard_margin"><a style = "text-decoration:none; cursor:pointer;" onclick = "reto(\'overview\')">
 <img class = "img-responsive" src="images/return_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
Back</a></div>';}

 echo                       '<div class="jumbotron name_space">
                            <a class="navbar-brand information_eye_large">'.strip_tags($row['fullname']).'</a>
 <div class = "col-md-12">
<h4 class = "information_eye_large">
<img src="images/menu_profile.png" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>
'.$my_user.' ID no.'.$row['employeeid'].'
                            </h4></div>
        </div>
           <div class = "buttons">
        <div class = "boxforpicture_full" id = "thepic">
            <div class = "picturebox"><img src = "images/applicantprofile/'.$theids.'.png?v=1.2" style = "
            width: 150px;
           height: 150px;
            ">
            </div></div>   </div>
                <div class = "button_positive" id = "aeditpictureb" onclick = "apicture()">Image Upload</div>
                <div class = "button_positive" onclick = "viewpdfen('.$theids.')">View Application</div>';
                 echo '
                <div style = "visibility:hidden;" id = "pictureapplicant">'.$row['employeeid'].'</div>
                ';
}
echo '<div class = "col-md-12">
<h4 class = "information_eye_large">
<img src="images/profile_logo.png" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>
Contact Information</h4></div>';
echo '<div class = "col-md-2 spacing_margin information_eye_large">Home Phone:</div>';
if($row['home_phone']!='' AND isset($row['home_phone'])){
echo '<div class = "col-md-10 spacing_margin information_eye_large">'.strip_tags($row['home_phone']).'</div>';
}else{
echo '<div class = "col-md-10 spacing_margin information_eye_large">None</div>'; 
}

echo '<div class = "col-md-2 spacing_margin information_eye_large">Mobile Phone:</div>';
if($row['mobile_no']!='' AND isset($row['mobile_no'])){
echo '<div class = "col-md-10 spacing_margin information_eye_large">'.strip_tags($row['mobile_no']).'</div>';
}else{
echo '<div class = "col-md-10 spacing_margin information_eye_large">None</div>'; 
}

echo '<div class = "col-md-2 spacing_margin information_eye_large">Email Address:</div>';
if($row['email_address']!='' AND isset($row['email_address'])){
echo '<div class = "col-md-10 spacing_margin information_eye_large">'.strip_tags($row['email_address']).'</div>';
}else{
echo '<div class = "col-md-10 spacing_margin information_eye_large">None</div>'; 
}

echo '<div class = "col-md-2 spacing_margin information_eye_large">Land Line:</div>';
if($row['landline']!='' AND isset($row['landline'])){
echo '<div class = "col-md-10 spacing_margin information_eye_large">'.strip_tags($row['landline']).'</div>';
}else{
echo '<div class = "col-md-10 spacing_margin information_eye_large">None</div>'; 
}

echo '<div class = "col-md-2 spacing_margin information_eye_large">Latitude:</div>';
if($row['latitude']!='' AND isset($row['latitude'])){
echo '<div class = "col-md-10 spacing_margin information_eye_large">'.strip_tags($row['latitude']).'</div>';
}else{
echo '<div class = "col-md-10 spacing_margin information_eye_large">None</div>'; 
}
echo '<div class = "col-md-2 spacing_margin information_eye_large">Longitude:</div>';
if($row['longitude']!='' AND isset($row['longitude'])){
echo '<div class = "col-md-10 spacing_margin information_eye_large">'.strip_tags($row['longitude']).'</div>';
}else{
echo '<div class = "col-md-10 spacing_margin information_eye_large">None</div>'; 
}
$data = trim($foo = preg_replace('/\s+/', ' ', strip_tags($row['process_status'])));
echo '<div class = "col-md-12"><h4 class = "information_eye_large">
<img src="images/gear_logo.gif" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>
Status: ';
if($data!='' AND isset($data)){
echo ''.$row['process_status'].'</h4></div>';
}else{
echo 'None</h4></div>';
}


if(!isset($_GET['adminview'])){
}else
{
// echo '</div>';
echo '<h4 class = "information_eye_large">
<img src="images/remark.png" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;
  cursor:pointer;"
  onclick = "toggle_input_all()"/>
Remarks:</h4>';
echo '
<input type = "text" class = "inputtab_off information_eye_large" id = "remarks" 
    onkeyup = "crud_function_noload_noalert(\'employeeid = :employeeid\',\''.$theids.'\',\'Applicants\', \'remarks\', this.value, \'UPDATE\', \'Successfully Updated!\', \'dbh\')"
    onclick = "toggle_input()"
    value = "'.$row['remarks'].'">
    ';
}

echo '
    </div>
    <div id="menu1" class="tab-pane fade">
      ';
if(isset($_GET['adminview'])){
echo '
<div class = "no_lining_standard_margin"><a style = "text-decoration:none; cursor:pointer;" onclick = "reto(\'overview\')">
 <img class = "img-responsive" src="images/return_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
Back</a></div>';}


echo '
    <div class = "col-md-12 information_eye"><h4>
<img src="images/verified_logo.png" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>
  Position Applied</h4></div>';

$depcodearray = array();
$depcodearray = explode(', ', $row['dept_abbriv']);
$jobarray = array();
$jobarray = explode(', ', $row['job_title']);


$x = 0;
$counter = 1;
while($counter<2){
    if(isset($jobarray[$x])){
    $jobdisplay = $jobarray[$x];
    $depcodedisplay = $depcodearray[$x];
    $x++;
    }else{
        $counter = 2;
    }

    echo '<div class = "col-md-6 spacing_margin font_eye_fast">'.$jobdisplay.'</div>';
    echo '<div class = "col-md-6 spacing_margin font_eye_fast">'.$depcodedisplay.'</div>';    
}
echo '
    <div class = "col-md-12 information_eye"><h4>
<img src="images/verified_logo.png" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>
    Qualifications</h4></div>';
echo '<div class = "col-md-2 font_eye_fast">Course/Degree:</div>';
$data = trim($foo = preg_replace('/\s+/', ' ', strip_tags($row['course_degree'])));
if($data!='' AND isset($data)){
$data_place = str_replace('][', '<br>', $row['course_degree']);
$data_place = str_replace('[', '', $data_place);
$data_place = str_replace(']', '', $data_place);
echo '<div class = "col-md-10 font_eye_fast">'.$data_place.'</div>';
}else{
echo '<div class = "col-md-10 font_eye_fast">None</div>'; 
}
$data = trim($foo = preg_replace('/\s+/', ' ', strip_tags($row['school_grad'])));
echo '<div class = "col-md-2 font_eye_fast">School Graduated:</div>';
if($data!='' AND isset($data)){
$data_place = str_replace('][', '<br>', $row['school_grad']);
$data_place = str_replace('[', '', $data_place);
$data_place = str_replace(']', '', $data_place);
echo '<div class = "col-md-10 font_eye_fast">'.$data_place.'</div>';
}else{
echo '<div class = "col-md-10 font_eye_fast">None</div>'; 
}
$data = trim($foo = preg_replace('/\s+/', ' ', strip_tags($row['eligibility'])));
echo '<div class = "col-md-2 font_eye_fast">Eligibility:</div>';
if($data!='' AND isset($data)){
$data_place = str_replace('][', '<br>', $row['eligibility']);
$data_place = str_replace('[', '', $data_place);
$data_place = str_replace(']', '', $data_place);
echo '<div class = "col-md-10 font_eye_fast">'.$data_place.'</div>';
}else{
echo '<div class = "col-md-10 font_eye_fast">None</div>'; 
}
$data = trim($foo = preg_replace('/\s+/', ' ', strip_tags($row['experience'])));
echo '<div class = "col-md-2 font_eye_fast">Experience:</div>';
if($data!='' AND isset($data)){
$data_place = str_replace('][', '<br>', $row['experience']);
$data_place = str_replace('[', '', $data_place);
$data_place = str_replace(']', '', $data_place);
echo '<div class = "col-md-10 font_eye_fast">'.$data_place.'</div>';
}else{
echo '<div class = "col-md-10 font_eye_fast">None</div>'; 
}
// $data = trim($foo = preg_replace('/\s+/', ' ', $row['yearsexp']));
// echo '<div class = "col-md-2">Years of Experience:</div>';
// if($data!='' AND isset($data)){
// $data_place = str_replace('][', '<br>', $row['yearsexp']);
// $data_place = str_replace('[', '', $data_place);
// $data_place = str_replace(']', '', $data_place);
// echo '<div class = "col-md-10">'.$data_place.'</div>';
// }else{
// echo '<div class = "col-md-10">None</div>'; 
// }
$data = trim($foo = preg_replace('/\s+/', ' ', strip_tags($row['training'])));
echo '<div class = "col-md-2 font_eye_fast">Training:</div>';
if($data!='' AND isset($data)){
$data_place = str_replace('][', '<br>', $row['training']);
$data_place = str_replace('[', '', $data_place);
$data_place = str_replace(']', '', $data_place);
echo '<div class = "col-md-10 font_eye_fast">'.$data_place.'</div>';
}else{
echo '<div class = "col-md-10 font_eye_fast">None</div>';
}
$data = trim($foo = preg_replace('/\s+/', ' ', strip_tags($row['special_skills'])));
echo '<div class = "col-md-2 font_eye_fast">Special Skills:</div>';
if($data!='' AND isset($data)){
$data_place = str_replace('][', '<br>', $row['special_skills']);
$data_place = str_replace('[', '', $data_place);
$data_place = str_replace(']', '', $data_place);
echo '<div class = "col-md-10 font_eye_fast">'.$data_place.'</div>';
}else{
echo '<div class = "col-md-10 font_eye_fast">None</div>'; 
}

echo '
    </div>
    <div id="menu2" class="tab-pane fade">
    ';
    if(isset($_GET['adminview'])){
echo '
<div class = "no_lining_standard_margin"><a style = "text-decoration:none; cursor:pointer;" onclick = "reto(\'overview\')">
 <img class = "img-responsive" src="images/return_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
Back</a></div>';}

                 echo '<div class = "col-md-4 font_eye_fast"><h2>Personnal Information</h2>
                 Given Name:<div class = "infotab">'.strip_tags($row['firstname']);
                 echo '</div>   
                 Middle Name:<div class = "infotab">'.strip_tags($row['middle']);
                 echo '</div> 
                 Surname:<div class = "infotab">'.strip_tags($row['lastname']);
                 echo '</div> 
                 Fullname:<div class = "infotab">'.strip_tags($row['fullname']);                 
                 echo '</div>';
                echo 'Home Address:<div class = "infotab">'.strip_tags($row['home_address']);
                switch ($row['gender']){
                case 0:
                echo '</div> 
                Gender:<div class = "infotab">Female';
                break;
                case 1:
                echo '</div> 
                Gender:<div class = "infotab">Male';
                break;
                }
                 echo '</div> Citizenship:<div class = "infotab">'.strip_tags($row['citizenship']);
                 echo '</div> Birthdate:<div class = "infotab">'.strip_tags($row['birthdate']);
                 echo '</div> Birthplace:<div class = "infotab">'.strip_tags($row['birthplace']);
                 echo '</div> Age:<div class = "infotab">'.strip_tags($row['age']);
                 echo '</div> Religion:<div class = "infotab">'.strip_tags($row['religion']).'</div></div><div class = "col-md-4 font_eye_fast">';
                 echo '<h2>Government Agencies</h2> 
                 Tin Number:<div class = "infotab">'.strip_tags($row['tin_number']);
                 echo '</div> SSS GSIS number:<div class = "infotab"> '.strip_tags($row['sssgsis_number']);
                 echo '</div> SSS GSIS contribution:<div class = "infotab">'.strip_tags($row['sssgsis_contrib']);
                 echo '</div> Philhealth Number:<div class = "infotab">'.strip_tags($row['philhealth_no']);
                 echo '</div> Philhealth contribution:<div class = "infotab">'.strip_tags($row['philhealth_contrib']);
                 echo '</div> Pagibig Number:<div class = "infotab">'.strip_tags($row['pagibig_no']);
                 echo '</div> Pagibig contribution:<div class = "infotab">'.strip_tags($row['pagibig_contrib']);
                 echo '</div> Tax Category:<div class = "infotab"> '.strip_tags($row['taxcategory']);
                  echo '</div> Cedula Number:<div class = "infotab">'.strip_tags($row['cedula_no']);
                  echo '</div> Date Issued:<div class = "infotab">'.strip_tags($row['dateissued']);
                 echo '</div> Place Issued:<div class = "infotab">'.strip_tags($row['placeissued']);
                 echo '</div> PWD:<div class = "infotab">'.strip_tags($row['pwd']);
                 echo '</div> Nature Statistics:<div class = "infotab"> '.strip_tags($row['nature_stat']);

// $queryinside = "select count(*) as count from employee_children WHERE employeeid = '$theids'";
// $stmtinside = $dbh -> query($queryinside);
// // echo $theids;
// // echo 'ahahah';
// while($rowinside = $stmtinside -> fetch( PDO::FETCH_ASSOC )){
//     $count = $rowinside['count'];
//                  //echo '<div class = "infotab"> Database ID: '.$row['Student_ID'];
// $queryinsider = $dbh->prepare("UPDATE Applicants SET no_dependents = ? WHERE employeeid = ?");
// $stmtinsider = $queryinsider->execute(array($count, $theids));
// if($stmtinsider){
// }
// else{
// }
// }


echo '</div>
                 </div><div class = "col-md-4 font_eye_fast"><h2>Family Information</h2>';

                 switch ($row['marital_status']){
                case 1:
                echo '
                Marital Status:<div class = "infotab">Single';
                break;
                case 2:
                echo '</div> 
                Marital Status:<div class = "infotab">Married';
                break;
                case 3:
                echo '</div> 
                Marital Status:<div class = "infotab">Widowed';
                break;
                case 4:
                echo '</div> 
                Marital Status:<div class = "infotab">Separated';
                break;
                 }
                 echo '</div> Father\'s Lastname:<div class = "infotab">'.strip_tags($row['flastname']);
                 echo '</div> Father\'s Firstname:<div class = "infotab">'.strip_tags($row['ffirstname']);
                 echo '</div> Father\'s Middlename:<div class = "infotab">'.strip_tags($row['fmiddle']);
                 echo '</div> Mother\'s Lastname:<div class = "infotab"> '.strip_tags($row['mlastname']);
                 echo '</div> Mother\'s Firstname:<div class = "infotab">'.strip_tags($row['mfirstname']);
                 echo '</div> Mother\'s Middlename:<div class = "infotab">'.strip_tags($row['mmiddle']);
                 echo '</div> Spouse Lastname:<div class = "infotab">'.strip_tags($row['spouse']);
                 echo '</div> Spouse Firstname:<div class = "infotab">'.strip_tags($row['spousefirstname']);
                 echo '</div> Spouse Middlename:<div class = "infotab">'.strip_tags($row['spousemiddle']);
                echo '</div> Spouse Address:<div class = "infotab">'.strip_tags($row['spouse_address']);
                                     echo '</div> Number Dependents:<div class = "infotab" style = "overflow: auto;">Not Available';
                 // echo '</div> Number Dependents:<div class = "infotab" style = "overflow: auto;">'.$count;
                 echo '

<img class = "img-responsive" src="images/logo_add.png" alt="image test"
  style = "position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 20px;
  cursor: pointer;
  float: right;
"/>
                ';
                 echo '</div>';
                 // echo '</div> Item Number:<div class = "infotab">'.$row['item_no'];
                 // echo '</div> Job Grade:<div class = "infotab">'.$row['job_grade'];
                //  $thecourse = $row['Course_ID'];
                
                // $querysubject = "select * from course where Course_ID = '$thecourse'";
                // foreach ($psbh->query($querysubject) as $rowex) {
                // echo '</div> Course:<div class = "infotab">'.$rowex['Course_Name'];
                // }
                 // echo '</div> Entrance Exam Score:<div class = "infotab">'.$row['remarks'];
             
                 // echo '</div> Enrollment Status:<div class = "infotab">'.$row['status'];
                 echo '</div>

    </div>
    <div id="menu3" class="tab-pane fade">';

if(isset($_GET['adminview'])){
echo '
<div class = "no_lining_standard_margin"><a style = "text-decoration:none; cursor:pointer;" onclick = "reto(\'overview\')">
 <img class = "img-responsive" src="images/return_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
Back</a></div>';
echo '
<div id = "applicationform">
<div class = "col-md-12">
<ul>
<h4 class = "transaction_head">PDF Files</h4>
                 <div class = "button_positive" onclick = "viewpdfen('.$theids.')">View Application</div>';
if (file_exists($filename)){
                   echo '<div class = "button_positive" onclick = "mypdf(\''.$pdfname.'\')">View Resume/Custom</div>';}
echo'        </ul>
                   </div><div class = "col-md-12">
<ul>
<h4 class = "transaction_head">Communications</h4>
<li class = "transaction_subtitle">Message</li>
<textarea class = "textarea_standard" id = "my_message">
</textarea>
</ul>
<div class = "button_positive" onclick = "crud_function_preset(\'\',\'\',\'date_recieved\',\'GETDATE()\',\'message_records\', \'message_content*-, target_username*-, message_origin*-, message_title\', document.getElementById(\'my_message\').value+\'*-, '.$my_user.'*-, '.$userprof.'*-, CHRMO LGU-Iligan City\', \'INSERT\', \'Message Sent!\', \'dbhsub\')">Send Message</div></div></div>';
echo '<div class = "col-md-12"><div class = "button_positive" onclick = "crud_function(\'employeeid = :employeeid\',\''.$theids.'\',\'Applicants\', \'process_status\', \'Viewed\', \'UPDATE\', \'Successfully Updated!\', \'dbh\')">Mark as Viewed</div>';   
echo '<div class = "button_positive" onclick = "crud_function(\'employeeid = :employeeid\',\''.$theids.'\',\'Applicants\', \'process_status\', \'For Exam\', \'UPDATE\', \'Successfully Updated!\', \'dbh\')">Mark for Exam</div>';
echo '<div class = "button_positive" onclick = "crud_function(\'employeeid = :employeeid\',\''.$theids.'\',\'Applicants\', \'process_status\', \'Hired\', \'UPDATE\', \'Successfully Updated!\', \'dbh\')">Mark as Hired</div></div>';

$data = trim($foo = preg_replace('/\s+/', ' ', $row['process_status']));
echo '<div class = "col-md-12"><h4>
<img src="images/gear_logo.gif" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>
Status: ';
if($data!='' AND isset($data)){
echo ''.$row['process_status'].'</h4></div>';
}else{
echo 'None</h4></div>';
}

}else{
echo 
'                <div class = "button_positive" onclick = "editprofile()">Edit Profile</div>
                <div class = "button_positive" onclick = "rejobapply()">Job Application</div>
                   <div class = "button_positive" onclick = "viewpdfen()">View Application</div>';
if (file_exists($filename)) {
                   echo '<div class = "button_positive" onclick = "mypdf(\''.$pdfname.'\')">View Credentials/Resume</div>';}
                echo '';
if (file_exists($filename)) {

echo '<form class = "sagara" action="php/uploadfile.php?thislove='.strip_tags($row['lastname']).', '.strip_tags($row['firstname']).' '.strip_tags($row['middle']).'" method ="post" enctype = "multipart/form-data" target = "uploadTarget"><p id = "uploadForm"><br/><label>';
echo '      
  <img src="images/check.png" class = "img-responsive" alt="image test" style = "position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  float: left;
  height: 25px;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>
';
echo'Upload Credentials/Resume PDF: <input name = "myfile" type = "file" size = "30"/></label></p><input id = "saela" type = "submit" name = "submitBtn" class = "button_positive" value = "Replace"/></form>';
}else{
echo '
<form class = "sagara" action="php/uploadfile.php?thislove='.strip_tags($row['lastname']).', '.strip_tags($row['firstname']).' '.strip_tags($row['middle']).'" method ="post" enctype = "multipart/form-data" target = "uploadTarget"><p id = "uploadForm"><br/><label>Upload Credentials/Resume PDF: <input name = "myfile" type = "file" size = "30"/></label></p><input id = "saela" type = "submit" name = "submitBtn" class = "button_positive" value = "Submit"/></form>';    
}
}
 echo '</div>';
}
echo '<div id="menu4" class="tab-pane fade">';

if(isset($_GET['adminview'])){
echo '
<div class = "no_lining_standard_margin"><a style = "text-decoration:none; cursor:pointer;" onclick = "reto(\'overview\')">
 <img class = "img-responsive" src="images/return_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
Back</a></div>
<div id = "file_application">
</div>
';
}else{
echo'<div id = "file_application">
</div>';
}
echo '</div>'     
?>