<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$ok = $_GET['idea'];
	$statement = $dbhsub -> query("SELECT * FROM covertitleimage WHERE imageid = '$ok'");
	while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
      // [newscontentid]
      // ,[newsid]
      // ,[description]
      // ,[type]
      // ,[sizeposition]
      // ,[imagepath]
      // ,[dateuploaded]

      // [newsid]
      // ,[title]
      // ,[type]
      // ,[sizeposition]
      // ,[dateuploaded]
      // ,[publisher]

    echo '<div class = "container">';
    if($row['sizeposition'] == 'half'){
    echo '<div class = "col-md-6" onclick = "optionmain('.$row['imageid'].')" style = "cursor:pointer;">';}else{
    echo '<div class = "col-md-12" onclick = "optionmain('.$row['imageid'].')" style = "cursor:pointer;">';     
    }
           $fulldesc = str_replace("hexor", "normalize", $row['imagetitle']);

         echo '<h1 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h1>';
         echo '<h4>Uploaded on '.$row['dateuploaded'].'</h4>';
echo'</div>';

	}

  $statement = $dbhsub -> query("SELECT * FROM coverextender WHERE imageid = '$ok' ORDER BY prioritycode ASC, dateuploaded DESC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
 



  if($row['sizeposition']=='half'||$row['sizeposition']=='halfl'){
  echo '<div class = "col-md-6" onclick = "optionsub('.$row['extenderid'].')" style = "cursor:pointer;">';}else{
  echo '<div class = "col-md-12" onclick = "optionsub('.$row['extenderid'].')" style = "cursor:pointer;">';  
  }
    if($row['type'] == 'none'){
  echo ' <img ';
if($row['sizeposition']=='half'||$row['sizeposition']=='full'){
  echo 'class = "imgvsm"';
}elseif($row['sizeposition']=='halfl'||$row['sizeposition']=='fullt'){
  echo 'class = "imgvlg"';
}
  echo ' id="frontimagedesign" src="../images/coverimages/'.$row['extenderid'].'.png" alt="image test" style = "background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);';
echo 'width: 100%;

           " />';}

           $fulldesc = str_replace("hexor", "normalize", $row['description']);
           if($row['type'] == 'paragraph'){
         
         echo '<p style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</p>';
       }elseif($row['type'] == 's1'){
         echo '<h1 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h1>';      
         }
         elseif($row['type'] == 's2'){
         echo '<h2 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h2>';      
         }
         elseif($row['type'] == 's3'){
         echo '<h3 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h3>';      
         }
         elseif($row['type'] == 's4'){
         echo '<h4 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h4>';      
         }
         elseif($row['type'] == 's5'){
         echo '<h5 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h5>';      
         }
         elseif($row['type'] == 's6'){
         echo '<h6 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h6>';      
         }
echo'</div>';


  }
  echo '</div>';
?>



        