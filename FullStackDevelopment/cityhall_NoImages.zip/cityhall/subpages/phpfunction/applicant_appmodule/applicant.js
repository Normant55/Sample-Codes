function upload_file_applicant(){
    // document.getElementById("uploadpictureb").style.display = "block"
    document.getElementById("coverreplacer").style.display = "block";
    // document.getElementById("thepic").style.display = "none";
}
function initialize_applicant_file(admin){
$.post("subpages/phpfunction/applicant_appmodule/file_list.php", 
           //Required URL of the page on server
          	{ // Data Sending With Request To Server
            	startmonthtoolkit:startmonthtoolkit,
            	startdaytoolkit:startdaytoolkit,
            	enddaytoolkit:enddaytoolkit,
            	endyeartoolkit:endyeartoolkit,
            	startyeartoolkit:startyeartoolkit,
            	endmonthtoolkit:endmonthtoolkit,
            	searchkeyword:searchkeyword,
            	item_ranking_first:item_ranking_first,
            	item_ranking_last:item_ranking_last,
              my_file_category_view:my_file_category_view,
            	theid:theid,
            	admin:admin
           },
           function(response,status){ // Required Callback Function
                //alert("*----Received Data----*nnResponse : " + response+"nnStatus : " + status);
                //"response" receives - whatever written in echo of above PHP script.
                // $("#form")[0].reset();
           		document.getElementById("file_application").innerHTML = response;
           		function return_typefile(data){
                	write_html = 'Choose Category: ';
                    write_html = write_html+select_maker(data, 'my_file_category_applicant');
                    // button_html = '<div class = "dashuploader" id ="coverreplacer" style = "float: left;"><div class="main" id = "coverup"><hr><form id="coverimagingb" action="" method="post" enctype="multipart/form-data"><div id="image_previewreplacerb"><img id="previewingreplacerb" src="noimage.png" /></div><hr id="line"><div id="selectImage"><label>Select Your Image</label><br/><input type="file" name="file" id="filereplacerb" required /><input type="submit" value="Add Photo" id ="replacerbutton" class="submit" /></div></form></div><div id="messagereplacerb"></div></div>'+write_html+'';
                    if(admin == 'no'){
                    $('.type_file_upload_applicant').html(write_html);
                    }
                    new_write_html = 'Choose Category: ';
                    new_write_html = new_write_html+select_maker_function(data, 'my_file_category_view', 'searchengine_file_applicant('+theid+',\''+admin+'\');', my_file_category_view);
                    $('.type_file_view_applicant').html(new_write_html);
           		}
           search_query('is_fixed = 1', '[biosub].[dbo].[file_category]', 'file_category_id*-, description', '', '', 'select_allby', '', 'dbhsub', return_typefile);
 		   }
 );
}
      function applicantshow_admin(id){
           searchkeyword = window.localStorage.getItem("searchkeyword");
           item_ranking_first =window.localStorage.getItem("item_ranking_first");
           item_ranking_last = window.localStorage.getItem("item_ranking_last");
           my_file_category_view =window.localStorage.getItem("my_file_category_view");
           theid = id;
           initialize_applicant_file('yes');
      }