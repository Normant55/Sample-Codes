                function searchengine_file_applicant(newid, admin){
                 searchkeyword = document.getElementById("searchkeyword").value;
                 item_ranking_first = document.getElementById("item_ranking_first").value;
                 item_ranking_last = document.getElementById("item_ranking_last").value;
                  theid = newid;
                  startmonthtoolkit = document.getElementById("startmonth").value;
                  startdaytoolkit = document.getElementById("startday").value;
                  startyeartoolkit = document.getElementById("startyear").value;
                  endmonthtoolkit = document.getElementById("endmonth").value;
                  enddaytoolkit = document.getElementById("endday").value;
                  endyeartoolkit = document.getElementById("endyear").value;
                  my_file_category_view = document.getElementById("my_file_category_view").value;
        if(searchkeyword != ''){
           $.post("subpages/phpfunction/applicant_appmodule/file_searchengine.php", 
           //Required URL of the page on server
           { // Data Sending With Request To Server
            startmonthtoolkit:startmonthtoolkit,
            startdaytoolkit:startdaytoolkit,
            enddaytoolkit:enddaytoolkit,
            endyeartoolkit:endyeartoolkit,
            startyeartoolkit:startyeartoolkit,
            endmonthtoolkit:endmonthtoolkit,
            searchkeyword:searchkeyword,
            item_ranking_first:item_ranking_first,
            item_ranking_last:item_ranking_last,
            my_file_category_view:my_file_category_view,
            theid:theid,
            admin:admin
           },
           function(response,status){ // Required Callback Function
                //alert("*----Received Data----*nnResponse : " + response+"nnStatus : " + status);
                //"response" receives - whatever written in echo of above PHP script.
                // $("#form")[0].reset();
                document.getElementById("files_box_applicant").innerHTML = response;
                function return_typefile(data){
                    write_html = 'Choose Category: ';
                    write_html = write_html+select_maker(data, 'my_file_category_applicant');
                    // button_html = '<div class = "dashuploader" id ="coverreplacer" style = "float: left;"><div class="main" id = "coverup"><hr><form id="coverimagingb" action="" method="post" enctype="multipart/form-data"><div id="image_previewreplacerb"><img id="previewingreplacerb" src="noimage.png" /></div><hr id="line"><div id="selectImage"><label>Select Your Image</label><br/><input type="file" name="file" id="filereplacerb" required /><input type="submit" value="Add Photo" id ="replacerbutton" class="submit" /></div></form></div><div id="messagereplacerb"></div></div>'+write_html+'';
                    if(admin == 'no'){
                    $('.type_file_upload_applicant').html(write_html);
                    }
                    new_write_html = 'Choose Category: ';
                    new_write_html = new_write_html+select_maker_function(data, 'my_file_category_view', 'searchengine_file_applicant('+theid+',\''+admin+'\');', my_file_category_view);
                    $('.type_file_view_applicant').html(new_write_html);
                }
                search_query('is_fixed = 1', '[biosub].[dbo].[file_category]', 'file_category_id*-, description', '', '', 'select_allby', '', 'dbhsub', return_typefile);
           });
}else{
           $.post("subpages/phpfunction/applicant_appmodule/file_list.php", 
           //Required URL of the page on server
           { // Data Sending With Request To Server
            startmonthtoolkit:startmonthtoolkit,
            startdaytoolkit:startdaytoolkit,
            enddaytoolkit:enddaytoolkit,
            endyeartoolkit:endyeartoolkit,
            startyeartoolkit:startyeartoolkit,
            endmonthtoolkit:endmonthtoolkit,
            searchkeyword:searchkeyword,
            item_ranking_first:item_ranking_first,
            item_ranking_last:item_ranking_last,
            my_file_category_view:my_file_category_view,
            theid:theid,
            admin:admin
           },
           function(response,status){ // Required Callback Function
                //alert("*----Received Data----*nnResponse : " + response+"nnStatus : " + status);
                //"response" receives - whatever written in echo of above PHP script.
                // $("#form")[0].reset();
                document.getElementById("file_application").innerHTML = response;
                function return_typefile(data){
                    write_html = 'Choose Category: ';
                    write_html = write_html+select_maker(data, 'my_file_category_applicant');
                    // button_html = '<div class = "dashuploader" id ="coverreplacer" style = "float: left;"><div class="main" id = "coverup"><hr><form id="coverimagingb" action="" method="post" enctype="multipart/form-data"><div id="image_previewreplacerb"><img id="previewingreplacerb" src="noimage.png" /></div><hr id="line"><div id="selectImage"><label>Select Your Image</label><br/><input type="file" name="file" id="filereplacerb" required /><input type="submit" value="Add Photo" id ="replacerbutton" class="submit" /></div></form></div><div id="messagereplacerb"></div></div>'+write_html+'';
                    if(admin == 'no'){
                    $('.type_file_upload_applicant').html(write_html);
                    }
                    new_write_html = 'Choose Category: ';
                    new_write_html = new_write_html+select_maker_function(data, 'my_file_category_view', 'searchengine_file_applicant('+theid+',\''+admin+'\');', my_file_category_view);
                    $('.type_file_view_applicant').html(new_write_html);
                }
                search_query('is_fixed = 1', '[biosub].[dbo].[file_category]', 'file_category_id*-, description', '', '', 'select_allby', '', 'dbhsub', return_typefile);
           });
}
                }
              

                function file_color_applicant(highlight){
                  document.getElementById("f_n"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("f_c"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("f_s"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("d_u"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("f_t"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                }

                function file_uncolor_applicant(highlight){
                  document.getElementById("f_n"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("f_c"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("f_s"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("d_u"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("f_t"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                }

                function file_color_sub_applicant(highlight){
                  document.getElementById("sr_ri"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_ltt"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_la"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_df"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_dt"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_lst"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_dal"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_dav"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_hda"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  // document.getElementById("sr_hdp"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("sr_r"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                }

                function file_uncolor_sub_applicant(highlight){
                  document.getElementById("sr_ri"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_ltt"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_la"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_df"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_dt"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_lst"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_dal"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_dav"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_hda"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  // document.getElementById("sr_hdp"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("sr_r"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                }

                function delete_file_applicant(targetid, newid, admin){
                  if(confirm("Are you sure you want to delete the item?")){
                    var xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function(){
                      if(this.readyState == 4 && this.status == 200) {
                          alert(this.responseText);
                          searchengine_file_applicant(newid, admin);
                      } 
                    };
                    xmlhttp.open("GET", "subpages/phpfunction/files_appmodule/delete.php?deletevalue="+targetid, true);
                    xmlhttp.send();
                  }
                }

                function deleteselected_file_applicant(newid, admin){
                  if(confirm("Are you sure you want to delete the selected?")){
                    mashael_file_applicant = window.localStorage.getItem("mashael_file_applicant");
                    mashael_file_applicant = mashael_file_applicant.slice(0, -1);
                    var xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function(){
                      if(this.readyState == 4 && this.status == 200){
                        window.localStorage.setItem("mashael_file_applicant", "");
                        alert(this.responseText);
                        searchengine_file_applicant(newid, admin);
                      }
                    };
                    xmlhttp.open("GET", "subpages/phpfunction/files_appmodule/deletebulk.php?deletevalue="+mashael_file_applicant, true);
                    xmlhttp.send();
                  }
                }

                function file_checkbox_applicant(thisa){
                if(document.getElementById("file_mycheck_applicant"+thisa).checked === true){
                  mashael_file_applicant = window.localStorage.getItem("mashael_file_applicant");
                  window.localStorage.setItem("mashael_file_applicant", mashael_file_applicant+thisa+",");
                  mashael_file_applicant = window.localStorage.getItem("mashael_file_applicant");
                }else{
                  mashael_file_applicant = window.localStorage.getItem("mashael_file_applicant");
                  tempshell_inbox = ","+mashael_file_applicant;
                  mashael_file_applicant = tempshell_inbox.replace(","+thisa+",", ",");
                  mashael_file_applicant = mashael_file_applicant.substr(1);
                  window.localStorage.setItem("mashael_file_applicant", mashael_file_applicant);
                }
                }

                function file_tick_applicant(){
                    theid = window.localStorage.getItem("loginid");
                    time_pick = document.getElementById('time_pick').value;
                    date_from = document.getElementById('date_from').value;
                    date_to = document.getElementById('date_to').value;
                    date_text = ''+date_from;
                    if(date_from != date_to){
                    date_text = ''+date_from+' to '+date_to;
                    }
                    flag_text = 'w';
                    wholeday_flag = 0;
                    halfday_AM_flag = 0;
                    halfday_PM_flag = 0;
                    if(time_pick == 0){
                      wholeday_flag = 1;
                      flag_text = 'w';
                    }else if(time_pick == 1){
                      halfday_AM_flag = 1;
                      flag_text = 'AM';
                    }else if(time_pick == 2){
                      halfday_PM_flag = 1;
                      flag_text = 'PM';
                    }
                    overall_text = date_text+''+flag_text;

                  function return_countdata(data){
                    amount = data;
                    if(amount!=0){
                      function return_latest_id(data_id){
                        var data_id = data_id.substring(0, data_id.length - 2);
                        crud_function('','','[LGU_DEV].[hr].[LEAV_REQ_ITEMS]', 'LEAV_REQNO*-, LEAV_TYPE_ID*-, LEAV_ACCNO*-, DATE_FROM*-, DATE_TO*-, HALF_D_FLG*-, HALF_D_AM*-, HALF_D_PM*-, DAYS_APPLD*-, DAYS_APPVD*-, POSTED_FLG*-, REMARKS*-, LEAV_STAT_ID*-, BY_RANGE', data_id+'*-, '+document.getElementById('my_select').value+'*-, 10'+data_id+'*-, '+document.getElementById('date_from').value+'*-, '+document.getElementById('date_to').value+'*-, '+wholeday_flag+'*-, '+halfday_AM_flag+'*-, '+halfday_PM_flag+'*-, 0*-, 0*-, 0*-, '+overall_text+'*-, 5*-, 0', 'INSERT', 'Successfully Added Leave Data!', 'dbh_leave');
                      }
                      search_query('EMP_ID=:EMP_ID AND LEAV_STAT_ID = 5 AND CONVERT(VARCHAR(10),LEAV_REQDT,101)=CONVERT(VARCHAR(10),GETDATE(),101)', '[LGU_DEV].[hr].[LEAV_REQ_HEADER]', 'LEAV_REQNO', ''+theid, '', 'select_allby', '', 'dbh_leave', return_latest_id);
                    }else{
                      crud_function_preset('','','LEAV_REQNO*-, LEAV_REQDT','(SELECT MAX(LEAV_REQNO) + 1 AS Result FROM [LGU_DEV].[hr].[LEAV_REQ_HEADER])*-, GETDATE()','[LGU_DEV].[hr].[LEAV_REQ_HEADER]', 'EMP_ID*-, LEAV_STAT_ID*-, VL_FLG*-, SL_FLG*-, COM_FLG', ''+theid+'*-, 5*-, 0*-, 0*-, 0 ', 'INSERT', 'Successfully Added New Header!', 'dbh_leave');
                      function return_latest_id(data_id){
                        var data_id = data_id.substring(0, data_id.length - 2);
                        crud_function('','','[LGU_DEV].[hr].[LEAV_REQ_ITEMS]', 'LEAV_REQNO*-, LEAV_TYPE_ID*-, LEAV_ACCNO*-, DATE_FROM*-, DATE_TO*-, HALF_D_FLG*-, HALF_D_AM*-, HALF_D_PM*-, DAYS_APPLD*-, DAYS_APPVD*-, POSTED_FLG*-, REMARKS*-, LEAV_STAT_ID*-, BY_RANGE', data_id+'*-, '+document.getElementById('my_select').value+'*-, 10'+data_id+'*-, '+document.getElementById('date_from').value+'*-, '+document.getElementById('date_to').value+'*-, '+wholeday_flag+'*-, '+halfday_AM_flag+'*-, '+halfday_PM_flag+'*-, 0*-, 0*-, 0*-, '+overall_text+'*-, 5*-, 0', 'INSERT', 'Successfully Added Leave Data!', 'dbh_leave');
                      }
                      search_query('EMP_ID=:EMP_ID AND LEAV_STAT_ID = 5 AND CONVERT(VARCHAR(10),LEAV_REQDT,101)=CONVERT(VARCHAR(10),GETDATE(),101)', '[LGU_DEV].[hr].[LEAV_REQ_HEADER]', 'LEAV_REQNO', ''+theid, '', 'select_allby', '', 'dbh_leave', return_latest_id);
                    }
                  }
                  search_query('EMP_ID=:EMP_ID AND LEAV_STAT_ID = 5 AND CONVERT(VARCHAR(10),LEAV_REQDT,101)=CONVERT(VARCHAR(10),GETDATE(),101)', '[LGU_DEV].[hr].[LEAV_REQ_HEADER]', '', ''+theid+'', '', 'countallby', '', 'dbh_leave', return_countdata);
                }

                function file_sub_leave_applicant(id_delete){
                  if(confirm("Would you like to delete the selected?")){
                    crud_function('ROW_ID=:ROW_ID', ''+id_delete, '[LGU_DEV].[hr].[LEAV_REQ_ITEMS]', '', '', 'DELETE', 'Successfully Deleted the Data', 'dbh_leave');
                  }
                }

                function file_sub_checkbox_applicant(thisa_sub){
                if(document.getElementById("leave_sub_mycheck"+thisa_sub).checked === true){
                  mashael_file_applicant_sub = window.localStorage.getItem("mashael_file_applicant_sub");
                  window.localStorage.setItem("mashael_file_applicant_sub", mashael_file_applicant_sub+thisa_sub+",");
                  mashael_file_applicant_sub = window.localStorage.getItem("mashael_file_applicant_sub");
                }else{
                  mashael_file_applicant_sub = window.localStorage.getItem("mashael_file_applicant_sub");
                  tempshell_ls = ","+mashael_file_applicant_sub;
                  mashael_file_applicant_sub = tempshell_ls.replace(","+thisa_sub+",", ",");
                  mashael_file_applicant_sub = mashael_file_applicant_sub.substr(1);
                  window.localStorage.setItem("mashael_file_applicant_sub", mashael_file_applicant_sub);
                }
                }

                function deleteselected_file_sub_applicant(){
                    mashael_file_applicant_sub = window.localStorage.getItem("mashael_file_applicant_sub");
                    mashael_file_applicant_sub = mashael_file_applicant_sub.slice(0, -1);
                    var xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function(){
                      if(this.readyState == 4 && this.status == 200){
                        alert(this.responseText);
                        window.localStorage.setItem("mashael_file_applicant_sub", "");
                        searchengine_leave();
                      }
                    };
                    xmlhttp.open("GET", "subpages/phpfunction/files_appmodule/deletebulk_sub.php?deletevalue="+mashael_file_applicant_sub, true);
                    xmlhttp.send();
                }             