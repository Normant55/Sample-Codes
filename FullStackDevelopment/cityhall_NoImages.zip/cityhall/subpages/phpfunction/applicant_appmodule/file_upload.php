<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../../php/connectPDO.php");
$my_file_category = $_GET['my_file_category'];
$theid = $_GET['theid'];
if(isset($_FILES["file"]["type"]))
{
$validextensions = array("pdf");
$temporary = explode(".", $_FILES["file"]["name"]);
$file_extension = end($temporary);
if ((($_FILES["file"]["type"] == "application/pdf") && ($_FILES["file"]["size"] < 400000000)) && in_array($file_extension, $validextensions)) {
if ($_FILES["file"]["error"] > 0)
{
echo "Return Code: " . $_FILES["file"]["error"] . "<br/><br/>";
}
else
{
$filename = $_FILES["file"]["name"];
$filepath = "../../../images/files/".$theid."/".$filename;
$filename_overall = $theid."/".$filename;
// if (!file_exists('http://79.125.201.223:8080/cityhall/images/files/'.$theid)) {
//     mkdir('http://79.125.201.223:8080/cityhall/images/files/'.$theid, 0777, true);
// }
$dir_name ='../../../images/files/'.$theid.'/';

//Check if the directory with the name already exists
if (!is_dir($dir_name)) {
//Create our directory if it does not exist
mkdir($dir_name,  0755, true);
}

$statement_count = $dbhsub -> prepare("Select count(*) FROM [biosub].[dbo].[file_main] WHERE [name] = :file_name");
$statement_count -> bindParam(":file_name", $filename_overall);
$statement_count -> execute();
$total_count = $statement_count->fetchColumn();

if($total_count == 0){
$query = "INSERT INTO [biosub].[dbo].[file_main]VALUES('$filename_overall', '$filepath', $my_file_category, 1, $theid, 2, GETDATE())";
$statement = $dbhsub ->prepare($query);
$statement -> execute();
}

$sourcePath = $_FILES['file']['tmp_name']; // Storing source path of the file in a variable
$targetPath = "../../../images/files/".$theid."/".$_FILES["file"]["name"]; // Target path where file is to be stored
// $temp = explode(".", $_FILES["file"]["name"]);
// $newfilename = round(microtime(true)) . '.' . end($temp);
// move_uploaded_file($_FILES["file"]["tmp_name"], "../img/imageDirectory/" . $newfilename);
move_uploaded_file($sourcePath,$targetPath) ; // Moving Uploaded file
echo "Image Uploaded Successfully...!!";
// echo "<br/><b>File Name:</b> " . $_FILES["file"]["name"] . "<br>";
echo "<br><b>Type:</b> " . $_FILES["file"]["type"] . "<br>";
echo "<b>Size:</b> " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
 echo "<b>Temp file:</b> " . $_FILES["file"]["tmp_name"] . "<br>";
}
}
else
{
echo "***Invalid file Size or Type;***";
}
}
?>