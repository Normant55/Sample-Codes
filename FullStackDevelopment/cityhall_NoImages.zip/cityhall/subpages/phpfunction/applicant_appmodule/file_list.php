<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../../php/connectPDO.php");
$theid = $_POST['theid'];
$startmonth =  $_POST['startmonthtoolkit'];
$startday =  $_POST['startdaytoolkit'];
$startyear =  $_POST['startyeartoolkit'];
$endmonth =  $_POST['endmonthtoolkit'];
$endday =  $_POST['enddaytoolkit'];
$endyear =  $_POST['endyeartoolkit'];
$searchkeyword = $_POST['searchkeyword'];
$item_ranking_first = $_POST['item_ranking_first'];
$item_ranking_last = $_POST['item_ranking_last'];
$my_file_category_view = $_POST['my_file_category_view'];

$statement_count = $dbhsub -> prepare("SELECT count(*) FROM (SELECT [file_id]
      ,[name]
      ,[path]
      ,A.file_category_id AS file_category_id
      ,D.description AS file_category
      ,C.description AS file_type
      ,[employeeid]
      ,B.description AS file_status
      ,A.date_uploaded AS the_time
      ,CONVERT(VARCHAR(10),date_uploaded, 101) AS date_uploaded,
      ROW_NUMBER() OVER(ORDER BY date_uploaded DESC) AS ranking_id
       FROM [biosub].[dbo].[file_main] AS A INNER JOIN [biosub].[dbo].[file_status] AS B on A.[file_status_id] = B.[file_status_id] INNER JOIN [biosub].[dbo].[file_type] AS C on A.[file_type_id] = C.[file_type_id] INNER JOIN [biosub].[dbo].[file_category] AS D on A.[file_category_id] = D.[file_category_id]) AS FINAL WHERE the_time between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' AND file_category_id = '$my_file_category_view' AND [employeeid] = '$theid'");
$statement_count -> execute();
$total_count = $statement_count->fetchColumn();

if(isset($item_ranking_first) AND $item_ranking_first != '' AND isset($item_ranking_last) AND $item_ranking_last != ''){
$statement = $dbhsub -> prepare("SELECT * FROM (SELECT [file_id]
      ,[name]
      ,[path]
      ,A.file_category_id AS file_category_id
      ,D.description AS file_category
      ,C.description AS file_type
      ,[employeeid]
      ,B.description AS file_status
      ,A.date_uploaded AS the_time
      ,CONVERT(VARCHAR(10),date_uploaded, 101) AS date_uploaded,
      ROW_NUMBER() OVER(ORDER BY date_uploaded DESC) AS ranking_id
       FROM [biosub].[dbo].[file_main] AS A INNER JOIN [biosub].[dbo].[file_status] AS B on A.[file_status_id] = B.[file_status_id] INNER JOIN [biosub].[dbo].[file_type] AS C on A.[file_type_id] = C.[file_type_id] INNER JOIN [biosub].[dbo].[file_category] AS D on A.[file_category_id] = D.[file_category_id]) AS FINAL WHERE (ranking_id BETWEEN :item_ranking_first AND :item_ranking_last) AND the_time between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND file_category_id = '$my_file_category_view' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' AND [employeeid] = '$theid' ORDER BY ranking_id ASC");
$statement -> bindParam(':item_ranking_first', $item_ranking_first, PDO::PARAM_INT);
$statement -> bindParam(':item_ranking_last', $item_ranking_last, PDO::PARAM_INT);
}else{
$statement = $dbhsub -> prepare("SELECT * FROM (SELECT [file_id]
      ,[name]
      ,[path]
      ,A.file_category_id AS file_category_id
      ,D.description AS file_category
      ,C.description AS file_type
      ,[employeeid]
      ,B.description AS file_status
      ,A.date_uploaded AS the_time
      ,CONVERT(VARCHAR(10),date_uploaded, 101) AS date_uploaded,
      ROW_NUMBER() OVER(ORDER BY date_uploaded DESC) AS ranking_id
       FROM [biosub].[dbo].[file_main] AS A INNER JOIN [biosub].[dbo].[file_status] AS B on A.[file_status_id] = B.[file_status_id] INNER JOIN [biosub].[dbo].[file_type] AS C on A.[file_type_id] = C.[file_type_id] INNER JOIN [biosub].[dbo].[file_category] AS D on A.[file_category_id] = D.[file_category_id]) AS FINAL WHERE (ranking_id BETWEEN 1 AND 15) AND  the_time between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' AND file_category_id = '$my_file_category_view' AND [employeeid] = '$theid' ORDER BY ranking_id ASC");
}
$statement -> execute();
  echo '
  <div class = "col-md-12" style = "margin-top: 0%;">
  <h3>Search File</h3>
  <div class = "col-md-4">
  File
  <input type = "text" class = "input_standard" onkeyup = "searchengine_file_applicant('.$theid.',\''.$_POST['admin'].'\')" id ="searchkeyword"';if($searchkeyword!=''){echo'value = "'.$searchkeyword.'"';} echo' placeholder = "Search Keyword..." style = "width: 100%;">
  </div>';
  echo '<div class = "col-md-2">
  Display Min <input type = "number" class = "input_standard"';if($item_ranking_first!=''){echo'value = "'.$item_ranking_first.'"';} echo' onkeyup = "searchengine_file_applicant('.$theid.',\''.$_POST['admin'].'\')" id ="item_ranking_first" style = "width: 100%;">
  </div>';
  echo '<div class = "col-md-2">
  Display Max <input type = "number" class = "input_standard"';if($item_ranking_last!=''){echo'value = "'.$item_ranking_last.'"';} echo' onkeyup = "searchengine_file_applicant('.$theid.',\''.$_POST['admin'].'\')" id = "item_ranking_last" style = "width: 100%;">
  </div>
  <div class = "col-md-2 type_file_view_applicant">
  </div>
  </div>';

echo '<div class = "col-xs-12"><div class = "datesectorover" style = "margin-bottom:20px;">';
echo '<div class = "datesector">';
echo '<div class = "markword col-xs-12 col-md-2 col-lg-2">Starting Date</div>';
echo '<div class = "markwordd">Month</div> <select id = "startmonth" onchange = "searchengine_file_applicant('.$theid.',\''.$_POST['admin'].'\')">
<option value = 1 ';if($startmonth == 1){echo'selected';}echo'>January</option>
<option value = 2 ';if($startmonth == 2){echo'selected';}echo'>Febuary</option>
<option value = 3 ';if($startmonth == 3){echo'selected';}echo'>March</option>
<option value = 4 ';if($startmonth == 4){echo'selected';}echo'>April</option>
<option value = 5 ';if($startmonth == 5){echo'selected';}echo'>May</option>
<option value = 6 ';if($startmonth == 6){echo'selected';}echo'>June</option>
<option value = 7 ';if($startmonth == 7){echo'selected';}echo'>July</option>
<option value = 8 ';if($startmonth == 8){echo'selected';}echo'>August</option>
<option value = 9 ';if($startmonth == 9){echo'selected';}echo'>September</option>
<option value = 10 ';if($startmonth == 10){echo'selected';}echo'>October</option>
<option value = 11 ';if($startmonth == 11){echo'selected';}echo'>November</option>
<option value = 12 ';if($startmonth == 12){echo'selected';}echo'>December</option>
</select>';
echo '<div class = "markwordd">Day</div> <select id ="startday" onchange = "searchengine_file_applicant('.$theid.',\''.$_POST['admin'].'\')">';
for($x=1; $x<=31; $x++){
  echo '<option value = '.$x.' ';if($startday == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markwordd">Year</div> <select id ="startyear" onchange = "searchengine_file_applicant('.$theid.',\''.$_POST['admin'].'\')">';
for($x=1990; $x<=2030; $x++){
  echo '<option value = '.$x.' ';if($startyear == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markword col-xs-12 col-md-1 col-lg-1"> ----- </div>';
echo '<div class = "markwordd">Month</div> <select id = "endmonth" onchange = "searchengine_file_applicant('.$theid.',\''.$_POST['admin'].'\')">
<option value = 1 ';if($endmonth == 1){echo'selected';}echo'>January</option>
<option value = 2 ';if($endmonth == 2){echo'selected';}echo'>Febuary</option>
<option value = 3 ';if($endmonth == 3){echo'selected';}echo'>March</option>
<option value = 4 ';if($endmonth == 4){echo'selected';}echo'>April</option>
<option value = 5 ';if($endmonth == 5){echo'selected';}echo'>May</option>
<option value = 6 ';if($endmonth == 6){echo'selected';}echo'>June</option>
<option value = 7 ';if($endmonth == 7){echo'selected';}echo'>July</option>
<option value = 8 ';if($endmonth == 8){echo'selected';}echo'>August</option>
<option value = 9 ';if($endmonth == 9){echo'selected';}echo'>September</option>
<option value = 10 ';if($endmonth == 10){echo'selected';}echo'>October</option>
<option value = 11 ';if($endmonth == 11){echo'selected';}echo'>November</option>
<option value = 12 ';if($endmonth == 12){echo'selected';}echo'>December</option>
</select>';
echo '<div class = "markwordd">Day</div> <select id ="endday" onchange = "searchengine_file_applicant('.$theid.',\''.$_POST['admin'].'\')">';
for($x=1; $x<=31; $x++){
  echo '<option value = '.$x.' ';if($endday == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '<div class = "markwordd">Year</div> <select id ="endyear" onchange = "searchengine_file_applicant('.$theid.',\''.$_POST['admin'].'\')">';
for($x=1990; $x<=2030; $x++){
  echo '<option value = '.$x.' ';if($endyear == $x){echo'selected';}echo'>'.$x.'</option>';
}
echo '</select>';
echo '</div></div>';
  echo'<div class = "col-md-12 standard_margin">
  <div class = "col-md-12">';
  
  if($_POST['admin']=='no'){
  echo'<div class = "word_button_sky" style = "cursor: pointer; display: inline-flex; line-height: 30px;"
  onclick = "upload_file_applicant()">
  <img class = "img-responsive" src="images/email.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />File Upload</div>';
  }

  echo '<div class = "word_button_sky" style = "cursor: pointer; display: inline-flex; line-height: 30px;" onclick = "selectall()">
  <img class = "img-responsive" src="images/logo_add.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />Select All</div>

  <div class = "word_button_sky" style = "cursor: pointer; display: inline-flex; line-height: 30px;" onclick = "deleteselected_file_applicant('.$theid.',\''.$_POST['admin'].'\')">
  <img class = "img-responsive" src="images/delete.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />Delete</div>

  </div>
  <div class = "col-md-12 collapse" id="demo_file">
  <div class = "col-md-12 type_file_forms" style = "word-wrap: break-word;"></div>
  <div class = "col-md-12 type_file" style = "word-wrap: break-word;"></div>
  </div>
  </div>
  </div>

  <div class = "col-md-1 passerbiga"></div>
  <div class = "col-md-11">
  <div class = "col-md-4 passerbiga">Name</div>
  <div class = "col-md-2 passerbiga">Category</div>
  <div class = "col-md-2 passerbiga">Status</div>
  <div class = "col-md-2 passerbiga">Date Uploaded</div>
  <div class = "col-md-2 passerbiga">Type</div> 
  </div>
  <div id = "files_box_applicant">
  ';
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
  echo '<div class = "col-md-12">';
	echo '<div onmouseover = "file_color_applicant('.$row['file_id'].')" onmouseout = "file_uncolor_applicant('.$row['file_id'].')" style = "cursor:pointer;">
  ';
  echo '<div class = "col-md-1 passerbigs"><input type="checkbox" id = "file_mycheck_applicant'.$row['file_id'].'" onclick="file_checkbox_applicant('.$row['file_id'].')"></div>';
  echo '<div class = "col-md-11" href="#demo'.$row['file_id'].'" data-toggle="collapse">
  ';
	echo '<div class = "col-md-4 passerbigs font_eye_catch font_eye_fast" id = "f_n'.$row['file_id'].'">'.$row['name'].'</div>';
	echo '<div class = "col-md-2 passerbigs font_eye_catch font_eye_fast" id = "f_c'.$row['file_id'].'">'.$row['file_category'].'</div>';
  echo '<div class = "col-md-2 passerbigs font_eye_catch font_eye_fast" id = "f_s'.$row['file_id'].'">'.$row['file_status'].'</div>';
  echo '<div class = "col-md-2 passerbigs font_eye_catch font_eye_fast" id = "d_u'.$row['file_id'].'">'.$row['date_uploaded'].'</div>';
	echo '<div class = "col-md-2 passerbigs font_eye_catch font_eye_fast" id = "f_t'.$row['file_id'].'">'.$row['file_type'].'</div>';
	echo '</div>';
	echo '
  </div>';
  echo '
  <div class = "col-md-12 collapse standard_margin_side standard_margin" id="demo'.$row['file_id'].'">
  <div class = "col-md-12">
  <a href = "http://79.125.201.223:8080/cityhall/images/files/'.$row['name'].'" target="_blank" class = "word_button_sky" style = "cursor: pointer; text-decoration:none;">
  <img class = "img-responsive" src="images/status_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
  Open</a>
  <a class = "word_button_sky" style = "cursor: pointer; text-decoration:none;" onclick = "delete_file_applicant('.$row['file_id'].', '.$theid.',\''.$_POST['admin'].'\')">
  <img class = "img-responsive" src="images/delete.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
  Delete</a>
  </div>
  </div>
  </div>
  ';
}

  if(isset($item_ranking_first) AND $item_ranking_first != '' AND isset($item_ranking_last) AND $item_ranking_last != ''){
  echo '<div class = "col-md-12" style = "margin-top: 0%;">
  Displaying items <b>Ranking: '.$item_ranking_first.'</b> to <b>'.$item_ranking_last.'</b> out of <b>Total: '.$total_count.'</b>
  </div>';
  }else{
  echo '<div class = "col-md-12" style = "margin-top: 0%;">
  Displaying all items from <b>1</b> to <b>15</b> out of <b>Total: '.$total_count.'</b>
  </div>';    
  }
  echo '</div>';

  // echo '
  // <a class = "word_button_sky" style = "cursor:pointer; text-decoration: none;" onclick = "crud_function_preset(\'\',\'\',\'LEAV_REQNO*-, LEAV_REQDT\',\'(SELECT MAX(LEAV_REQNO) + 1 AS Result FROM [LGU_DEV].[hr].[LEAV_REQ_HEADER])*-, GETDATE()\',\'[LGU_DEV].[hr].[LEAV_REQ_HEADER]\', \'EMP_ID*-, LEAV_STAT_ID*-, VL_FLG*-, SL_FLG*-, COM_FLG\', \''.$theid.'*-, 5*-, 0*-, 0*-, 0 \', \'INSERT\', \'Successfully Added!\', \'dbh_leave\')">
  // <img class = "img-responsive" src="images/target_logo.png" alt="image test" 
  // style = "
  // position: relative;
  // background-repeat: no-repeat;
  // background-size: 100% 100%;
  // background-position: 20% 50%;
  // background-color: rgba(200,200,200, 0);
  // height: 30px;
  // display: inline-block;
  // " />
  // Add Header</a>
  // ';
?>