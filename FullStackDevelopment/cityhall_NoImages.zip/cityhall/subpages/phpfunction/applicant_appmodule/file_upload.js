$(document).ready(function (e) {
$("#coverimagingb").on('submit',(function(e) {
e.preventDefault();
$("#messagereplacerb").empty();
$('#loading').show();
my_file_category = document.getElementById("my_file_category_applicant").value;
theid = window.localStorage.getItem("loginid");
                  searchkeyword = document.getElementById("searchkeyword").value;
                  item_ranking_first = document.getElementById("item_ranking_first").value;
                  item_ranking_last = document.getElementById("item_ranking_last").value;
                  startmonthtoolkit = document.getElementById("startmonth").value;
                  startdaytoolkit = document.getElementById("startday").value;
                  startyeartoolkit = document.getElementById("startyear").value;
                  endmonthtoolkit = document.getElementById("endmonth").value;
                  enddaytoolkit = document.getElementById("endday").value;
                  endyeartoolkit = document.getElementById("endyear").value;
                  my_file_category_view =window.localStorage.getItem("my_file_category_view");
$.ajax({
url: "http://79.125.201.223:8080/cityhall/subpages/phpfunction/applicant_appmodule/file_upload.php?my_file_category="+my_file_category+"&theid="+theid, // Url to which the request is send
type: "POST",             // Type of request to be send, called as method
data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
contentType: false,       // The content type used when sending data to the server.
cache: false,             // To unable request pages to be cached
processData:false,        // To send DOMDocument or non processed data file it is set to false
success: function(data)   // A function to be called if request succeeds
{
$('#loading').hide();
$("#messagereplacerb").html(data);
admin = 'no';
if(searchkeyword != ''){
           $.post("subpages/phpfunction/applicant_appmodule/file_searchengine.php", 
           //Required URL of the page on server
           { // Data Sending With Request To Server
            startmonthtoolkit:startmonthtoolkit,
            startdaytoolkit:startdaytoolkit,
            enddaytoolkit:enddaytoolkit,
            endyeartoolkit:endyeartoolkit,
            startyeartoolkit:startyeartoolkit,
            endmonthtoolkit:endmonthtoolkit,
            searchkeyword:searchkeyword,
            item_ranking_first:item_ranking_first,
            item_ranking_last:item_ranking_last,
            my_file_category_view:my_file_category_view,
            theid:theid,
            admin:admin
           },
           function(response,status){ // Required Callback Function
                //alert("*----Received Data----*nnResponse : " + response+"nnStatus : " + status);
                //"response" receives - whatever written in echo of above PHP script.
                // $("#form")[0].reset();
                document.getElementById("files_box_applicant").innerHTML = response;
                function return_typefile(data){
                    write_html = 'Choose Category: ';
                    write_html = write_html+select_maker(data, 'my_file_category_applicant');
                    // button_html = '<div class = "dashuploader" id ="coverreplacer" style = "float: left;"><div class="main" id = "coverup"><hr><form id="coverimagingb" action="" method="post" enctype="multipart/form-data"><div id="image_previewreplacerb"><img id="previewingreplacerb" src="noimage.png" /></div><hr id="line"><div id="selectImage"><label>Select Your Image</label><br/><input type="file" name="file" id="filereplacerb" required /><input type="submit" value="Add Photo" id ="replacerbutton" class="submit" /></div></form></div><div id="messagereplacerb"></div></div>'+write_html+'';
                    $('.type_file_upload_applicant').html(write_html);
                }
                search_query('is_fixed = 1', '[biosub].[dbo].[file_category]', 'file_category_id*-, description', '', '', 'select_allby', '', 'dbhsub', return_typefile);
           });
}else{
           $.post("subpages/phpfunction/applicant_appmodule/file_list.php", 
           //Required URL of the page on server
           { // Data Sending With Request To Server
            startmonthtoolkit:startmonthtoolkit,
            startdaytoolkit:startdaytoolkit,
            enddaytoolkit:enddaytoolkit,
            endyeartoolkit:endyeartoolkit,
            startyeartoolkit:startyeartoolkit,
            endmonthtoolkit:endmonthtoolkit,
            searchkeyword:searchkeyword,
            item_ranking_first:item_ranking_first,
            item_ranking_last:item_ranking_last,
            my_file_category_view:my_file_category_view,
            theid:theid,
            admin:admin
           },
           function(response,status){ // Required Callback Function
                //alert("*----Received Data----*nnResponse : " + response+"nnStatus : " + status);
                //"response" receives - whatever written in echo of above PHP script.
                // $("#form")[0].reset();
                document.getElementById("file_application").innerHTML = response;
                function return_typefile(data){
                    write_html = 'Choose Category: ';
                    write_html = write_html+select_maker(data, 'my_file_category_applicant');
                    // button_html = '<div class = "dashuploader" id ="coverreplacer" style = "float: left;"><div class="main" id = "coverup"><hr><form id="coverimagingb" action="" method="post" enctype="multipart/form-data"><div id="image_previewreplacerb"><img id="previewingreplacerb" src="noimage.png" /></div><hr id="line"><div id="selectImage"><label>Select Your Image</label><br/><input type="file" name="file" id="filereplacerb" required /><input type="submit" value="Add Photo" id ="replacerbutton" class="submit" /></div></form></div><div id="messagereplacerb"></div></div>'+write_html+'';
                    $('.type_file_upload_applicant').html(write_html);
                }
                search_query('is_fixed = 1', '[biosub].[dbo].[file_category]', 'file_category_id*-, description', '', '', 'select_allby', '', 'dbhsub', return_typefile);
           });
}








}
});
}));
// Function to preview image after validation
$(function() {
$("#filereplacerb").change(function() {
$("#messagereplacerb").empty(); // To remove the previous error message
var file = this.files[0];
var imagefile = file.type;
var match= ["application/pdf"];
if(!(imagefile==match[0]))
{
$("#messagereplacerb").html("<p id='error'>Please Select A valid Image File</p>"+"<h4>Note</h4>"+"<span id='error_message'>Only PDF file type allowed</span>");
return false;
}
else
{
var reader = new FileReader();
reader.onload = imageIsLoaded;
reader.readAsDataURL(this.files[0]);
}
});
});
// function imageIsLoaded(e) {
// $("#filereplacerb").css("color","green");
// $('#image_previewreplacerb').css("display", "block");
// $('#previewingreplacerb').attr('src', e.target.result);
// $('#previewingreplacerb').attr('width', '250px');
// $('#previewingreplacerb').attr('height', '230px');
// };



});