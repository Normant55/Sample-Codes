<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../../php/connectPDO.php");
$startmonth =  $_GET['startmonthtoolkit'];
$startday =  $_GET['startdaytoolkit'];
$startyear =  $_GET['startyeartoolkit'];
$endmonth =  $_GET['endmonthtoolkit'];
$endday =  $_GET['enddaytoolkit'];
$endyear =  $_GET['endyeartoolkit'];
$status_select = $_GET['status_select'];
$gender_select =  $_GET['gender_select'];
$input_min_age =  $_GET['input_min_age'];
$input_max_age =  $_GET['input_max_age'];

if($gender_select == 1){
$gender_query = 'gender = 1';}elseif($gender_select == 0){
$gender_query = 'gender = 0';}elseif($gender_select == 2){
$gender_query = 'gender = 1 OR gender = 0';
}
if($status_select == 0){
$select_query = 'process_status = \'Hired\'';}
elseif($status_select == 3){
$select_query = 'process_status IS NULL';}
elseif($status_select == 2){
$select_query = 'process_status = \'Viewed\'';}
elseif($status_select == 1){
$select_query = 'process_status = \'For Exam\'';}
elseif($status_select == 4){
$select_query = '1 = 1';
}

if(isset($_GET['searchkeyword']) AND !empty($_GET['searchkeyword'])){
	$searchkeyword = $_GET['searchkeyword'];
$keys = explode(" ", $searchkeyword);
$idfound = array();
$x = 1;
$current = 0;
while($x<2){
	if(isset($keys[$current]) && $keys[$current]!=''){
	$searchthis = $keys[$current];
	$current++;
$statement = $dbh -> prepare("SELECT employeeid, lastname, firstname, middle, job_title, course_degree, eligibility, birthdate, CONVERT(VARCHAR(10),birthdate, 101) AS birthdate, school_grad, date_registered, CONVERT(int, age) AS age FROM Applicants WHERE (lastname LIKE :searchthis9 OR firstname LIKE :searchthis10 OR middle LIKE :searchthis11 OR job_title LIKE :searchthis12 OR eligibility LIKE :searchthis13 OR school_grad LIKE :searchthis14 OR course_degree LIKE :searchthis15 OR home_address LIKE :searchthis16) AND (CONVERT(int, age) >= '$input_min_age' AND CONVERT(int, age) <= '$input_max_age') AND employeeid NOT IN ('".implode(' \', \'', $idfound)."') AND (".$select_query.") AND (".$gender_query.") AND date_registered between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' ORDER BY date_registered DESC");
$statement -> bindValue(':searchthis9', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis10', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis11', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis12', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis13', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis14', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis15', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis16', '%'.$searchthis.'%');
$statement -> execute();
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
array_push($idfound, $row['employeeid']);
	echo '<div onmouseover = "color('.$row['employeeid'].')" onmouseout = "uncolor('.$row['employeeid'].')" style = "cursor:pointer; margin-bottom:50px;" onclick = "applicantshow('.$row['employeeid'].')">';
	echo '<div class = "col-md-12" id = "apall'.$row['employeeid'].'">';
	echo '<div class = "col-md-3 passerbigs phone_bar" id = "apname'.$row['employeeid'].'">'.strip_tags($row['lastname']).', '.strip_tags($row['firstname']).' '.strip_tags($row['middle']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apjob'.$row['employeeid'].'">'.strip_tags($row['job_title']).'</div>';
	echo '<div class = "col-md-3 passerbigs" id = "apgrad'.$row['employeeid'].'">'.strip_tags($row['course_degree']).' '.strip_tags($row['school_grad']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apelig'.$row['employeeid'].'">'.strip_tags($row['eligibility']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apbirth'.$row['employeeid'].'">'.strip_tags($row['date_registered']).'</div>';
	echo '</div></div>';
}
}else{
	$x = 2;
}
}

}else{
$statement = $dbh -> prepare("SELECT employeeid, lastname, firstname, middle, job_title, course_degree, eligibility, birthdate, CONVERT(VARCHAR(10),birthdate, 101) AS birthdate, school_grad, date_registered, CONVERT(int, age) AS age FROM Applicants WHERE (CONVERT(int, age) >= '$input_min_age' AND CONVERT(int, age) <= '$input_max_age') AND date_registered between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' AND (".$select_query.") AND (".$gender_query.") ORDER BY date_registered DESC");
$statement -> execute();
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
	echo '<div onmouseover = "color('.$row['employeeid'].')" onmouseout = "uncolor('.$row['employeeid'].')" style = "cursor:pointer; margin-bottom:50px;" onclick = "applicantshow('.$row['employeeid'].')">';
	echo '<div class = "col-md-12" id = "apall'.$row['employeeid'].'">';
	echo '<div class = "col-md-3 passerbigs phone_bar" id = "apname'.$row['employeeid'].'">'.strip_tags($row['lastname']).', '.strip_tags($row['firstname']).' '.strip_tags($row['middle']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apjob'.$row['employeeid'].'">'.strip_tags($row['job_title']).'</div>';
	echo '<div class = "col-md-3 passerbigs" id = "apgrad'.$row['employeeid'].'">'.strip_tags($row['course_degree']).' '.strip_tags($row['school_grad']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apelig'.$row['employeeid'].'">'.strip_tags($row['eligibility']).'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "apbirth'.$row['employeeid'].'">'.strip_tags($row['date_registered']).'</div>';
	echo '</div></div>
	';
}
}
$data_count = 0;
if(isset($_GET['searchkeyword']) AND !empty($_GET['searchkeyword'])){
	$searchkeyword = $_GET['searchkeyword'];
$keys = explode(" ", $searchkeyword);
$idfound_count = array();
$x = 1;
$current = 0;
while($x<2){
	if(isset($keys[$current]) && $keys[$current]!=''){
	$searchthis = $keys[$current];
	$current++;
$stmt = $dbh -> prepare("SELECT employeeid FROM Applicants WHERE (lastname LIKE :searchthis OR firstname LIKE :searchthis2 OR middle LIKE :searchthis3 OR job_title LIKE :searchthis4 OR eligibility LIKE :searchthis5 OR school_grad LIKE :searchthis6 OR course_degree LIKE :searchthis7 OR home_address LIKE :searchthis8) AND CONVERT(int, age) >= '$input_min_age' AND CONVERT(int, age) <= '$input_max_age' AND employeeid NOT IN ('".implode(' \', \'', $idfound_count)."') AND (".$select_query.") AND (".$gender_query.") AND date_registered between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000'");
$stmt -> bindValue(':searchthis', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis2', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis3', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis4', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis5', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis6', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis7', '%'.$searchthis.'%');
$stmt -> bindValue(':searchthis8', '%'.$searchthis.'%');

$stmt -> execute();
// $add_count = $stmt -> fetchColumn();
while($crow = $stmt -> fetch(PDO::FETCH_ASSOC)){
array_push($idfound_count, $crow['employeeid']);
	$data_count++;
	}
// $data_count = $data_count + $add_count;
}else{
	$x = 2;
}
}
}else{
$stmt = $dbh -> prepare("SELECT employeeid FROM Applicants WHERE CONVERT(int, age) >= '$input_min_age' AND CONVERT(int, age) <= '$input_max_age' AND date_registered between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' AND (".$select_query.") AND (".$gender_query.")");
$stmt -> execute();
// $add_count = $stmt -> fetchColumn();
while($crow = $stmt -> fetch(PDO::FETCH_ASSOC)){
	$data_count++;
	}
// $data_count = $data_count + $add_count;
}
echo '<div class = "keywords_category">Search Count: '.$data_count.'</div>';
?>