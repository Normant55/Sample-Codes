<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
$startmonth =  $_GET['startmonthtoolkit'];
$startday =  $_GET['startdaytoolkit'];
$startyear =  $_GET['startyeartoolkit'];
$endmonth =  $_GET['endmonthtoolkit'];
$endday =  $_GET['enddaytoolkit'];
$endyear =  $_GET['endyeartoolkit'];
$gender_select =  $_GET['gender_select'];
$status_select =  $_GET['status_select'];
$input_min_age =  $_GET['input_min_age'];
$input_max_age =  $_GET['input_max_age'];
if(isset($_GET['searchkeyword']) AND !empty($_GET['searchkeyword'])){
	$searchkeyword = $_GET['searchkeyword'];
echo '<a class = "word_button_sky" href = "php/printapplicant.php?searchkeyword='.$searchkeyword.'&startmonthtoolkit='.$startmonth.'&startdaytoolkit='.$startday.'&startyeartoolkit='.$startyear.'&endmonthtoolkit='.$endmonth.'&enddaytoolkit='.$endday.'&endyeartoolkit='.$endyear.'&gender_select='.$gender_select.'&status_select='.$status_select.'&input_min_age='.$input_min_age.'&input_max_age='.$input_max_age.'" target="_blank" class = "word_button" style = "text-decoration: none; cursror: pointer;">
<img src="images/profile_logo.png" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>
All PDF</a>';
}else{
echo '<a class = "word_button_sky" href = "php/printapplicant.php?&startmonthtoolkit='.$startmonth.'&startdaytoolkit='.$startday.'&startyeartoolkit='.$startyear.'&endmonthtoolkit='.$endmonth.'&enddaytoolkit='.$endday.'&endyeartoolkit='.$endyear.'&gender_select='.$gender_select.'&status_select='.$status_select.'&input_min_age='.$input_min_age.'&input_max_age='.$input_max_age.'" target="_blank" class = "word_button" style = "text-decoration: none; cursror: pointer;">
<img src="images/profile_logo.png" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>
All PDF</a>';
}

?>

