<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$target = $_POST['target'];

  $statement = $dbhsub -> prepare("SELECT TOP 1 newscontentid FROM newsextension WHERE newscontentid = :target");
  $statement->bindParam(':target', $target);
  $statement->execute();
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
echo '  <div class="fullviewimaging">
      	<img src="../images/newsimages/'.$row['newscontentid'].'.png" alt="image" class = "imgvlgfull">
        </div>';
  }

?>