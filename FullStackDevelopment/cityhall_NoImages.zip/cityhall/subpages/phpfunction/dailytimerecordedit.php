<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');

$id = $_GET['studID'];
$connection = $_GET['connection'];
$timecategory = $_GET['timecategory'];
$keyseq = $_GET['keyseq'];
$valuetime = $_GET['valuetime'];
$timenow = $_GET['timenow'];
$timenow = $timenow.' 00:00:00';

$aa = '';
$da = '';
$ap = '';
$dp = '';
switch($timecategory){
	case 'aa':
	$aa = $valuetime;
	break;
	case 'da':
	$da = $valuetime;
	break;
	case 'ap':
	$ap = $valuetime;
	break;
	case 'dp':
	$dp = $valuetime;
	break;	
}


$query = "SELECT count(*) FROM dtr_foreditrequest WHERE idspeci = :keyseq";
$stmt = $dbhsub -> prepare($query);
$stmt -> bindParam(':keyseq', $keyseq);
$stmt -> execute();
if($stmt->fetchColumn()>0){
	if(!empty($aa)){
	$querythis = $dbhsub -> prepare("UPDATE dtr_foreditrequest SET arrival_am = ? WHERE idspeci = ?");
	$run = $querythis ->execute(array($valuetime, $keyseq));
	}
	if(!empty($da)){
	$querythis = $dbhsub -> prepare("UPDATE dtr_foreditrequest SET departure_am = ? WHERE idspeci = ?");
	$run = $querythis ->execute(array($valuetime, $keyseq));
	}
	if(!empty($ap)){
	$querythis = $dbhsub -> prepare("UPDATE dtr_foreditrequest SET arrival_pm = ? WHERE idspeci = ?");
	$run = $querythis ->execute(array($valuetime, $keyseq));
	}
	if(!empty($dp)){
	$querythis = $dbhsub -> prepare("UPDATE dtr_foreditrequest SET departure_pm = ? WHERE idspeci = ?");
	$run = $querythis ->execute(array($valuetime, $keyseq));
	}
	echo 'Successfully modified data';
}
else{
	$queryin = $dbhsub->prepare("INSERT INTO dtr_foreditrequest(dtrdt, arrival_am, departure_am, arrival_pm, departure_pm, employeeid, idspeci)VALUES(?,?,?,?,?,?,?)");
	$stmts = $queryin->execute(array($timenow, $aa, $da, $ap, $dp, $id, $keyseq));
	// $stmts->bindParam(':aa', $aa);
	// $stmts->bindParam(':da', $da);
	// $stmts->bindParam(':ap', $ap);
	// $stmts->bindParam(':dp', $dp);
	// $stmts->bindParam(':id', $id);
	// $stmts->bindParam(':keyseq', $keyseq);
	// $stmts->execute();
	if($stmts){
	echo 'Successfully inserted new request data';
	}
	else{
	echo 'fail query';
	}
}


?>