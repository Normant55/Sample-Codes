<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
  $thislink = "none";
  $thelink = "none";
  $statement = $dbhsub -> query("SELECT * FROM covertitleimage ORDER BY imageid DESC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
    $record = $row['imageid'];
  $firstimage = $dbhsub -> query("SELECT TOP 1 * FROM coverextender WHERE imageid = '$record' AND imagepath !='none' ORDER BY imageid DESC");
  while($imagerow = $firstimage ->fetch(PDO::FETCH_ASSOC)){
    $determine = $imagerow['extenderid'];
  }
    $firstdescription = $dbhsub -> query("SELECT TOP 1 * FROM coverextender WHERE imageid = '$record' AND imagepath = 'none' ORDER BY imageid DESC");
  while($descriptive = $firstdescription ->fetch(PDO::FETCH_ASSOC)){
    $descript = $descriptive['description'];
      $thelink = substr($descript, 21, 10);
  }
    if($thelink == 'linktopath'){
$arr = explode('linktopath ', $descript);
$thislink = $arr[1];
$thislink = substr($thislink, 0, -6);          
    echo '<div id=\'processdiv'.$row['imageid'].'\' class=\'display\' style = "width: 100%;position: relative; cursor:pointer;">';

    if(isset($determine)){
echo '<img class = "img-responsive" id="frontimagedesign" onclick = "linktopath(\''.$thislink.'\')" src="images/coverimages/'.$determine.'.png" alt="image test" style = "position: relative; z-index: 0; 

            background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  margin-top: 0%;
  margin-bottom: 0%;
  width: 100%;
  margin-left: 0%;
           " />';}

$thelink = 'none';

  }else{
    echo '<div id=\'processdiv'.$row['imageid'].'\' class=\'display\' style = "width: 100%;position: relative; cursor:pointer;">';
    
    if(isset($determine)){
echo ' <img class = "img-responsive" id="frontimagedesign" onclick = "owaay('.$row['imageid'].')" src="images/coverimages/'.$determine.'.png" alt="image test" style = "position: relative; z-index: 0; 

            background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  margin-top: 0%;
  margin-bottom: 0%;
  width: 100%;
  margin-left: 0%;

           " />';}}

if(strlen($row['imagetitle'])>20){
   $finaltitle = substr($row['imagetitle'], 0, 20).'...';}
   else{
    $finaltitle = $row['imagetitle'];
   }
   if(isset($descript)){
    $finaldesc = $descript;}else{$finaldesc = '<div class = "hexor"></div>';}
    // $finaldesc = str_replace("hexor", "normal", $finaldesc);
   //  $finaldesc = str_replace("<span style=\"background-color:rgba(0,0,0,0);\">", "", $finaldesc);
   //  $finaldesc = str_replace("</span>", "", $finaldesc);
   // echo '<div class = "container-fluid" style="margin-top: 1%; background-color: rgba(200,200,200,0.8); width: 100%; float: left;">';
   //       echo '<h2 style = "color: rgba(240, 50, 50, 1)">'.$finaltitle.'</h2>';
   //       echo '<p>'.$finaldesc.'</p>';
   // echo'</div>';
echo'</div>';
  }
?>


        