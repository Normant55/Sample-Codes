<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
$delete = $_GET['deletevalue'];
include("../../../php/connectPDO.php");

$statement = $dbhsub -> prepare("DELETE FROM examinee WHERE examineeid = :delete");
$statement -> bindParam(':delete', $delete);
$statement -> execute();
if($statement){
	echo 'Successfully Deleted Object!';
}


?>