<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../../php/connectPDO.php");
$searchkeyword = $_GET['searchkeyword'];
$searchdate = $_GET['searchdate'];
$searchfnt = $_GET['searchfnt'];
$eft = $_GET['eft'];
$searchtnt = $_GET['searchtnt'];
$ett = $_GET['ett'];
$inputname = $_GET['inputname'];
$inputcontact = $_GET['inputcontact'];
$inputlevel = $_GET['inputlevel'];
$inputscore = $_GET['inputscore'];
$inputresult = $_GET['inputresult'];
$inputremarks = $_GET['inputremarks'];
$inputdate = $_GET['inputdate'];
$inputtime = $_GET['inputtime'];
$statement = $dbhsub -> prepare("SELECT examineeid, name, contact, elevel, score, result, remarks, takentime, CONVERT(VARCHAR(10),takendate, 101) AS takendate FROM examinee ORDER BY takendate");
$statement -> execute();
	echo '<div class = "no_lining">
  <a onclick = "reto(\'default\')" style = "cursor:pointer;">
  <img class = "img-responsive" src="images/return_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
  Exit</a></div>';
  echo '<a href = "php/printexaminees.php" class = "word_button" style = "text-decoration: none; cursror: pointer;">View All PDF</a>';
  echo '<div class = "col-md-12" style = "margin-top: 0%;">
  <h3>Search Examinee</h3>
  <input type = "text" onkeyup = "searchengine()" id ="searchkeyword"';if($searchkeyword!=''){echo'value = "'.$searchkeyword.'"';} echo' placeholder = "Search Keyword..." style = "width: 30%; margin-right: 2.5%;">
  <input type = "date" onchange = "searchengine()"';if($searchdate!=''){echo'value = "'.$searchdate.'"';} echo' id = "searchdate">';
  echo 'From <input type = "number" style = "width: 5%;" ';if($searchfnt!=''){echo'value = "'.$searchfnt.'"';} echo' onkeyup = "searchengine()" id ="searchfnt"> 
  <select id = "eft" onchange = "searchengine()"><option value = "AM" ';if($eft=='AM'){echo'selected';} echo'>AM</option><option value = "PM" ';if($eft!='AM'){echo'selected';} echo'>PM</option></select>';
  echo 'To <input type = "number" style = "width: 5%;" ';if($searchtnt!=''){echo'value = "'.$searchtnt.'"';} echo' onkeyup = "searchengine()" id = "searchtnt"> 
  <select id = "ett" onchange = "searchengine()"><option value = "AM" ';if($ett=='AM'){echo'selected';} echo'>AM</option><option value = "PM" ';if($ett!='AM'){echo'selected';} echo'>PM</option></select></div>';
  echo '<div class = "col-md-12" style ="margin-top: 0.5%;">
  <h3>Add Examinee</h3>
  <input type = "text" id = "inputname" onkeyup = "saveinput()" ';if($inputname!=''){echo'value = "'.$inputname.'"';} echo' placeholder = "Insert Name...">
  <input type = "text" id = "inputcontact" onkeyup = "saveinput()" ';if($inputcontact!=''){echo'value = "'.$inputcontact.'"';} echo' placeholder = "Contact...">
  <input type = "text" id = "inputlevel" onkeyup = "saveinput()" ';if($inputlevel!=''){echo'value = "'.$inputlevel.'"';} echo' placeholder = "Level...">
  <input type = "text" id = "inputscore" onkeyup = "saveinput()" ';if($inputscore!=''){echo'value = "'.$inputscore.'"';} echo' placeholder = "Score...">
  <input type = "text" id = "inputresult" onkeyup = "saveinput()" ';if($inputresult!=''){echo'value = "'.$inputresult.'"';} echo' placeholder = "Result...">
  <input type = "text" id = "inputremarks" onkeyup = "saveinput()" ';if($inputremarks!=''){echo'value = "'.$inputremarks.'"';} echo' placeholder = "Remarks...">
  <input type = "date" id = "inputdate" onchange = "saveinput()" ';if($inputdate!=''){echo'value = "'.$inputdate.'"';} echo' placeholder = "Date...">
  <input type = "text" id = "inputtime" onkeyup = "saveinput()" ';if($inputtime!=''){echo'value = "'.$inputtime.'"';} echo' placeholder = "Time...">
  <button class = "btn-default" onclick = "addexaminee();">Add Examinee</a>
  </div>';
  echo '<div class = "col-md-12"><h3>Examinee</h3></div>
<div class = "col-md-12">
<div class = "editor" onclick = "deleteselected()">Delete Selected</div>
<div class = "editor" onclick = "selectall()">Select All</div></div>
  <div class = "col-md-1 passerbiga"></div>
  <div class = "col-md-11">
  <div class = "col-md-3 passerbiga">Fullname</div>
  <div class = "col-md-2 passerbiga">Contact</div>
  <div class = "col-md-2 passerbiga">Level</div> 
  <div class = "col-md-2 passerbiga">Score</div>
  <div class = "col-md-1 passerbiga">Result</div>
  <div class = "col-md-2 passerbiga">Remark</div>
  </div>
  <div id = "examineesbox">
  ';
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
  echo '<div class = "col-md-12">';
	echo '<div onmouseover = "ecolor('.$row['examineeid'].')" onmouseout = "euncolor('.$row['examineeid'].')" style = "cursor:pointer;">
  ';
  echo '<div class = "col-md-1 passerbigs"><input type="checkbox" id = "mycheck'.$row['examineeid'].'" onclick="examcbox('.$row['examineeid'].')"></div>';
  echo '<div class = "col-md-11" href="#demo'.$row['examineeid'].'" data-toggle="collapse">
  ';
	echo '<div class = "col-md-3 passerbigs" id = "en'.$row['examineeid'].'">'.$row['name'].'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "ec'.$row['examineeid'].'">'.$row['contact'].'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "el'.$row['examineeid'].'">'.$row['elevel'].'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "ee'.$row['examineeid'].'">'.$row['score'].'</div>';
	echo '<div class = "col-md-1 passerbigs" id = "et'.$row['examineeid'].'">'.$row['result'].'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "es'.$row['examineeid'].'">'.$row['remarks'].'</div></div>';
	echo '
  </div>
  <div class = "col-md-12 collapse" id="demo'.$row['examineeid'].'">
  <div class = "col-md-12"><div class = "col-md-6">Taken Date: '.$row['takendate'].'</div><div class = "col-md-6">Taken Time: '.$row['takentime'].'</div></div>
  <div class = "col-md-6">
  <div class = "editor" style = "margin: 0 20%;">
  Update</div>
  </div>
  <div class = "col-md-6">
  <div class = "editor" style = "margin: 0 20%;" onclick = "deleteexaminee('.$row['examineeid'].')">
  Delete</div>
  </div>
  </div>
  </div>
  ';
}
  echo '</div>';
?>