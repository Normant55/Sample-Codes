<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../../php/connectPDO.php");
$searchkeyword = $_GET['searchkeyword'];
$searchdate = $_GET['searchdate'];

$searchfnt = $_GET['searchfnt'];
$eft = $_GET['eft'];
$searchtnt = $_GET['searchtnt'];
$ett = $_GET['ett'];
if($searchdate != ''){
$searchdate = substr($searchdate, 5, 2).'/'.substr($searchdate, 8, 2).'/'.substr($searchdate, 0, 4);
$conditiondate = 'AND takendate = \''.$searchdate.'\'';}else{
$conditiondate = '';
}
$keyarray = array();
$keyarray = explode(" ", $searchkeyword);
$idfound = array();
$x = 1;
$current = 0;
while($x<2){
	if(isset($keyarray[$current]) && $keyarray[$current]!=''){
	$searchthis = $keyarray[$current];
	$current++;
$statement = $dbhsub -> prepare("SELECT examineeid, name, contact, elevel, score, result, remarks, takentime, CONVERT(VARCHAR(10),takendate, 101) AS takendate FROM examinee WHERE (name LIKE ':searchthis' OR contact LIKE ':searchthis2' OR elevel LIKE ':searchthis3' OR score LIKE ':searchthis4' OR result LIKE ':searchthis5' OR remarks LIKE ':searchthis6') AND examineeid NOT IN ('".implode(' \', \'', $idfound)."')".$conditiondate);
$statement -> bindValue(':searchthis', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis2', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis3', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis4', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis5', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis6', '%'.$searchthis.'%');
$statement -> execute();
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
array_push($idfound, $row['examineeid']);
  echo '<div class = "col-md-12" style = "border-bottom: solid 1px black;">';
	echo '<div onmouseover = "ecolor('.$row['examineeid'].')" onmouseout = "euncolor('.$row['examineeid'].')" style = "cursor:pointer;">
  ';
  echo '<div class = "col-md-1"><input type="checkbox" name="varanq[]" value="'.$row['examineeid'].'"></div>';
  echo '<div class = "col-md-11" href="#demo'.$row['examineeid'].'" data-toggle="collapse">
  ';
	echo '<div class = "col-md-3 passerbigs" id = "en'.$row['examineeid'].'">'.$row['name'].'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "ec'.$row['examineeid'].'">'.$row['contact'].'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "el'.$row['examineeid'].'">'.$row['elevel'].'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "ee'.$row['examineeid'].'">'.$row['score'].'</div>';
	echo '<div class = "col-md-1 passerbigs" id = "et'.$row['examineeid'].'">'.$row['result'].'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "es'.$row['examineeid'].'">'.$row['remarks'].'</div></div>';
	echo '
  </div>
  <div class = "col-md-12 collapse" id="demo'.$row['examineeid'].'">
  <div class = "col-md-12"><div class = "col-md-6">Taken Date: '.$row['takendate'].'</div><div class = "col-md-6">Taken Time: '.$row['takentime'].'</div></div>
  <div class = "col-md-6">
  <div class = "editor" style = "margin: 0 20%;">
  Update</div>
  </div>
  <div class = "col-md-6">
  <div class = "editor" style = "margin: 0 20%;" onclick = "deleteexaminee('.$row['examineeid'].')">
  Delete</div>
  </div>
  </div>
  </div>
  ';

	}

}else{
	$x = 2;
}

}
?>