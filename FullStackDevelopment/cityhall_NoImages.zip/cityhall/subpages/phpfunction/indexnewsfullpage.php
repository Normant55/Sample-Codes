<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$ok = $_GET['nombe'];
echo '<div style = "font-size: 150%; padding: 2.5%;"><a style = "cursor:pointer; text-decoration:none;" onclick = "refresher()" class = "exit_edge">
  <img class = "img-responsive" src="images/return_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
Back</a></div>';
  $statement = $dbhsub -> prepare("SELECT * FROM covertitleimage WHERE imageid = :ok");
  $statement->bindParam(":ok", $ok);
  $statement->execute();
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
      // [newscontentid]
      // ,[newsid]
      // ,[description]
      // ,[type]
      // ,[sizeposition]
      // ,[imagepath]
      // ,[dateuploaded]

      // [newsid]
      // ,[title]
      // ,[type]
      // ,[sizeposition]
      // ,[dateuploaded]
      // ,[publisher]

    echo '<div class = "container">';
    if($row['sizeposition'] == 'half'){
    echo '<div class = "col-md-6">';}else{
    echo '<div class = "col-md-12">';     
    }
           $fulldesc = str_replace("hexor", "normalize", preg_replace('#<script(.*?)>(.*?)</script>#is', '', $row['imagetitle']));
         echo '<h1 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h1>';
         echo '<h4>Uploaded on '.$row['dateuploaded'].'</h4>';
echo'</div>';

  }
$blockfirst = 1;
  $statement = $dbhsub -> prepare("SELECT * FROM coverextender WHERE imageid = :ok ORDER BY prioritycode ASC, dateuploaded DESC");
  $statement->bindParam(":ok", $ok);
  $statement->execute();
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
 

    if($row['type'] == 'none' AND $blockfirst == 1){
      $blockfirst++;
    }
if($blockfirst!=2){
  if($row['sizeposition']=='half'||$row['sizeposition']=='halfl'){
  echo '<div class = "col-md-6">';}else{
  echo '<div class = "col-md-12">';  
  }
    if($row['type'] == 'none'){
  echo ' <img ';
if($row['sizeposition']=='half'||$row['sizeposition']=='full'){
  echo 'class = "imgvsm"';
}elseif($row['sizeposition']=='halfl'||$row['sizeposition']=='fullt'){
  echo 'class = "imgvlg"';
}
echo ' id="frontimagedesign" src="images/coverimages/'.$row['extenderid'].'.png" alt="image test" style = "background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);';
echo 'width: 100%;
           " />';}
          $fulldesc = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $row['description']);
           $fulldesc = str_replace("hexor", "normalize", $fulldesc);
           if($row['type'] == 'paragraph'){
        
         echo '<p style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</p>';
       }elseif($row['type'] == 's1'){
         echo '<h1 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h1>';      
         }
         elseif($row['type'] == 's2'){
         echo '<h2 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h2>';      
         }
         elseif($row['type'] == 's3'){
         echo '<h3 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h3>';      
         }
         elseif($row['type'] == 's4'){
         echo '<h4 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h4>';      
         }
         elseif($row['type'] == 's5'){
         echo '<h5 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h5>';      
         }
         elseif($row['type'] == 's6'){
         echo '<h6 style = "color: rgba(10, 10, 10, 1)">'.$fulldesc.'</h6>';      
         }
echo'</div>';
}else{$blockfirst= 3;}
  }
  echo '</div>';
?>



        