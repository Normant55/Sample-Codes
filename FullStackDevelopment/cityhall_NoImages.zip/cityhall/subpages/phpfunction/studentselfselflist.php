<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');

$theconnection =  $_GET['connection'];
$theids =  $_GET['studID'];
$query = "select * from employee WHERE employeeid = '$theids'";
$stmt = $dbh -> query($query);
// echo $theids;
// echo 'ahahah';

while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
                 //echo '<div class = "infotab"> Database ID: '.$row['Student_ID'];
if($theconnection != 'fixed'){
                echo '
                        <div class="jumbotron name_space information_eye">
                                     <a class="navbar-brand">'.strip_tags($row['fullname']).'</a><div class = "col-md-12">
  <h4><img src="images/menu_profile.png" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>ID no.'.strip_tags($row['employeeid']).'</h4></div>
        </div>
           <div class = "buttons">
        <div class = "boxforpicture" id = "thepic">
            <div class = "picturebox"><img src = "http://'.$theconnection.'/cityhall/images/studentprofile/'.$theids.'.png" style = "
            width: 150px;
           height: 150px;
            ">
            </div></div>
         


                <div class = "button_positive" id = "editpictureb" onclick = "picture()">Image Upload</div>
                <div class = "button_positive" onclick = "editprofile()">Edit Profile</div>  
                 </div>';}
else{

 echo '

                        <div class="jumbotron name_space information_eye ">
                            <a class="navbar-brand">'.strip_tags($row['fullname']).'</a><div class = "col-md-12">
<h4><img src="images/menu_profile.png" class = "img-responsive" alt="image test" style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 25px;
  display: inline-block;
  margin-top: 0px;
  margin-bottom: 5px;
  margin-left: 0.5%;"/>ID no.'.strip_tags($row['employeeid']).'</h4></div>
        </div>
           <div class = "buttons">
        <div class = "boxforpicture" id = "thepic">
            <div class = "picturebox"><img src = "images/studentprofile/'.$theids.'.png?v=1.2" style = "
            width: 150px;
           height: 150px;
            ">
            </div></div>
                <div class = "button_positive" id = "editpictureb" onclick = "picture()">Image Upload</div>         
                <div class = "button_positive" onclick = "editprofile()">Edit Profile</div>
                </div>';

}


                 echo '<div class = "col-md-4 font_eye_fast">
                 Given Name:<div class = "infotab">'.strip_tags($row['firstname']);
                 echo '</div>   
                 Middle Name:<div class = "infotab">'.strip_tags($row['middle']);
                 echo '</div> 
                 Surname:<div class = "infotab">'.strip_tags($row['lastname']);
                 switch (strip_tags($row['marital_status'])){
                case 1:
                echo '</div> 
                Marital Status:<div class = "infotab">Single';
                break;
                case 2:
                echo '</div> 
                Marital Status:<div class = "infotab">Married';
                break;
                case 3:
                echo '</div> 
                Marital Status:<div class = "infotab">Widowed';
                break;
                case 4:
                echo '</div> 
                Marital Status:<div class = "infotab">Separated';
                break;

                 }
                 echo '</div> 
                 Entrance to Duty:<div class = "infotab">'.strip_tags($row['entrance_to_duty']);
                 echo '</div> 
                 Fullname:<div class = "infotab">'.strip_tags($row['fullname']);
                 echo '</div> Home Address:<div class = "infotab">'.strip_tags($row['home_address']);
                 echo '</div> Home Phone:<div class = "infotab">'.strip_tags($row['home_phone']);
                 echo '</div> Mobile Number:<div class = "infotab"> '.strip_tags($row['mobile_no']);
                 echo '</div> Citizenship:<div class = "infotab">'.strip_tags($row['citizenship']);
                 echo '</div> Email Address:<div class = "infotab">'.strip_tags($row['email_address']);
                 echo '</div> Birthdate:<div class = "infotab">'.strip_tags($row['birthdate']);
                 echo '</div> Age:<div class = "infotab">'.strip_tags($row['age']);
                 echo '</div> Birthplace:<div class = "infotab">'.strip_tags($row['birthplace']);
                 echo '</div> Department Abbrivation:<div class = "infotab"> '.strip_tags($row['dept_abbriv']);
                 echo '</div> Job Title:<div class = "infotab">'.strip_tags($row['job_title']);
                 echo '</div> Work Schedule:<div class = "infotab">'.strip_tags($row['work_sched']);
                 echo '</div> Job Status:<div class = "infotab">'.strip_tags($row['job_status']);

                 echo '</div></div><div class = "col-md-4 font_eye_fast"> Work Status:<div class = "infotab">'.strip_tags($row['work_status']);
                 echo '</div> Tin Number:<div class = "infotab">'.strip_tags($row['tin_number']);
                 echo '</div> SSS GSIS number:<div class = "infotab"> '.strip_tags($row['sssgsis_number']);
                 echo '</div> SSS GSIS contribution:<div class = "infotab">'.strip_tags($row['sssgsis_contrib']);
                 echo '</div> Philhealth Number:<div class = "infotab">'.strip_tags($row['philhealth_no']);
                 echo '</div> Philhealth contribution:<div class = "infotab">'.strip_tags($row['philhealth_contrib']);
                 echo '</div> Pagibig Number:<div class = "infotab">'.strip_tags($row['pagibig_no']);
                 echo '</div> Pagibig contribution:<div class = "infotab">'.strip_tags($row['pagibig_contrib']);
                 echo '</div> Tax Category:<div class = "infotab"> '.strip_tags($row['taxcategory']);
                 switch (strip_tags($row['gender'])){
                case 0:
                echo '</div> 
                Gender:<div class = "infotab">Female';
                break;
                case 1:
                echo '</div> 
                Gender:<div class = "infotab">Male';
                break;
                }
                 echo '</div> Course Degree:<div class = "infotab">'.strip_tags($row['course_degree']);
                 echo '</div> School Graduate:<div class = "infotab">'.strip_tags($row['school_grad']);

                 echo '</div> Eligibility:<div class = "infotab">'.strip_tags($row['eligibility']);
                 echo '</div> Special Skills:<div class = "infotab">'.strip_tags($row['special_skills']);
                 echo '</div> Latitude:<div class = "infotab">'.strip_tags($row['latitude']);
                 echo '</div> Longitude:<div class = "infotab">'.strip_tags($row['longitude']);
                 echo '</div> Spouse Address:<div class = "infotab">'.strip_tags($row['spouse_address']);

$queryinside = "select count(*) as count from employee_children WHERE employeeid = '$theids'";
$stmtinside = $dbh -> query($queryinside);
// echo $theids;
// echo 'ahahah';
while($rowinside = $stmtinside -> fetch( PDO::FETCH_ASSOC )){
    $count = $rowinside['count'];
                 //echo '<div class = "infotab"> Database ID: '.$row['Student_ID'];
$queryinsider = $dbh->prepare("UPDATE employee SET no_dependents = ? WHERE employeeid = ?");
$stmtinsider = $queryinsider->execute(array($count, $theids));
if($stmtinsider){
}
else{
}
}



                 echo '</div> Number Dependents:<div class = "infotab" style = "overflow: auto;">'.$count;
                 echo '
<img class = "img-responsive" src="images/logo_add.png" alt="image test"
  onclick = "adddependents()" 
  style = "position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 20px;
  cursor: pointer;
  float: right;
"/>
                 </div>
                 </div><div class = "col-md-4 font_eye_fast"> Cedula Number:<div class = "infotab">'.$row['cedula_no'];
                 echo '</div> Landline:<div class = "infotab"> '.$row['landline'];

                 echo '</div> Date Issued:<div class = "infotab">'.$row['dateissued'];
                 echo '</div> Place Issued:<div class = "infotab">'.$row['placeissued'];
                 echo '</div> Father\'s Lastname:<div class = "infotab">'.$row['flastname'];
                 echo '</div> Father\'s Firstname:<div class = "infotab">'.$row['ffirstname'];
                 echo '</div> Father\'s Middlename:<div class = "infotab">'.$row['fmiddle'];
                 echo '</div> Mother\'s Lastname:<div class = "infotab"> '.$row['mlastname'];
                 echo '</div> Mother\'s Firstname:<div class = "infotab">'.$row['mfirstname'];
                 echo '</div> Mother\'s Middlename:<div class = "infotab">'.$row['mmiddle'];
                 echo '</div> Spouse Lastname:<div class = "infotab">'.$row['spouse'];
                 echo '</div> Spouse Firstname:<div class = "infotab">'.$row['spousefirstname'];

                 echo '</div> Spouse Middlename:<div class = "infotab">'.$row['spousemiddle'];
                 echo '</div> PWD:<div class = "infotab">'.$row['pwd'];
                 echo '</div> Nature Statistics:<div class = "infotab"> '.$row['nature_stat'];
                 echo '</div> Religion:<div class = "infotab">'.$row['religion'];
                 echo '</div> Item Number:<div class = "infotab">'.$row['item_no'];
                 echo '</div> Job Grade:<div class = "infotab">'.$row['job_grade'];
                //  $thecourse = $row['Course_ID'];
                
                // $querysubject = "select * from course where Course_ID = '$thecourse'";
                // foreach ($psbh->query($querysubject) as $rowex) {
                // echo '</div> Course:<div class = "infotab">'.$rowex['Course_Name'];
                // }
                 // echo '</div> Entrance Exam Score:<div class = "infotab">'.$row['remarks'];
                 echo '</div> Employee ID:<div class = "infotab">'.$row['employeeid'];
                 // echo '</div> Enrollment Status:<div class = "infotab">'.$row['status'];
                 echo '</div></div>';
        
}
       
?>