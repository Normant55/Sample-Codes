<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
function strafter($string, $substring) {
  $pos = strpos($string, $substring);
  if ($pos === false)
   return $string;
  else  
   return(substr($string, $pos+strlen($substring)));
}



include('../../php/connectPDO.php');
echo '<h2>Departments</h2>';
$query = $dbhhris -> query("SELECT Count(Distinct[Poscode]) FROM ITEMS");
$amount = $query -> fetchColumn();
echo '<div class="tab">';
$counter = $amount/7;
$starting = 1;
while($starting<=$counter+1){
echo ' <button class="tablinks" onclick="openCity(event, \'ain'.$starting.'\')">'.$starting.'</button>';
$starting++;
}
echo '</div>';

$counterlimit = 1;
$bash = 1;
$query = $dbhhris -> query("SELECT Distinct[Poscode], Position, DeptDesc FROM ITEMS");
while($row = $query -> fetch(PDO::FETCH_ASSOC)){

	if($counterlimit==8){
		$counterlimit = 1;
			echo '</div>';
	}

	if($counterlimit == 1){
		echo '<div id="ain'.$bash.'" class="tabcontent">';
		$bash++;
	}

$stringsearch = $row['DeptDesc'];
$stringsearch = str_replace('\'', '`', $stringsearch);

echo '<li><a onclick = "viewdepartmentopenjobs(\''.$stringsearch.'\')">'.$row['DeptDesc'].'-'.$row['Poscode'].'-'.$row['Position'].'</a></li>';



	$counterlimit ++;



}
echo '</div>';






?>
<!-- Tab content -->