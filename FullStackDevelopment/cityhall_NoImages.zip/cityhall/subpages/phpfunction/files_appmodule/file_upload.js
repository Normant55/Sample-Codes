$(document).ready(function (e) {
$("#coverimagingb").on('submit',(function(e) {
e.preventDefault();
$("#messagereplacerb").empty();
$('#loading').show();
my_file_category = document.getElementById("my_file_category").value;
theid = window.localStorage.getItem("loginid");
$.ajax({
url: "http://79.125.201.223:8080/cityhall/subpages/phpfunction/files_appmodule/file_upload.php?my_file_category="+my_file_category+"&theid="+theid, // Url to which the request is send
type: "POST",             // Type of request to be send, called as method
data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
contentType: false,       // The content type used when sending data to the server.
cache: false,             // To unable request pages to be cached
processData:false,        // To send DOMDocument or non processed data file it is set to false
success: function(data)   // A function to be called if request succeeds
{
$('#loading').hide();
$("#messagereplacerb").html(data);
if(searchkeyword != ''){
           $.post("subpages/phpfunction/files_appmodule/searchengine.php", 
           //Required URL of the page on server
           { // Data Sending With Request To Server
            startmonthtoolkit:startmonthtoolkit,
            startdaytoolkit:startdaytoolkit,
            enddaytoolkit:enddaytoolkit,
            endyeartoolkit:endyeartoolkit,
            startyeartoolkit:startyeartoolkit,
            endmonthtoolkit:endmonthtoolkit,
            searchkeyword:searchkeyword,
            item_ranking_first:item_ranking_first,
            item_ranking_last:item_ranking_last,
            theid:theid
           },
           function(response,status){ // Required Callback Function
                //alert("*----Received Data----*nnResponse : " + response+"nnStatus : " + status);
                //"response" receives - whatever written in echo of above PHP script.
                // $("#form")[0].reset();
                document.getElementById("files_box").innerHTML = response;
                function return_typefile(data){
                    write_html = 'Choose Category: ';
                    write_html = write_html+select_maker(data, 'my_file_category');
                    // button_html = '<div class = "dashuploader" id ="coverreplacer" style = "float: left;"><div class="main" id = "coverup"><hr><form id="coverimagingb" action="" method="post" enctype="multipart/form-data"><div id="image_previewreplacerb"><img id="previewingreplacerb" src="noimage.png" /></div><hr id="line"><div id="selectImage"><label>Select Your Image</label><br/><input type="file" name="file" id="filereplacerb" required /><input type="submit" value="Add Photo" id ="replacerbutton" class="submit" /></div></form></div><div id="messagereplacerb"></div></div>'+write_html+'';
                    $('.type_file_upload').html(write_html);
                }
                search_query('is_fixed = 0', '[biosub].[dbo].[file_category]', 'file_category_id*-, description', '', '', 'select_allby', '', 'dbhsub', return_typefile);
           });
}else{
           $.post("subpages/phpfunction/files_appmodule/list.php", 
           //Required URL of the page on server
           { // Data Sending With Request To Server
            startmonthtoolkit:startmonthtoolkit,
            startdaytoolkit:startdaytoolkit,
            enddaytoolkit:enddaytoolkit,
            endyeartoolkit:endyeartoolkit,
            startyeartoolkit:startyeartoolkit,
            endmonthtoolkit:endmonthtoolkit,
            searchkeyword:searchkeyword,
            item_ranking_first:item_ranking_first,
            item_ranking_last:item_ranking_last,
            theid:theid
           },
           function(response,status){ // Required Callback Function
                //alert("*----Received Data----*nnResponse : " + response+"nnStatus : " + status);
                //"response" receives - whatever written in echo of above PHP script.
                // $("#form")[0].reset();
                document.getElementById("file_application").innerHTML = response;
                function return_typefile(data){
                    write_html = 'Choose Category: ';
                    write_html = write_html+select_maker(data, 'my_file_category');
                    // button_html = '<div class = "dashuploader" id ="coverreplacer" style = "float: left;"><div class="main" id = "coverup"><hr><form id="coverimagingb" action="" method="post" enctype="multipart/form-data"><div id="image_previewreplacerb"><img id="previewingreplacerb" src="noimage.png" /></div><hr id="line"><div id="selectImage"><label>Select Your Image</label><br/><input type="file" name="file" id="filereplacerb" required /><input type="submit" value="Add Photo" id ="replacerbutton" class="submit" /></div></form></div><div id="messagereplacerb"></div></div>'+write_html+'';
                    $('.type_file_upload').html(write_html);
                }
                search_query('is_fixed = 0', '[biosub].[dbo].[file_category]', 'file_category_id*-, description', '', '', 'select_allby', '', 'dbhsub', return_typefile);
           });
}








}
});
}));
// Function to preview image after validation
$(function() {
$("#filereplacerb").change(function() {
$("#messagereplacerb").empty(); // To remove the previous error message
var file = this.files[0];
var imagefile = file.type;
// var match= ["image/jpeg","image/png","image/jpg"];
// if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
// {
// $('#previewingreplacerb').attr('src','noimage.png');
// $("#messagereplacerb").html("<p id='error'>Please Select A valid Image File</p>"+"<h4>Note</h4>"+"<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
// return false;
// }
// else
// {
// var reader = new FileReader();
// reader.onload = imageIsLoaded;
// reader.readAsDataURL(this.files[0]);
// }
});
});
// function imageIsLoaded(e) {
// $("#filereplacerb").css("color","green");
// $('#image_previewreplacerb').css("display", "block");
// $('#previewingreplacerb').attr('src', e.target.result);
// $('#previewingreplacerb').attr('width', '250px');
// $('#previewingreplacerb').attr('height', '230px');
// };



});