<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
$delete = $_GET['deletevalue'];
$deletearray = array();
$deletearray = explode(",", $delete);
include("../../../php/connectPDO.php");


$statement = $dbhsub -> prepare("SELECT path FROM [biosub].[dbo].[file_main] WHERE [file_id] IN ('".implode(' \', \'', $deletearray)."')");
$statement -> execute();
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
	$path = $row['path'];
	if(file_exists($path)){
	unlink($path);
	}
}

$statement = $dbhsub -> prepare("DELETE FROM [biosub].[dbo].[file_main] WHERE [file_id] IN ('".implode(' \', \'', $deletearray)."')");
$statement -> execute();
if($statement){
	echo 'Successfully Deleted Object!';
}


?>