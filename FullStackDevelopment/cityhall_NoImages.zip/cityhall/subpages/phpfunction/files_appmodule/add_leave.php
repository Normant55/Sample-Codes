<?php
include("../../../php/connectPDO.php");
$inputname = $_GET['inputname'];
$inputcontact = $_GET['inputcontact'];
$inputlevel = $_GET['inputlevel'];
$inputscore = $_GET['inputscore'];
$inputresult = $_GET['inputresult'];
$inputremarks = $_GET['inputremarks'];
$inputdate = $_GET['inputdate'];
$inputtime = $_GET['inputtime'];
$statement = $dbhsub ->prepare("INSERT INTO examinee(name, contact, elevel, score, result, remarks, takendate, takentime)values('$inputname', '$inputcontact', '$inputlevel', '$inputscore', '$inputresult', '$inputremarks', '$inputdate', '$inputtime');");
$statement -> execute();
if($statement){
	"Successful Query";
}
else{
	"Failed Query";
}
?>