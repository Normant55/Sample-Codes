<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../../php/connectPDO.php");
$theid = $_POST['theid'];
$searchkeyword = $_POST['searchkeyword'];
$item_ranking_first = $_POST['item_ranking_first'];
$item_ranking_last = $_POST['item_ranking_last'];

if((!isset($_POST['item_ranking_first']) OR ($_POST['item_ranking_first']=='')) OR (!isset($_POST['item_ranking_last']) OR ($_POST['item_ranking_last']==''))){
  $item_ranking_first = 1;
  $item_ranking_last = 15;
}else{
  $item_ranking_first = $_POST['item_ranking_first'];
  $item_ranking_last = $_POST['item_ranking_last'];
}

$startmonth =  $_POST['startmonthtoolkit'];
$startday =  $_POST['startdaytoolkit'];
$startyear =  $_POST['startyeartoolkit'];
$endmonth =  $_POST['endmonthtoolkit'];
$endday =  $_POST['enddaytoolkit'];
$endyear =  $_POST['endyeartoolkit'];

$searchdate = '';
if($searchdate != ''){
$searchdate = substr($searchdate, 5, 2).'/'.substr($searchdate, 8, 2).'/'.substr($searchdate, 0, 4);
$conditiondate = 'AND takendate = \''.$searchdate.'\'';}else{
$conditiondate = '';
}

$data_count = 0;
$keyarray = array();
$keyarray = explode(" ", $searchkeyword);
$idfound = array();
$x = 1;
$current = 0;
while($x<2){
	if(isset($keyarray[$current]) && $keyarray[$current]!=''){
	$searchthis = $keyarray[$current];  
	$current++;
$statement = $dbhsub -> prepare("SELECT * FROM (SELECT [file_id]
      ,[name]
      ,[path]
      ,D.description AS file_category
      ,C.description AS file_type
      ,[employeeid]
      ,B.description AS file_status
      ,A.date_uploaded AS the_time
      ,CONVERT(VARCHAR(10),date_uploaded, 101) AS date_uploaded,
      ROW_NUMBER() OVER(ORDER BY date_uploaded DESC) AS ranking_id
       FROM [biosub].[dbo].[file_main] AS A INNER JOIN [biosub].[dbo].[file_status] AS B on A.[file_status_id] = B.[file_status_id] INNER JOIN [biosub].[dbo].[file_type] AS C on A.[file_type_id] = C.[file_type_id] INNER JOIN [biosub].[dbo].[file_category] AS D on A.[file_category_id] = D.[file_category_id]) AS FINAL WHERE name LIKE :searchthis AND file_id NOT IN ('".implode(' \', \'', $idfound)."') AND (ranking_id BETWEEN :item_ranking_first AND :item_ranking_last) AND the_time between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' AND [employeeid] = '$theid' ORDER BY ranking_id ASC");
$statement -> bindValue(':searchthis', '%'.$searchthis.'%');
$statement -> bindParam(':item_ranking_first', $item_ranking_first, PDO::PARAM_INT);
$statement -> bindParam(':item_ranking_last', $item_ranking_last, PDO::PARAM_INT);
$statement -> execute();
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
  array_push($idfound, $row['file_id']);
  $data_count++;
  echo '<div class = "col-md-12">';
  echo '<div onmouseover = "file_color('.$row['file_id'].')" onmouseout = "file_uncolor('.$row['file_id'].')" style = "cursor:pointer;">
  ';
  echo '<div class = "col-md-1 passerbigs"><input type="checkbox" id = "file_mycheck'.$row['file_id'].'" onclick="file_checkbox('.$row['file_id'].')"></div>';
  echo '<div class = "col-md-11" href="#demo'.$row['file_id'].'" data-toggle="collapse">
  ';
  echo '<div class = "col-md-4 passerbigs font_eye_catch font_eye_fast" id = "f_n'.$row['file_id'].'">'.$row['name'].'</div>';
  echo '<div class = "col-md-2 passerbigs font_eye_catch font_eye_fast" id = "f_c'.$row['file_id'].'">'.$row['file_category'].'</div>';
  echo '<div class = "col-md-2 passerbigs font_eye_catch font_eye_fast" id = "f_s'.$row['file_id'].'">'.$row['file_status'].'</div>';
  echo '<div class = "col-md-2 passerbigs font_eye_catch font_eye_fast" id = "d_u'.$row['file_id'].'">'.$row['date_uploaded'].'</div>';
  echo '<div class = "col-md-2 passerbigs font_eye_catch font_eye_fast" id = "f_t'.$row['file_id'].'">'.$row['file_type'].'</div>';
  echo '</div>';
  echo '
  </div>';
  echo '
  </div>
  ';
    echo '
  <div class = "col-md-12 collapse standard_margin_side standard_margin" id="demo'.$row['file_id'].'">
  <div class = "col-md-12">
  <a href = "http://79.125.201.223:8080/cityhall/images/files/'.$row['name'].'" target="_blank" class = "word_button_sky" style = "cursor: pointer; text-decoration:none;">
  <img class = "img-responsive" src="images/status_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
  Open</a>
  <a class = "word_button_sky" style = "cursor: pointer; text-decoration:none;" onclick = "delete_file('.$row['file_id'].')">
  <img class = "img-responsive" src="images/delete.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />
  Delete</a>
  </div>
  </div>
  ';
}
}else{
	$x = 2;
}

}

$total_count = $data_count;
  if(isset($item_ranking_first) AND $item_ranking_first != '' AND isset($item_ranking_last) AND $item_ranking_last != ''){
  echo '<div class = "col-md-12" style = "margin-top: 0%;">
  Displaying items \''.$searchkeyword.'\' <b>Ranking: '.$item_ranking_first.'</b> to <b>'.$item_ranking_last.'</b> out of <b>Total: '.$total_count.'</b>
  </div>';
  }else{
  echo '<div class = "col-md-12" style = "margin-top: 0%;">
  Displaying all items \''.$searchkeyword.'\' from <b>1</b> to <b>15</b> out of <b>Total: '.$total_count.'</b>
  </div>';    
  }
?>