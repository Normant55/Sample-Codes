<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
$metyou = $_GET['metyou'];
	$statement = $dbhsub -> query("SELECT * FROM customdescriptions WHERE dividname LIKE '%$metyou%'");
	while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
		echo '<h4>item no '.$row['descriptid'].'</h4>';
		echo 'Div ID: <input type = "text" value = "'.$row['dividname'].'" id = "dividea'.$row['descriptid'].'">';
		echo 'Div Description: <input type = "text" value = "'.$row['divdescription'].'" id = "divdescriptioner'.$row['descriptid'].'">';
		echo '<button class = "btn-default" onclick = "peeeling('.$row['descriptid'].')">Edit</button>';
		}	


?>