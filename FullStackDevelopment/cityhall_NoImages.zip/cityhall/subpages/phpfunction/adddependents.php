<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$studID =  $_GET['studID'];
$firstname =  $_GET['firstname'];
$middlename =  $_GET['middlename'];
$lastname =  $_GET['lastname'];
$birthdate =  $_GET['birthdate'];


	$query = $dbh->prepare("INSERT INTO employee_children(employeeid, firstname, middle, lastname, birthdate)VALUES(?,?,?,?,?)");
$stmt = $query->execute(array($studID, $firstname, $middlename, $lastname, $birthdate));
if($stmt){
	echo 'Succesfully Added';
}
else{
	echo 'Fail';
}

?> 