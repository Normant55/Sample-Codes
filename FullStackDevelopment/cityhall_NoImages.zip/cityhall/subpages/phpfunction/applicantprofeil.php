<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');

$searchvalue = $_GET['searchvalue'];
		echo '<h4 style = "float: right; margin-top: 5%;margin-right: 5%;">Schedule for Interview: Friday, February 02, 2018</h4>';
echo '<div class = "picture"><img src = "images/profilesample.jpg" style= "width: 100%; height: 19.5vh;"></div>';
	


$stmt = $dbh -> query("SELECT * FROM Applicants WHERE employeeid = '$searchvalue'");
while($row = $stmt -> fetch(PDO::FETCH_ASSOC)){
	echo '<div class = "container-fluid">';
	echo '<div class = "col-md-6">';
	echo '<ul>';
	echo '<li><a>'.$row['fullname'].'</a></li>';
	echo '<li>Home Address: <a>Confidential</a></li>';


      echo '<li>Citizenship: <a>'.$row['citizenship'].'</a></li>';
      echo '<li>Email Address: <a>Confidential</a></li>';
      echo '<li>Marital Status: <a>Confidential</a></li>';
      echo '<li>Birthplace: <a>Confidential</a></li>';
      echo '<li>Department<a>Confidential</a></li>';
      echo '<li>Job Title: <a>Confidential</a></li>';
		echo '</ul>';
	echo '</div>';
	echo '<div class = "col-md-6">';
	echo '<ul>';
      echo '<li>Gender: <a>Confidence</a></li>';
      echo '<li>Course Degree:<a>Confidential</a></li>';
      echo '<li>School Graduated: <a>Confidential</a></li>';
      echo '<li>Eligibility: <a>Confidential</a></li>';
      echo '<li>Special Skills: <a>Confidential</a></li>';


      echo '<li>Date Issued: <a>Confidential</a></li>';

      echo '<li>Religion: <a>Confidential</a></li>';



echo '</ul>';
	echo '</div>';
	echo '</div>';

}



?>