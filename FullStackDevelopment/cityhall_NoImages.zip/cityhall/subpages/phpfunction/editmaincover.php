<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$ok = $_POST['idea'];
$entry = $_POST['entry'];
$editimagepriority = $_POST['editimagepriority'];
$editimagepriority = strip_tags($editimagepriority);
$entry = str_replace("e1p1", "<", $entry);
$entry = str_replace("e1p2", ">", $entry);
$entry = str_replace("e1p3", "\"", $entry);
$entry = str_replace("e1p4", "#", $entry);
$entry = str_replace("e1p5", "(", $entry);
$entry = str_replace("e1p6", ")", $entry);
$entry = str_replace("e1p7", "-", $entry);
$entry = str_replace("e1p8", ":", $entry);
$entry = str_replace("e1p9", "&", $entry);
$entry = str_replace("<head>", " ", $entry);
$entry = str_replace("<body>", " ", $entry);
$mode = $_POST['mode'];
	if($mode == 'title'){
	$statement = $dbhsub -> prepare("UPDATE [covertitleimage] SET [imagetitle] = :entry WHERE [imageid] = :ok");
	$statement->bindParam(':entry', $entry);	
	$statement->bindParam(':ok', $ok);
	$statement -> execute();
	echo 'Successfully changed to '.$entry.'!';


$filestatement = $dbhsub -> query("SELECT [imagetitle] FROM [covertitleimage] WHERE [imageid] = '$ok'");
	while($filerow = $filestatement ->fetch(PDO::FETCH_ASSOC)){
		$title = $filerow['[imagetitle]'];
	}
$titleformeta = strip_tags($title);

$myfile = fopen("../coverthumbs/coverfile".$ok.".html", "w");
$oldfile = "
<!DOCTYPE HTML>
<html lang = \"en\">
<meta charset = \"utf-8\">
<meta property=\"og:description\" content=\"end description\" />
<meta property=\"og:title\" content=\"".$titleformeta."\" />
<script type = \"text/javascript\">
        function viewthiscover(){
        window.location.href = \"http://79.125.201.223:8080/cityhall/index\";
        }
        window.onload = viewthiscover;
</script>
".$title."
";

$statement2 = $dbhsub -> query("SELECT type, description FROM [coverextender] WHERE [imageid] = '$ok'");
while($row2 = $statement2 ->fetch(PDO::FETCH_ASSOC)){

	$description = $row2['description'];
	if($row2['type']=='none'){


		$oldfile = str_replace("<html lang = \"en\">", " <html lang = \"en\"> <meta property=\"og:image\" content=\"http://79.125.201.223:8080/cityhall/images/coverimages/".$ok.".png\" />", $oldfile);


	}else{

		$description = strip_tags($description);
		$oldfile = str_replace("<meta property=\"og:description\" content=\"", "<meta property=\"og:description\" content=\"".$description." ", $oldfile);
		$oldfile = str_replace("</script>", "</script> ".$description, $oldfile);

	}
}
		fwrite($myfile, $oldfile);
		fclose($myfile);
//$mode
	}else{
	$statement = $dbhsub -> prepare("UPDATE [coverextender] SET description = :entry, prioritycode = :editimagepriority WHERE [extenderid] = :ok");
	$statement->bindParam(':entry', $entry);
	$statement->bindParam(':ok', $ok);
	$statement->bindParam(':editimagepriority', $editimagepriority);
	$statement -> execute();
	if($entry == 'none'){
	echo 'Successfully priority!';		
	}else{
	echo 'Successfully changed to '.$entry.'!';
	}

$statement = $dbhsub -> query("SELECT [imageid] FROM [coverextender] WHERE [extenderid] = '$ok'");
while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
	$newsid = $row['imageid'];

$filestatement = $dbhsub -> query("SELECT [imagetitle] FROM [covertitleimage] WHERE [imageid] = '$newsid'");
	while($filerow = $filestatement ->fetch(PDO::FETCH_ASSOC)){
		$title = $filerow['imagetitle'];
	}
$titleformeta = strip_tags($title);

$myfile = fopen("../coverthumbs/coverfile".$newsid.".html", "w");
$oldfile = "
<!DOCTYPE HTML>
<html lang = \"en\">
<meta charset = \"utf-8\">
<meta property=\"og:description\" content=\"end description\" />
<meta property=\"og:title\" content=\"".$titleformeta."\" />
<script type = \"text/javascript\">
        function viewthiscover(){
        window.location.href = \"http://79.125.201.223:8080/cityhall/index\";
        }
        window.onload = viewthiscover;
</script>
".$title."
";

$statement2 = $dbhsub -> query("SELECT [extenderid], type, description FROM [coverextender] WHERE [imageid] = '$newsid'");
while($row2 = $statement2 ->fetch(PDO::FETCH_ASSOC)){
	$newscontentid = $row2['extenderid'];
	$description = $row2['description'];
	if($row2['type']=='none'){


		$oldfile = str_replace("<html lang = \"en\">", " <html lang = \"en\"> <meta property=\"og:image\" content=\"http://79.125.201.223:8080/cityhall/images/coverimages/".$newscontentid.".png\" />", $oldfile);
	}else{

		$description = strip_tags($description);
		$oldfile = str_replace("<meta property=\"og:description\" content=\"", "<meta property=\"og:description\" content=\"".$description." ", $oldfile);
		$oldfile = str_replace("</script>", "</script> ".$description, $oldfile);

	}
}
		fwrite($myfile, $oldfile);
		fclose($myfile);
}


	}



?>