<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");

$firstname = strip_tags($_GET['firstname']);
$firstname = strtoupper($firstname);
$middlename = strip_tags($_GET['middlename']);
$middlename = strtoupper($middlename);
$lastname = strip_tags($_GET['lastname']);
$lastname = strtoupper($lastname);
$username = $_GET['username'];
$username = strip_tags($username);

$errorlog = 0;
$statement = $dbh -> query("SELECT count(*) FROM Applicants WHERE firstname = '$firstname' AND middle = '$middlename' AND lastname = '$lastname'");
if($statement ->fetchColumn()>0){
	echo 'fn';
	$errorlog++;
}

$statement = $dbh -> query("SELECT count(*) FROM applicantlogin WHERE username = '$username'");
if($statement ->fetchColumn()>0){
	if($errorlog == 1){
	echo 'au';
	}else{
	echo 'u';
	}
	$errorlog++;
}else{
$statement = $dbh -> query("SELECT count(*) FROM userlogn WHERE username = '$username'");
if($statement ->fetchColumn()>0){
	if($errorlog == 1){
	echo 'au';
	}else{
	echo 'u';
	}
	$errorlog++;
}	
}

if($errorlog==0){
	echo 'Success';
}



?>