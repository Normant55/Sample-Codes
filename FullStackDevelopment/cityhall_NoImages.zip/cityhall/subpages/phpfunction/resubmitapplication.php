<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$myid = $_POST['myid'];                 
$course = $_POST['course']; 
//     $course2 = $_POST['course2'];
// $course = $course.', '.$course2;
$schoolgraduated = $_POST['schoolgraduated'];            
$eligibility = $_POST['eligibility'];         
$dep = $_POST['departments'];
// $dep = $dep.", ";
$experience = $_POST['experience'];
// $yearone = $_POST['yearone'];
$training = $_POST['training'];
$special_skills = $_POST['special_skills'];
$sarray = array();
$targe = array();
$fordeptab = array();
$dep = str_replace("<li><a>", "", $dep);
$dep = str_replace("</a></li>", ", ", $dep);
$sarray = explode(", ", $dep);
$arraycounter = count($sarray);
for($min = 0; $min<$arraycounter; $min++){
$what_you_want = substr($sarray[$min], 0, strpos($sarray[$min], ':'));
 array_push($fordeptab, $what_you_want);
$jobdescription = str_replace($what_you_want.':', '', $sarray[$min]);
 array_push($targe, $jobdescription);
}
  //   $queryforabbriv = "select deptAbbriv from OfficeHeaders WHERE Department = '".implode('\' OR Department = \'',$sarray)."'";
  // $stmtdepabbriv = $dbhbudget -> query($queryforabbriv);
  // while($row = $stmtdepabbriv -> fetch( PDO::FETCH_ASSOC )){
  //     array_push($targe, $row['deptAbbriv']);
  //   }

  $deptarmentschoosen = implode(", ", $targe);
  $debabbriv = implode(", ", $fordeptab);
//.date("F jS \of Y");
$course = strip_tags($course);
$schoolgraduated = strip_tags($schoolgraduated);
$eligibility = strip_tags($eligibility);
$experience = strip_tags($experience);
$training = strip_tags($training);
$special_skills = strip_tags($special_skills);
$stmt = $dbh -> prepare("UPDATE Applicants SET course_degree = :course, school_grad = :schoolgraduated, job_title = :deptarmentschoosen, dept_abbriv = :debabbriv, eligibility = :eligibility, experience = :experience, training = :training, special_skills = :special_skills WHERE employeeid = :myid");
$stmt->bindParam(':course', $course);
$stmt->bindParam(':schoolgraduated', $schoolgraduated);
$stmt->bindParam(':deptarmentschoosen', $deptarmentschoosen);
$stmt->bindParam(':debabbriv', $debabbriv);
$stmt->bindParam(':eligibility', $eligibility);
$stmt->bindParam(':experience', $experience);
$stmt->bindParam(':training', $training);
$stmt->bindParam(':special_skills', $special_skills);
$stmt->bindParam(':myid', $myid);
$stmt->execute();

if($stmt){
  echo 'Successfully Uploaded Application';
}
else{
  echo 'Failed Query to Uploaded Application';
}


?>