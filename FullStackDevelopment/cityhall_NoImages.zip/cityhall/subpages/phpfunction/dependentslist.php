<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');

$theconnection =  $_GET['connection'];
$theids =  $_GET['studID'];
$query = "select *,CONVERT(VARCHAR(10),birthdate,101) AS birthday from employee_children WHERE employeeid = '$theids'";
$stmt = $dbh -> query($query);
// echo $theids;
// echo 'ahahah';
echo '<div class = "row">';
echo '<div class = "col-md-3">Firstname</div>';
echo '<div class = "col-md-3">Middlename</div>';
echo '<div class = "col-md-3">Lastname</div>';
echo '<div class = "col-md-2">Birthdate</div>';
echo '<div class = "col-md-1"></div>';
echo '</div>';
while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
                 //echo '<div class = "infotab"> Database ID: '.$row['Student_ID'];
                 echo '<div class = "row">';
                 echo '<div class = "col-md-3">
               '.$row['firstname'];
                 echo '</div>'; 
                 echo '<div class = "col-md-3">
                '.$row['middle'];
                 echo '</div>';      
                 echo '<div class = "col-md-3">
                '.$row['lastname'];
                 echo '</div>';       
                 echo '<div class = "col-md-2">
                '.$row['birthday'];
                 echo '</div>'; 
                echo '<div class = "col-md-1"><img src = "images/delete.png" style = "width: 100%; cursor: pointer;" onclick = "erasedependent('.$row['child_numb'].')">
                ';
                 echo '</div>'; 
                 echo '</div>';  
}
       
?>