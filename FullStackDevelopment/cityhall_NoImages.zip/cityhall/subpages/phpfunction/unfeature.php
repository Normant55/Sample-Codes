<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");
$data = $_POST['data'];
$statement = $dbhsub -> query("UPDATE mainnews SET featured = 'no' WHERE newsid = '$data'");
if($statement){
}
?>