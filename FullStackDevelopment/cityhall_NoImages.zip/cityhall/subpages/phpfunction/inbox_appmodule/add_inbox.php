<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../../php/connectPDO.php");
$inputname = $_GET['inputname'];
$inputcontact = $_GET['inputcontact'];
$inputlevel = $_GET['inputlevel'];
$inputscore = $_GET['inputscore'];
$inputresult = $_GET['inputresult'];
$inputremarks = $_GET['inputremarks'];
$inputdate = $_GET['inputdate'];
$inputtime = $_GET['inputtime'];
$statement = $dbhsub ->prepare("INSERT INTO examinee(name, contact, elevel, score, result, remarks, takendate, takentime)values(:inputname, :inputcontact, :inputlevel, :inputscore, :inputresult, :inputremarks, :inputdate, :inputtime);");
$statement -> bindParam(":inputname", $inputname);
$statement -> bindParam(":inputcontact", $inputcontact);
$statement -> bindParam(":inputlevel", $inputlevel);
$statement -> bindParam(":inputscore", $inputscore);
$statement -> bindParam(":inputresult", $inputresult);
$statement -> bindParam(":inputremarks", $inputremarks);
$statement -> bindParam(":inputdate", $inputdate);
$statement -> bindParam(":inputtime", $inputtime);
$statement -> execute();
if($statement){
	"Successful Query";
}
else{
	"Failed Query";
}
?>