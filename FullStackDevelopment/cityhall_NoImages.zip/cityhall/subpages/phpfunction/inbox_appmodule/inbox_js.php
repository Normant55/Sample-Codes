<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
header('Content-Type: application/javascript');
?>
function searchengine_item(){
                 searchkeyword = document.getElementById("searchkeyword").value;
                 item_ranking_first = document.getElementById("item_ranking_first").value;
                 //item_ranking_last = document.getElementById("item_ranking_last").value;
                 userprof = window.localStorage.getItem("loginuser");
                 window.localStorage.setItem("searchkeyword", searchkeyword);
                 window.localStorage.setItem("item_ranking_first", item_ranking_first);
                 //window.localStorage.setItem("item_ranking_last", item_ranking_last);
        if(searchkeyword != ''){
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("inboxlist_box").innerHTML = this.responseText;
            }
            };
            xmlhttp.open("GET", "subpages/phpfunction/inbox_appmodule/searchengine.php?searchkeyword="+searchkeyword+"&item_ranking_first="+item_ranking_first+"&userprof="+userprof, true);
            xmlhttp.send();
        }else{
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("inbox").innerHTML = this.responseText;
            }
            };
            xmlhttp.open("GET", "subpages/phpfunction/inbox_appmodule/inbox_list.php?searchkeyword="+searchkeyword+"&item_ranking_first="+item_ranking_first+"&userprof="+userprof, true);
            xmlhttp.send();
        }
}

                function inbox_color(highlight){
                  document.getElementById("i_mo"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("i_mt"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("i_dt"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                  document.getElementById("i_do"+highlight).style.backgroundColor = "rgba(240,100,100,1)";
                }
                function inbox_uncolor(highlight){
                  document.getElementById("i_mo"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("i_mt"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("i_dt"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                  document.getElementById("i_do"+highlight).style.backgroundColor = "rgba(240,100,100,0)";
                }

                function delete_message(targetid){
                  if(confirm("Are you sure you want to delete the item?")){
                    var xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function(){
                      if(this.readyState == 4 && this.status == 200) {
                          alert(this.responseText);
                          searchengine_item();
                      } 
                    };
                    xmlhttp.open("GET", "subpages/phpfunction/inbox_appmodule/delete.php?deletevalue="+targetid, true);
                    xmlhttp.send();
                  }
                }
                function deleteselected_inbox(){
                  if(confirm("Are you sure you want to delete the selected?")){
                    mashael_inbox = window.localStorage.getItem("mashael_inbox");
                    mashael_inbox = mashael_inbox.slice(0, -1);
                  
                    var xmlhttp = new XMLHttpRequest();
                    xmlhttp.onreadystatechange = function(){
                      if(this.readyState == 4 && this.status == 200){
                        alert(this.responseText);
                        window.localStorage.setItem("mashael_inbox", "");
                        searchengine_item();
                      }
                    };
                    xmlhttp.open("GET", "subpages/phpfunction/inbox_appmodule/deletebulk.php?deletevalue="+mashael_inbox, true);
                    xmlhttp.send();
                  }
                }
                function inbox_checkbox(thisa){
                if(document.getElementById("inbox_mycheck"+thisa).checked === true){
                  mashael_inbox = window.localStorage.getItem("mashael_inbox");
                  window.localStorage.setItem("mashael_inbox", mashael_inbox+thisa+",");
                  mashael_inbox = window.localStorage.getItem("mashael_inbox");
                }else{
                  mashael_inbox = window.localStorage.getItem("mashael_inbox");
                  tempshell_inbox = ","+mashael_inbox;
                  mashael_inbox = tempshell_inbox.replace(","+thisa+",", ",");
                  mashael_inbox = mashael_inbox.substr(1);
                  window.localStorage.setItem("mashael_inbox", mashael_inbox);
                }
                
                }

                function update_view(message_id){
                function return_countdata(data){
                amount = data;
                if(amount!=0){
                crud_function_preset_noload_noalert('message_id = :message_id',''+message_id+'','date_opened','GETDATE()','[biosub].[dbo].[message_records]', '', '', 'UPDATE', 'Successfully Updated!', 'dbhsub');
                }else{
                }
                }
                search_query('message_id=:message_id AND date_opened IS NULL', '[biosub].[dbo].[message_records]', '', ''+message_id+'', '', 'countallby', '', 'dbhsub', return_countdata);
                }