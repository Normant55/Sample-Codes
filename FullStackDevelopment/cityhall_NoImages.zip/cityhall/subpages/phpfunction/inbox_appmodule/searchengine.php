<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../../php/connectPDO.php");
$searchkeyword = $_GET['searchkeyword'];
if((!isset($_GET['item_ranking_first']) OR ($_GET['item_ranking_first']==''))){
  $item_ranking_first = 1;
  // $item_ranking_last = 15;
}else{
  $item_ranking_first = $_GET['item_ranking_first'];
  $first_page = ($item_ranking_first*15+1)-15;
  // $item_ranking_last = $_GET['item_ranking_last'];
}
$userprof = $_GET['userprof'];

$data_count = 0;
$keyarray = array();
$keyarray = explode(" ", $searchkeyword);
$idfound = array();
$x = 1;
$current = 0;
while($x<2){
	if(isset($keyarray[$current]) && $keyarray[$current]!=''){
	$searchthis = $keyarray[$current];
	$current++;
$statement = $dbhsub -> prepare("SELECT * FROM (SELECT message_title, target_username, message_id, message_content, message_origin, date_recieved, date_opened, ROW_NUMBER() OVER(ORDER BY date_recieved DESC) AS ranking_id FROM message_records WHERE target_username = :userprof AND (message_title LIKE :searchthis OR target_username LIKE :searchthis2 OR message_content LIKE :searchthis3 OR message_origin LIKE :searchthis4)) AS A WHERE (ranking_id BETWEEN :item_ranking_page AND (:item_ranking_first*15)) AND target_username = :userprof2 AND (message_title LIKE :searchthis5 OR target_username LIKE :searchthis6 OR message_content LIKE :searchthis7 OR message_origin LIKE :searchthis8) AND message_id NOT IN ('".implode(' \', \'', $idfound)."') ORDER BY ranking_id ASC");
$statement -> bindValue(':searchthis', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis2', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis3', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis4', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis5', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis6', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis7', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis8', '%'.$searchthis.'%');
$statement -> bindParam(':userprof', $userprof, PDO::PARAM_STR);
$statement -> bindParam(':userprof2', $userprof, PDO::PARAM_STR);
$statement -> bindParam(':item_ranking_page', $first_page, PDO::PARAM_INT);
$statement -> bindParam(':item_ranking_first', $item_ranking_first, PDO::PARAM_INT);
$statement -> execute();
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
array_push($idfound, $row['message_id']);
// $data_count++;
  echo '<div class = "col-md-12">';
	echo '<div onmouseover = "inbox_color('.$row['message_id'].')" onmouseout = "inbox_uncolor('.$row['message_id'].')" style = "cursor:pointer;">
  ';
  // echo '<div class = "col-md-1"><input type="checkbox" name="varanq[]" value="'.$row['message_id'].'"></div>';
  echo '<div class = "col-md-1 passerbigs"><input type="checkbox" id = "inbox_mycheck'.$row['message_id'].'" onclick="inbox_checkbox('.$row['message_id'].')"></div>';
  echo '<div class = "col-md-11" href="#demo'.$row['message_id'].'" data-toggle="collapse">
  ';
  echo '<div class = "col-md-2 passerbigs" id = "i_mo'.$row['message_id'].'">'.$row['message_origin'].'</div>';
  echo '<div class = "col-md-6 passerbigs" id = "i_mt'.$row['message_id'].'">'.$row['message_title'].'</div>';
  echo '<div class = "col-md-2 passerbigs" id = "i_dt'.$row['message_id'].'">'.$row['date_recieved'].'</div>';
  echo '<div class = "col-md-2 passerbigs" id = "i_do'.$row['message_id'].'">'.$row['date_opened'].'</div>';
	echo '</div>';
  $final_message_content = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $row['message_content']);
	echo '
  </div>
  <div class = "col-md-12 collapse standard_margin_side standard_margin" id="demo'.$row['message_id'].'">
  <div class = "col-md-12" style = "word-wrap: break-word;">Message Content:</div>
  <div class = "col-md-12 message_default" style = "word-wrap: break-word;">'.$final_message_content.'</div>
  <div class = "col-md-12">
  <a class = "word_button_sky" style = "cursor: pointer; text-decoration:none;" onclick = "delete_message('.$row['message_id'].')">
  Delete</a>
  </div>
  </div>
  </div>
  ';

	}

}else{
	$x = 2;
}

}
// $total_count = $data_count;
  if(isset($item_ranking_first) AND $item_ranking_first != ''){
  echo '<div class = "col-md-12" style = "margin-top: 0%;">
  Displaying items \''.$searchkeyword.'\' <b>Page: '.$item_ranking_first.'</b>
  </div>';
  }else{
  echo '<div class = "col-md-12" style = "margin-top: 0%;">
  Displaying all items \''.$searchkeyword.'\' from <b>1</b> to <b>15</b> out of <b>Total: '.$total_count.'</b>
  </div>';    
  }
?>