<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../../php/connectPDO.php");
$searchkeyword = $_GET['searchkeyword'];
$item_ranking_first = $_GET['item_ranking_first'];
// $item_ranking_last = $_GET['item_ranking_last'];
$userprof = $_GET['userprof'];

if(isset($item_ranking_first) AND $item_ranking_first != ''){
$first_page = ($item_ranking_first*15+1)-15;
$statement = $dbhsub -> prepare("SELECT * FROM (SELECT message_title, target_username, message_id, message_content, message_origin, date_recieved, date_opened, ROW_NUMBER() OVER(ORDER BY date_recieved DESC) AS ranking_id FROM message_records WHERE target_username = :userprof) AS A WHERE (ranking_id BETWEEN :item_ranking_page AND (:item_ranking_first*15)) AND target_username = :userprof2 ORDER BY ranking_id ASC");
$statement -> bindParam(':userprof', $userprof, PDO::PARAM_STR);
$statement -> bindParam(':userprof2', $userprof, PDO::PARAM_STR);
$statement -> bindParam(':item_ranking_page', $first_page, PDO::PARAM_INT);
$statement -> bindParam(':item_ranking_first', $item_ranking_first, PDO::PARAM_INT);

$statement_count = $dbhsub -> prepare("SELECT count(*) FROM (SELECT target_username, ROW_NUMBER() OVER(ORDER BY date_recieved DESC) AS ranking_id FROM message_records WHERE target_username = :userprof_count) AS A WHERE target_username = '$userprof' AND (ranking_id BETWEEN :item_ranking_page_count AND (:item_ranking_first_count*15))");
$statement_count -> bindParam(':userprof_count', $userprof, PDO::PARAM_STR);
$statement_count -> bindParam(':item_ranking_page_count', $first_page, PDO::PARAM_INT);
$statement_count -> bindParam(':item_ranking_first_count', $item_ranking_first, PDO::PARAM_INT);
$statement_count -> execute();
$total_count = $statement_count->fetchColumn();
$total_count = $total_count/15+1;
}else{
$statement = $dbhsub -> prepare("SELECT * FROM (SELECT message_title, target_username, message_id, message_content, message_origin, date_recieved, date_opened, ROW_NUMBER() OVER(ORDER BY date_recieved DESC) AS ranking_id FROM message_records  WHERE target_username = :userprof3) AS A WHERE (ranking_id BETWEEN 1 AND 15) AND target_username = :userprof4 ORDER BY ranking_id ASC");
$statement -> bindParam(':userprof3', $userprof, PDO::PARAM_STR);
$statement -> bindParam(':userprof4', $userprof, PDO::PARAM_STR);
$statement_count = $dbhsub -> prepare("SELECT count(*) FROM (SELECT target_username, ROW_NUMBER() OVER(ORDER BY date_recieved DESC) AS ranking_id FROM message_records WHERE target_username = :userprof_count2) AS A WHERE target_username = '$userprof' AND (ranking_id BETWEEN 1 AND 15)");
$statement_count -> bindParam(':userprof_count2', $userprof, PDO::PARAM_STR);
$statement_count -> execute();
$total_count = $statement_count->fetchColumn();
$total_count = $total_count/15+1;
}
$statement -> execute();
	echo '<div class = "no_lining">
  <a onclick = "reto(\'default\')" style = "cursor:pointer;">
  <img class = "img-responsive" src="images/return_logo.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  "/>
  Exit</a></div>';
  echo '<div class = "col-md-12" style = "margin-top: 0%;">

  <h3>Search Message</h3>
  <div class = "col-md-4">
  File
  <input type = "text" class = "input_standard" onkeyup = "searchengine_item()" id ="searchkeyword"';if($searchkeyword!=''){echo'value = "'.$searchkeyword.'"';} echo' placeholder = "Search Keyword..." style = "width: 100%; margin-right: 2.5%;"></div>';
  echo '  <div class = "col-md-1">Page<input type = "number" class = "input_standard" style = "width: 100%;" ';if($item_ranking_first!=''){echo'value = "'.$item_ranking_first.'"';} echo' onkeyup = "searchengine_item()" id ="item_ranking_first"></div>';
  // echo '<div class = "col-md-1">To <input type = "number" class = "input_standard" style = "width: 100%;" ';if($item_ranking_last!=''){echo'value = "'.$item_ranking_last.'"';} echo' onkeyup = "searchengine_item()" id = "item_ranking_last"></div></div>';


  echo '
  <div class = "col-md-12 standard_margin">
  <div class = "col-md-12">
  <div class = "word_button_sky" style = "cursor: pointer; display: inline-flex; line-height: 30px;"
  href="#demo_message" data-toggle="collapse">
  <img class = "img-responsive" src="images/email.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />Compose</div>

  <div class = "word_button_sky" style = "cursor: pointer; display: inline-flex; line-height: 30px;" onclick = "selectall()">
  <img class = "img-responsive" src="images/logo_add.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />Select All</div>

  <div class = "word_button_sky" style = "cursor: pointer; display: inline-flex; line-height: 30px;" onclick = "deleteselected_inbox()">
  <img class = "img-responsive" src="images/delete.png" alt="image test" 
  style = "
  position: relative;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: 20% 50%;
  background-color: rgba(200,200,200, 0);
  height: 30px;
  display: inline-block;
  " />Delete</div>

  </div>

  <div class = "col-md-12 collapse" id="demo_message">
  <li class = "standard_li">Message</li>
  <textarea class = "textarea_standard" id = "my_message"></textarea>
  <li class = "standard_li">To Username</li>
  <input type = "text" class = "input_standard" id = "to_username">

  <a class = "word_button_sky" style = "cursor:pointer; text-decoration: none;" onclick = "crud_function_preset(\'\',\'\',\'date_recieved\',\'GETDATE()\',\'message_records\', \'message_content*-, target_username*-, message_origin*-, message_title\', document.getElementById(\'my_message\').value+\'*-, \'+document.getElementById(\'to_username\').value+\'*-, '.$userprof.'*-, CHRMO LGU-Iligan City\', \'INSERT\', \'Message Sent!\', \'dbhsub\')">Send Message</a>
  </div>
  </div>

  <div class = "col-md-1 passerbiga"></div>
  <div class = "col-md-11">
  <div class = "col-md-2 passerbiga">From</div>
  <div class = "col-md-6 passerbiga">Title</div> 
  <div class = "col-md-2 passerbiga">Date Recieved</div>
  <div class = "col-md-2 passerbiga">Date Opened</div>
  </div>
  <div id = "inboxlist_box">
  ';
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
  echo '<div class = "col-md-12">';
	echo '<div onmouseover = "inbox_color('.$row['message_id'].')" onmouseout = "inbox_uncolor('.$row['message_id'].')" style = "cursor:pointer;">
  ';
  echo '<div class = "col-md-1 passerbigs"><input type="checkbox" id = "inbox_mycheck'.$row['message_id'].'" onclick="inbox_checkbox('.$row['message_id'].')"></div>';
  echo '<div class = "col-md-11" href="#demo'.$row['message_id'].'" data-toggle="collapse" onclick = " update_view('.$row['message_id'].')">
  ';
	echo '<div class = "col-md-2 passerbigs" id = "i_mo'.$row['message_id'].'">'.$row['message_origin'].'</div>';
	echo '<div class = "col-md-6 passerbigs" id = "i_mt'.$row['message_id'].'">'.$row['message_title'].'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "i_dt'.$row['message_id'].'">'.$row['date_recieved'].'</div>';
	echo '<div class = "col-md-2 passerbigs" id = "i_do'.$row['message_id'].'">'.$row['date_opened'].'</div>';
	echo '</div>';
  $final_message_content = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $row['message_content']);
	echo '
  </div>
  <div class = "col-md-12 collapse standard_margin_side standard_margin" id="demo'.$row['message_id'].'">
  <div class = "col-md-12" style = "word-wrap: break-word;">Message Content:</div>
  <div class = "col-md-12 message_default" style = "word-wrap: break-word;">'.$final_message_content.'</div>
  <div class = "col-md-12">
  <a class = "word_button_sky" style = "cursor: pointer; text-decoration:none;" onclick = "delete_message('.$row['message_id'].')">
  Delete</a>
  </div>
  </div>
  </div>
  ';
}
  if(isset($item_ranking_first) AND $item_ranking_first != ''){
  echo '<div class = "col-md-12" style = "margin-top: 0%;">
  Displaying items <b>Page: '.$item_ranking_first.'</b> out of <b>Total: '.$total_count.'</b>
  </div>';
  }else{
  echo '<div class = "col-md-12" style = "margin-top: 0%;">
  Displaying all items from Page <b>One</b> out of <b>Total: '.$total_count.'</b>
  </div>';    
  }
?>