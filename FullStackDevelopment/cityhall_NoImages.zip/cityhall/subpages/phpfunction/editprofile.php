<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');


$studID =  $_POST['studID'];
$marital_status =  $_POST['marital_status'];
$home_address =  $_POST['home_address'];
$home_phone =  $_POST['home_phone'];
$mobile_no =  $_POST['mobile_no'];
$citizenship =  $_POST['citizenship'];
$email_address =  $_POST['email_address'];
$email_address = strip_tags($email_address);
$birthplace =  $_POST['birthplace'];
$tin_number =  $_POST['tin_number'];
$sssgsis_number =  $_POST['sssgsis_number'];
$sssgsis_contrib =  $_POST['sssgsis_contrib'];
$philhealth_no =  $_POST['philhealth_no'];
$philhealth_contrib =  $_POST['philhealth_contrib'];
$pagibig_no =  $_POST['pagibig_no'];
          $pagibig_contrib =  $_POST['pagibig_contrib'];
          $spouse =  $_POST['spouse'];
          $spouse_address=  $_POST['spouse_address'];
          $no_dependents =  $_POST['no_dependents'];
          $landline=  $_POST['landline'];
          $flastname =  $_POST['flastname'];
          $ffirstname =  $_POST['ffirstname'];         
          $fmiddle=  $_POST['fmiddle'];
          $mlastname =  $_POST['mlastname'];
          $mfirstname =  $_POST['mfirstname'];
          $mmiddle =  $_POST['mmiddle'];
          $spousefirstname=  $_POST['spousefirstname'];
          $spousemiddle =  $_POST['spousemiddle'];
          $religion=  $_POST['religion'];
          $gender=  $_POST['gender'];



	$query = $dbh->prepare("UPDATE employee SET marital_status = ?, home_address = ?, home_phone = ?, mobile_no = ?, citizenship = ?, flastname = ?, ffirstname = ?, spouse = ?, email_address = ?, birthplace = ?, tin_number = ?, sssgsis_number = ?, sssgsis_contrib = ?, philhealth_no = ?, philhealth_contrib = ?, pagibig_no = ?, pagibig_contrib = ?, spouse_address = ?, no_dependents = ?, landline = ?, fmiddle = ?, mlastname = ?, mfirstname = ?, mmiddle = ?, spousefirstname = ?, spousemiddle = ?, religion = ?, gender = ? WHERE employeeid = ?");
$stmt = $query->execute(array($marital_status, $home_address, $home_phone, $mobile_no, $citizenship,$flastname, $ffirstname, $spouse, $email_address, $birthplace,$tin_number, $sssgsis_number, $sssgsis_contrib, $philhealth_no, $philhealth_contrib,$pagibig_no, $pagibig_contrib, $spouse_address, $no_dependents, $landline,$fmiddle, $mlastname, $mfirstname, $mmiddle, $spousefirstname,$spousemiddle, $religion, $gender, $studID));
if($stmt){
	echo 'Succesful';
}
else{
	echo 'Fail';
}
?> 