<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
function strafter($string, $substring) {
  $pos = strpos($string, $substring);
  if ($pos === false)
   return $string;
  else  
   return(substr($string, $pos+strlen($substring)));
}



include('../../php/connectPDO.php');
// echo '<h2>Positions</h2>';
$query = $dbh -> query("SELECT Count(Distinct[Poscode]) FROM ITEMS");
$amount = $query -> fetchColumn();
echo '<div class="tab">';
$counter = $amount/30;
$starting = 1;
echo '<h3><a class = "clickable_button" style = "text-decoration:none; z-index: 999;" href = "subpages/jobapplicant">Start Application</a></h3>
<h3>Note</h3>
<p>Start registration to submit personnal information and user login, when you are logged in to your user account, you can start to choose the item you want to apply for and submit other documents in the File tab.</p>
';
echo '
<ul>
Requirements
<li>Personnal Data Sheet</li>
<li>Resume/CV, TOR, Birthcertificate, Diploma</li>
<li>2x2 Photo</li>
</ul>
<h4>Select page number below to view available job positions</h4>';
while($starting<=$counter+1){
echo ' <button class="tablinks" onclick="openCity(event, \'rain'.$starting.'\')">'.$starting.'</button>';
$starting++;
}
echo '</div>';
$counterlimit = 1;
$bash = 1;
$query = $dbh -> query("SELECT Distinct[Poscode], [Itemnos], Position, DeptDesc, Poscode, Deptcode, Grade, Step, Rate FROM ITEMS");
while($row = $query -> fetch(PDO::FETCH_ASSOC)){

	if($counterlimit==31){
		$counterlimit = 1;
			echo '</div>';
	}

	if($counterlimit == 1){
		echo '<div id="rain'.$bash.'" class="tabcontent">';
		$bash++;
	}

$stringsearch = $row['DeptDesc'];
$stringsearch = str_replace('\'', '`', $stringsearch);

echo '
<div class = "col-md-12" style = "margin-bottom: 50px">
<div class = "col-md-1 passerbigs">
Item No: '.$row['Itemnos'].'
</div>
<div class = "col-md-1 passerbigs">
Code: '.$row['Poscode'].'
</div>
<div class = "col-md-2 passerbigs">
'.$row['Position'].'
</div>
<div class = "col-md-1 passerbigs">
'.$row['Deptcode'].'
</div>
<div class = "col-md-4 passerbigs">
'.$row['DeptDesc'].'
</div>
<div class = "col-md-1 passerbigs">
Grade:'.$row['Grade'].'
</div>
<div class = "col-md-1 passerbigs">
Step: '.$row['Step'].'
</div>
<div class = "col-md-1 passerbigs">
Rate: '.$row['Rate'].'
</div>
</div>
';



	$counterlimit ++;



}
echo '</div>';






?>
<!-- Tab content -->