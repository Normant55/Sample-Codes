<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');


$theids =  $_GET['studID'];
$query = "select * from employee t1 INNER JOIN userlogn t2 on t1.employeeid = t2.employeeid WHERE t1.employeeid = '$theids'";
$stmt = $dbh -> query($query);



while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
                 //echo '<div class = "infotab"> Database ID: '.$row['Student_ID'];

                echo '

                        <div class="jumbotron name_space information_eye">
                                  <a class="navbar-brand">'.strip_tags($row['fullname']).'</a><div class = "col-md-12"><a class="navbar-brand">ID No. '.$row['employeeid'].'</a></div>
        </div>    
          ';
      echo '<div class = "col-md-4 font_eye_fast">
                 Given Name:<div class = "infotab">'.strip_tags($row['firstname']);
                 echo '</div>   
                 Middle Name:<div class = "infotab">'.$row['middle'];
                 echo '</div> 
                 Surname:<div class = "infotab">'.$row['lastname'];
                 echo '</div> 
                 Marital Status:<select id = "marital_status" class = "inputtab">
                 <option value = 1';if($row['marital_status']==1){echo' selected';}echo'>Single</option>
                 <option value = 2';if($row['marital_status']==2){echo' selected';}echo'>Married</option>
                 <option value = 3';if($row['marital_status']==3){echo' selected';}echo'>Widower</option>
                 <option value = 4';if($row['marital_status']==4){echo' selected';}echo'>Separated</option>
                </select>
                 ';
                 echo '
                 Entrance to Duty:<div class = "infotab">'.$row['entrance_to_duty'];
                 echo '</div> 
                 Fullname:<div class = "infotab">'.strip_tags($row['fullname']);
                 echo '</div> Home Address:<input type = "text" id = "home_address" class = "inputtab" value = "'.strip_tags($row['home_address']).'">';
                 echo ' Home Phone:<input type = "text" id = "home_phone" class = "inputtab" value = "'.strip_tags($row['home_phone']).'">';
                 echo ' Mobile Number:<input type = "text" id = "mobile_no" class = "inputtab" value = "'.strip_tags($row['mobile_no']).'">';
                 echo ' Citizenship:<input type = "text" id = "citizenship" class = "inputtab" value = "'.strip_tags($row['citizenship']).'">';
                 echo ' Email Address:<input type = "text" id = "email_address" class = "inputtab" value = "'.strip_tags($row['email_address']).'">';
                 echo ' Birthdate:<div class = "infotab">'.strip_tags($row['birthdate']);
                 echo '</div> Age:<div class = "infotab">'.strip_tags($row['age']);
                 echo '</div> Birthplace:<input type = "text" id = "birthplace" class = "inputtab" value = "'.strip_tags($row['birthplace']).'">';
                 echo ' Department Abbrivation:<div class = "infotab"> '.strip_tags($row['dept_abbriv']);
                 echo '</div> Job Title:<div class = "infotab">'.strip_tags($row['job_title']);
                 echo '</div> Work Schedule:<div class = "infotab">'.strip_tags($row['work_sched']);
                 echo '</div> Job Status:<div class = "infotab">'.strip_tags($row['job_status']);

                 echo '</div></div><div class = "col-md-4 font_eye_fast"> Work Status:<div class = "infotab">'.strip_tags($row['work_status']);
                 echo '</div> Tin Number:<input type = "text" id = "tin_number" class = "inputtab" value = "'.strip_tags($row['tin_number']).'">';
                 echo ' SSS GSIS number:<input type = "text" id = "sssgsis_number" class = "inputtab" value = "'.strip_tags($row['sssgsis_number']).'">';
                 echo ' SSS GSIS contribution:<input type = "number" id = "sssgsis_contrib" class = "inputtab" value = "'.strip_tags($row['sssgsis_contrib']).'">';
                 echo ' Philhealth Number:<input type = "text" id = "philhealth_no" class = "inputtab" value = "'.strip_tags($row['philhealth_no']).'">';
                 echo ' Philhealth contribution:<input type = "number" id = "philhealth_contrib" class = "inputtab" value = "'.strip_tags($row['philhealth_contrib']).'">';
                 echo ' Pagibig Number:<input type = "text" id = "pagibig_no" class = "inputtab" value = "'.strip_tags($row['pagibig_no']).'">';
                 echo ' Pagibig contribution:<input type = "number" id = "pagibig_contrib" class = "inputtab" value = "'.strip_tags($row['pagibig_contrib']).'">';
                 echo ' Tax Category:<div class = "infotab"> '.strip_tags($row['taxcategory']);
                 echo '</div> Gender:<select id = "gender" class = "inputtab">
                 <option value = 0';if($row['gender']==0){echo' selected';}echo'>Female</option>
                 <option value = 1';if($row['gender']==1){echo' selected';}echo'>Male</option>
                 </select>
                 ';
                 echo 'Course Degree:<div class = "infotab">'.strip_tags($row['course_degree']);
                 echo '</div> School Graduate:<div class = "infotab">'.strip_tags($row['school_grad']);

                 echo '</div> Eligibility:<div class = "infotab">'.strip_tags($row['eligibility']);
                 echo '</div> Special Skills:<div class = "infotab">'.strip_tags($row['special_skills']);
                 echo '</div> Latitude:<input type = "text" id = "latitude" class = "inputtab" value = "'.$row['latitude'].'">';
                 echo 'Longitude:<input type = "text" id = "longitude" class = "inputtab" value = "'.strip_tags($row['longitude']).'">';
                 echo ' Spouse Address:<input type = "text" id = "spouse_address" class = "inputtab" value = "'.strip_tags($row['spouse_address']).'">';
                 echo ' Number Dependents:<input type = "text" id = "no_dependents" class = "inputtab" value = "'.$row['no_dependents'].'">';
                 echo '</div><div class = "col-md-4 font_eye_fast"> Landline:<input type = "text" id = "landline" class = "inputtab" value = "'.strip_tags($row['landline']).'">';
                 echo 'Cedula Number:<div class = "infotab">'.strip_tags($row['cedula_no']);

                 echo '</div> Date Issued:<div class = "infotab">'.strip_tags($row['dateissued']);
                 echo '</div> Place Issued:<div class = "infotab">'.strip_tags($row['placeissued']);
                 echo '</div> Father\'s Lastname:<input type = "text" id = "flastname" class = "inputtab" value = "'.strip_tags($row['flastname']).'">';
                 echo ' Father\'s Firstname:<input type = "text" id = "ffirstname" class = "inputtab" value = "'.strip_tags($row['ffirstname']).'">';
                 echo ' Father\'s Middlename:<input type = "text" id = "fmiddle" class = "inputtab" value = "'.strip_tags($row['fmiddle']).'">';
                 echo ' Mother\'s Lastname:<input type = "text" id = "mlastname" class = "inputtab" value = " '.strip_tags($row['mlastname']).'">';
                 echo ' Mother\'s Firstname:<input type = "text" id = "mfirstname" class = "inputtab" value = "'.strip_tags($row['mfirstname']).'">';
                 echo ' Mother\'s Middlename:<input type = "text" id = "mmiddle" class = "inputtab" value = "'.strip_tags($row['mmiddle']).'">';
                 echo ' Spouse Lastname:<input type = "text" id = "spouse" class = "inputtab" value = "'.strip_tags($row['spouse']).'">';
                 echo ' Spouse Firstname:<input type = "text" id = "spousefirstname" class = "inputtab" value = "'.strip_tags($row['spousefirstname']).'">';

                 echo ' Spouse Middlename:<input type = "text" id = "spousemiddle" class = "inputtab" value = "'.strip_tags($row['spousemiddle']).'">';
                 echo ' PWD:<div class = "infotab">'.strip_tags($row['pwd']);
                 echo '</div> Nature Statistics:<div class = "infotab"> '.strip_tags($row['nature_stat']);
                 echo '</div> Religion:<input type = "text" id = "religion" class = "inputtab" value = "'.strip_tags($row['religion']).'">';
                 echo ' Item Number:<div class = "infotab">'.strip_tags($row['item_no']);
                 echo '</div> Job Grade:<div class = "infotab">'.strip_tags($row['job_grade']);
                //  $thecourse = $row['Course_ID'];
                
                // $querysubject = "select * from course where Course_ID = '$thecourse'";
                // foreach ($psbh->query($querysubject) as $rowex) {
                // echo '</div> Course:<div class = "infotab">'.$rowex['Course_Name'];
                // }
                 // echo '</div> Entrance Exam Score:<div class = "infotab">'.$row['remarks'];
                 echo '</div> Employee ID:<div class = "infotab">'.$row['employeeid'];
                 // echo '</div> Enrollment Status:<div class = "infotab">'.$row['status'];
                 echo '</div></div>';
        
        echo '<div class = "button_positive" onclick = "submitedit()">Confirm</div>';
}
       
?>

       