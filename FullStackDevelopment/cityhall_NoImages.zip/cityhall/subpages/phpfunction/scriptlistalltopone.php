<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("../../php/connectPDO.php");

if(!isset($_GET['newstitlesearch'])){

    $statement = $dbhsub -> query("SELECT TOP 1 * FROM mainnews ORDER BY dateuploaded DESC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
      echo $row['newsid'];
  }

}else{

	$newstitlesearch = $_GET['newstitlesearch'];
$startmonth =  $_GET['startmonthtoolkit'];
$startday =  $_GET['startdaytoolkit'];
$startyear =  $_GET['startyeartoolkit'];
$endmonth =  $_GET['endmonthtoolkit'];
$endday =  $_GET['enddaytoolkit'];
$endyear =  $_GET['endyeartoolkit'];
$content = 0;
      $statement = $dbhsub -> query("SELECT newsid, CONVERT(VARCHAR(10),dateuploaded, 101) AS dateuploaded FROM mainnews WHERE title LIKE '%$newstitlesearch%' AND dateuploaded between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' ORDER BY dateuploaded DESC");
  while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
      echo $row['newsid'];
      $content++;
  }

  if($content != 1){
  	echo 'empty';
  }
}
?>