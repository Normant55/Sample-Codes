<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$depvalue = $_GET['depvalue'];
echo '<h2>'.$depvalue.'</h2>';
echo '<h4 onclick = "redisplayjobdep()">Back</h4>';

$depvalue = str_replace('`', '\'\'', $depvalue);

$query = $dbhhris -> query("SELECT Count(Distinct[PositionN]) FROM ITEMS WHERE DeptDesc = '$depvalue'");
$amount = $query -> fetchColumn();
echo '<div class="tab">';
$counter = $amount/12;
$starting = 1;
while($starting<=$counter+1){
echo ' <button class="tablinks" onclick="openCity(event, \'ainz'.$starting.'\')">'.$starting.'</button>';
$starting++;
}
echo '</div>';

if($amount == 0){
	echo '<h1>None Available</h1>';
}

$counterlimit = 1;
$bash = 1;
$query = $dbhhris -> query("SELECT Distinct[PositionN], [Itemnos] FROM ITEMS  WHERE DeptDesc = '$depvalue'");
while($row = $query -> fetch(PDO::FETCH_ASSOC)){

	if($counterlimit==13){
		$counterlimit = 1;
			echo '</div>';
	}

	if($counterlimit == 1){
		echo '<div id="ainz'.$bash.'" class="tabcontent">';
		$bash++;
	}

echo '<li><a href = "subpages/jobapplicant" onmouseover="jobprofiling(\''.$row['Itemnos'].'\')" onmouseout="jobprofilingout()">'.$row['PositionN'].'</a></li>';



	$counterlimit ++;



}
echo '</div>';






?>
<!-- Tab content -->