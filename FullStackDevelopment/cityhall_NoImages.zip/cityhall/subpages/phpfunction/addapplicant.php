<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
sleep(1);
    $firstname = strip_tags($_GET['firstname']);       
    $middlename = strip_tags($_GET['middlename']);             
    $lastname = strip_tags($_GET['lastname']);
    $firstname = strtoupper($firstname);
    $middlename = strtoupper($middlename);
    $lastname = strtoupper($lastname);
    $emailaddress = $_GET['emailaddress'];
    $emailaddress = strip_tags($emailaddress);              
    $address = $_GET['address'];
    $birthdate = $_GET['birthdate'];
    $birthplacei = $_GET['birthplacei'];            
    $fullname = $lastname.', '.$firstname.' '.$middlename;
    $username = $_GET['username'];
    $username = strip_tags($username); 
    $password = $_GET['password'];
    $password = strip_tags($password); 
    $phonenumber = $_GET['phonenumber'];              
    $mobilenumber = $_GET['mobilenumber'];            
    $course = $_GET['course'];
    $religion = $_GET['religion'];            
    $gender = $_GET['gender'];            
    $citizenship = $_GET['citizenship'];            
    $maritalstatus = $_GET['maritalstatus'];          
    $ssgsis = $_GET['ssgsis'];         
    $philhealth = $_GET['philhealth'];          
    $pagibig = $_GET['pagibig'];              
    $dep = $_GET['departments'];

$sarray = array();
$targe = array();
$fordeptab = array();
$course = strip_tags($course);

$schoolgraduated = $_GET['schoolgraduated'];     
$schoolgraduated = strip_tags($schoolgraduated);
$eligibility = $_GET['eligibility'];  
$eligibility = strip_tags($eligibility);
$experience = $_GET['experience'];
$experience = strip_tags($experience);
$training = $_GET['training'];
$training = strip_tags($training);
$special_skills = $_GET['special_skills'];
$special_skills = strip_tags($special_skills);

$dep = str_replace("<li><a>", "", $dep);
$dep = str_replace("</a></li>", ", ", $dep);
$sarray = explode(", ", $dep);
$arraycounter = count($sarray);
for($min = 0; $min<$arraycounter; $min++){
$what_you_want = substr($sarray[$min], 0, strpos($sarray[$min], ':'));
 array_push($fordeptab, $what_you_want);
$jobdescription = str_replace($what_you_want.':', '', $sarray[$min]);
 array_push($targe, $jobdescription);
}
  //   $queryforabbriv = "select deptAbbriv from OfficeHeaders WHERE Department = '".implode('\' OR Department = \'',$sarray)."'";
  // $stmtdepabbriv = $dbhbudget -> query($queryforabbriv);
  // while($row = $stmtdepabbriv -> fetch( PDO::FETCH_ASSOC )){
  //     array_push($targe, $row['deptAbbriv']);
  //   }
  $deptarmentschoosen = implode(", ", $targe);
  $debabbriv = implode(", ", $fordeptab);
//.date("F jS \of Y");

$errorlog = 0;
$statement = $dbh -> prepare("SELECT count(*) FROM Applicants WHERE firstname = :firstname AND middle = :middlename AND lastname = :lastname");
$statement->bindParam(":firstname", $firstname);
$statement->bindParam(":middlename", $middlename);
$statement->bindParam(":lastname", $lastname);
$statement -> execute();
if($statement ->fetchColumn()>0){
  echo 'fn';
  $errorlog++;
}

$statement = $dbh -> prepare("SELECT count(*) FROM applicantlogin WHERE username = :username");
$statement->bindParam(":username", $username);
$statement -> execute();
if($statement ->fetchColumn()>0){
  if($errorlog == 1){
  echo 'au';
  }else{
  echo 'u';
  }
  $errorlog++;
}else{
$statement = $dbh -> prepare("SELECT count(*) FROM userlogn WHERE username = :username");
$statement->bindParam(":username", $username);
$statement -> execute();
if($statement ->fetchColumn()>0){
  if($errorlog == 1){
  echo 'au';
  }else{
  echo 'u';
  }
  $errorlog++;
} 
}

if($errorlog==0){

function getAge($then) {
    $then_ts = strtotime($then);
    $then_year = date('Y', $then_ts);
    $age = date('Y') - $then_year;
    if(strtotime('+' . $age . ' years', $then_ts) > time()) $age--;
    return $age;
}
$myage = getAge($birthdate);






$stmt = $dbh -> prepare("INSERT INTO Applicants(fullname, firstname,middle,lastname,email_address,home_address,birthdate, age, birthplace,home_phone,
  mobile_no, course_degree, school_grad, religion, gender, citizenship, job_title, dept_abbriv, marital_status, sssgsis_number,
  philhealth_no, pagibig_no, eligibility, sssgsis_contrib, philhealth_contrib, pagibig_contrib, experience, training, date_registered, special_skills) VALUES(:fullname, :firstname, :middlename, :lastname, :emailaddress, :address, :birthdate, :myage, :birthplace, :phonenumber, :mobilenumber, :course, :schoolgraduated, :religion, :gender, :citizenship, :deptarmentschoosen, :fordeptab, :maritalstatus, :ssgsis, :philhealth, :pagibig, :eligibility, 0, 0, 0, :experience, :training,  GETDATE(), :special_skills);");
$stmt->bindParam(':fullname', $fullname);
$stmt->bindParam(':firstname', $firstname);
$stmt->bindParam(':middlename', $middlename);
$stmt->bindParam(':lastname', $lastname);
$stmt->bindParam(':emailaddress', $emailaddress);
$stmt->bindParam(':address', $address);
$stmt->bindParam(':birthplace', $birthplacei);
$stmt->bindParam(':birthdate', $birthdate);
$stmt->bindParam(':phonenumber', $phonenumber);
$stmt->bindParam(':mobilenumber', $mobilenumber);
$stmt->bindParam(':course', $course);
$stmt->bindParam(':schoolgraduated', $schoolgraduated);
$stmt->bindParam(':religion', $religion);
$stmt->bindParam(':gender', $gender, PDO::PARAM_INT);
$stmt->bindParam(':citizenship', $citizenship);
$stmt->bindParam(':deptarmentschoosen', $deptarmentschoosen);
$stmt->bindParam(':fordeptab', $debabbriv);
$stmt->bindParam(':maritalstatus', $maritalstatus, PDO::PARAM_INT);
$stmt->bindParam(':ssgsis', $ssgsis);
$stmt->bindParam(':myage', $myage);
$stmt->bindParam(':philhealth', $philhealth);
$stmt->bindParam(':pagibig', $pagibig);
$stmt->bindParam(':eligibility', $eligibility);
$stmt->bindParam(':experience', $experience);
$stmt->bindParam(':training', $training);
$stmt->bindParam(':special_skills', $special_skills);
$stmt->execute();

if($stmt){

}
else{
  echo 'Failed Query to Uploaded Application';
}

$query = "SELECT TOP 1 * FROM Applicants ORDER BY employeeid DESC"; 
$getid = $dbh -> query($query);
while($row = $getid -> fetch( PDO::FETCH_ASSOC )){
  $nowid = $row['employeeid'];
}
// $now = ''.date("m/d/y");

// echo $username.$password.$nowid.$now;
$insertuser = $dbh -> query("INSERT INTO applicantlogin(username, intra_pword, employeeid, datetimelog)VALUES('$username', '$password', '$nowid', GETDATE())");
if($insertuser){
   echo $nowid;
}
}
?>