<select id = "officeorigin" class = "form-control" required>

<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
	$query = "select distinct acronym from OFFICE_ORIGIN ORDER BY acronym ASC";
	$stmt = $dbhbudget -> query($query);
	while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
		$acronym = $row['acronym'];
		echo '<option value = "'.$acronym.'">'.$acronym.'</option>';

	}
?>
	</select>