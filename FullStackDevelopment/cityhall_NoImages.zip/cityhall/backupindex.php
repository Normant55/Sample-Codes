<?php
session_start();
include('php/connectPDO.php');
if(isset($_SESSION['user'])&&!empty($_SESSION['user'])){
  unset($_SESSION['user']);
  }
?>
    <!DOCTYPE HTML>
    <html lang = "en">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <head>
    <link rel = "icon" type = "image/png" href = "images/samplelogo.png"/>
    <title>City Hall</title>
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="bootstrap/dis/js/bootstrap.min.js"></script>
    <link rel = "stylesheet" type = "text/css" href = "css/index.css?<?php echo time(); ?>">
    <link href = "bootstrap/dis/css/bootstrap.min.css" rel = "stylesheet">

    </head>

    <body>
    <!--TestCode-->
    <?php
    /*$query = 'select * from dbo.user_account';  
    // simple query  
    $stmt = $dbh->query( $query );  
    while ( $row = $stmt->fetch( PDO::FETCH_ASSOC ) ){  
       print_r( "<div class = 'test'>".$row['user_name'] ."</div>" );  
       print_r( "<div class = 'test'>".$row['gender'] ."</div>" );  
    }  
    //echo "........ query for a column ............";  
    // query for one column  
    /*$stmt = $dbh->query( $query, PDO::FETCH_COLUMN, 4 );  
    while ( $row = $stmt->fetch() ){  
       echo "<div class = 'blank'>$row</div>";  
    }*/
    ?>
    <!--TestCodeAbove-->

    <div class = "container">

       	<div class = "jumbotron" id = "titleimage">
        <h1>LGU-Iligan</h1>
          <p></p>      
    <div class="topnav">
       	<div class = "container">

         	<div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-2">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="registrationindex.php">Register</a>
        	</div>


    		<div class="collapse navbar-collapse" id="navbar-collapse-2">
        		<ul class="nav navbar-nav navbar-right" style="margin-right: 38px;">
                                    <li><a href="index.php" id ="currentbutton">Home</a></li>
                                    <li><a href="#">About</a></li>
                                    <li><a href="#">Contents</a></li>
                                    <li><a href="#">Sites</a></li>
                                    <li><a href="#">News</a></li>
                                    <li><a href="#">Contact</a></li>
                               		  <li>
                               			<div class = "signin">
                                        <a class="btn btn-default" data-toggle="collapse" href="#nav-collapse2" aria-expanded="false" aria-controls="nav-collapse2">Sign in</a>
    									              </div>
                                    </li>
        		</ul>
        				
          						<div class="collapse nav navbar-nav nav-collapse" id="nav-collapse2">
                                    <form class="navbar-form navbar-right form-inline" role="form" action = "php/login/login.php" method = "POST">
                                        <div class="form-group">
                                            <label class="sr-only" for="Email">Username</label>
                                            <input type="text" class="form-control" id="Email" name = "loginemail" placeholder="Username" autofocus required />
                                        </div>
                                        <div class="form-group">
                                            <label class="sr-only" for="Password">Password</label>
                                            <input type="password" class="form-control" id="Password" name = "loginpassword" placeholder="Password" required />
                                        </div>
                                        <button type="submit" class="btn btn-success" name = "signin">Sign in</button>
                                    </form>
                                </div>
                          
    		</div>
       	</div>
    </div>
    	</div>
      
    </div>

    <div class = "container-fluid">

    <div class = "row">
    <div class = "myfooter">

    </div>

    </div>

    </div>



    </body>
    </html>