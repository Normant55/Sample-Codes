// $(document).ready(function(){
// $( ".clicktoenlarge" ).on("click",
//   function() {
//     $(".datacontainment").css("width", "90%")
//     $(".datacontainment").css("right", "5%")
//     $(".datacontainment").css("position", "fixed")
//     $(".mytable").css("margin", "0 auto")
//     $(".dummyclick").css("display", "block")
//     $(this).css("display", "none")   
//   });
// $( ".dummyclick" ).on("click",
//   function() {
//     $(".datacontainment").css("width", "100%")
//     $(".datacontainment").css("right", "0%")
//     $(".datacontainment").css("position", "absolute")
//     $(".mytable").css("margin", "0 0")
//     $(this).css("display", "none")
//     $(".clicktoenlarge").css("display", "block")
//   });
// $( ".itemdatainput" ).click(
//   function() {
//     $("this").prop('disabled' , false)
//   });
// });
$(document).ready(function () {
$('#searchtool').click(function () {
    $('.navhide').hide();
    $('#lowerhalfall').hide();
    $('#jobboards').hide();
    $('#applicantformletter').hide();
    $('#newsfeed').hide();
    $('#lining').hide();
    $('#liningunder').hide();
    $('#portalhider').hide();
    $('#portalhider_object').hide();
    $('.for_hide').hide();
    $('#fadeinsearch').fadeIn('slow');
});
// $("#show_Qualifications").hover(function(){
//   $('.entry_cursor').css("background-color", "rgba(200, 200, 200, 1)");
//   }, function(){
//   $('.entry_cursor').css("background-color", "rgba(255, 255, 255, 1)");
// });
$('#closesearch').click(function () {
    $('#fadeinsearch').hide();
    $('#newsfeed').fadeIn('slow');
    $('#lowerhalfall').fadeIn('slow');
    $('.navhide').fadeIn('slow');
    $('#lining').fadeIn('slow');
    $('#liningunder').fadeIn('slow');
    $('#portalhider').fadeIn('slow');
    $('#portalhider_object').fadeIn('slow');
    $('.for_hide').fadeIn();
    $('#applicantformletter').fadeIn('slow');
    $('#jobboards').fadeIn('slow');   
});
$('#forsignin').click(function(){
    $('#registrypad').fadeIn('slow');
});
$('#closeregistry').click(function(){
    $('#registrypad').hide();
});
$('#registrypadexit').click(function(){
    $('#registrypad').hide();   
});
$('#registerbutton').click(function(){
    $('.navhide').hide();
    $('#lowerhalfall').hide();
    $('#jobboards').hide();
    $('#applicantformletter').hide();
    $('#newsfeed').hide();
    $('#lining').hide();
    $('#liningunder').hide();
    $('#portalhider').hide();
    $('#portalhider_object').hide();
    $('.for_hide').hide();   
    $('#registrationchoice').fadeIn('slow');
});
$('#closeregchoice').click(function(){
    $('#registrationchoice').hide();
    $('#newsfeed').fadeIn('slow');
    $('#lowerhalfall').fadeIn('slow');
    $('.navhide').fadeIn('slow');
    $('#lining').fadeIn('slow');
    $('#liningunder').fadeIn('slow');
    $('#portalhider').fadeIn('slow');
    $('#portalhider_object').fadeIn('slow');
    $('.for_hide').fadeIn();
    $('#applicantformletter').fadeIn('slow');
    $('#jobboards').fadeIn('slow'); 
});
});
$(document).ready(function () {
$('#chrmologo').click(function () {
// window.location.href = "subpages/jobapplicant";
});
});
$(document).ready(function () {
$('#enginesmenu').click(function () {
    $('.navhide').hide();
    $('#lowerhalfall').hide();
    $('#jobboards').hide();
    $('#applicantformletter').hide();
    $('#newsfeed').hide();
    $('#lining').hide();
    $('#liningunder').hide();
    $('#portalhider').hide();
    $('#portalhider_object').hide();
    $('.for_hide').hide();
    $('#fadeinenginelist').fadeIn('slow');
});
$('#enginesmenudub').click(function () {
    $('.navhide').hide();
    $('#lowerhalfall').hide();
    $('#jobboards').hide();
    $('#applicantformletter').hide();
    $('#newsfeed').hide();
    $('#lining').hide();
    $('#liningunder').hide();
    $('#portalhider').hide();
    $('#portalhider_object').hide();
    $('.for_hide').hide();
    $('#fadeinenginelist').fadeIn('slow');
});
$('#closeengine').click(function () {
    $('#fadeinenginelist').hide();
    $('#newsfeed').fadeIn('slow');
    $('#lining').fadeIn('slow');
    $('#liningunder').fadeIn('slow');
    $('#applicantformletter').fadeIn('slow');
    $('#lowerhalfall').fadeIn('slow');
    $('.navhide').fadeIn('slow');
    $('#portalhider').fadeIn('slow');
    $('#portalhider_object').fadeIn('slow');
    $('.for_hide').fadeIn();
    $('#jobboards').fadeIn('slow');      
});
});
$(document).ready(function () {
$('#infonewers').click(function () {
    dumplink = window.localStorage.getItem("warper");
    if(dumplink != "default"){
          window.location.href = "subpages/"+dumplink;
    }else{
    $('.navhide').hide();
    $('#lowerhalfall').hide();
    $('#jobboards').hide();
    $('#applicantformletter').hide();
    $('#newsfeed').hide();
    $('#lining').hide();
    $('#liningunder').hide();
    $('#portalhider').hide();
    $('#portalhider_object').hide();
    $('.for_hide').hide();
    $('#fullviewblog').fadeIn('slow');}
});
});
$(document).ready(function () {
// $('#newhireclicker').click(function () {
//     $('#openjobs').hide();
//     $('#jobs').hide();
//     $('#newhire').fadeIn('slow');
// });
$('#jobsclicker').click(function () {
    // $('#newhire').hide();
    $('#openjobs').hide();
    $('.jobemblem').fadeOut(1000);
    setTimeout(function(){$('#jobs').slideDown(1000);}, 1000);
     openCity(event, 'rain1');
});
$('#openjobsclicker').click(function () {
    // $('#newhire').hide();
    $('#jobs').hide();
    $('#openjobs').fadeIn('slow');  
});
});
$(document).ready(function () {
$('#appviewer').hover(
  function(){$('#infojobbutton').css('display', 'block')}, 
  function(){$('#infojobbutton').css('display', 'none')}
);
});
// $(document).ready(function () {
// $('#exituploadfiles').click(function () {
//     // $('#openjobs').hide();
//     $('#uploaderfiles').fadeOut('slow');
// });

// $('#uploadresume').click(function () {
//     // $('#newhire').hide();
//     $('#uploaderfiles').fadeIn('slow');   
// });
// });
$(document).ready(function () {
// $('#newhireclicker').click(function () {
//     $('#openjobs').hide();
//     $('#jobs').hide();
//     $('#newhire').fadeIn('slow');
// });
$('.return-forbutton').click(function () {
    // $('#newhire').hide();
    $('#secondbite').hide();
    $('#thirdbite').hide();
    $('#firstbite').fadeIn('slow');    
});
$('#regularbutton').click(function () {
    // $('#newhire').hide();
    $('#firstbite').hide();
    $('#thirdbite').hide();
    $('#secondbite').fadeIn('slow');    
});
$('#newappbutton').click(function () {
    // $('#newhire').hide();
    $('#firstbite').hide();
    $('#secondbite').hide();
    $('#thirdbite').fadeIn('slow');    
});
$('#show_Qualifications').click(function () {
    $('#Qualifications').fadeIn('slow');    
});
$('#hide_Qualifications').click(function () {
    $('#Qualifications').fadeOut('slow');    
});
});
$(document).ready(function(){
    // $("#applicantlistminimizer").click(function(){
    //     $("#toggleapplicantlist").slideToggle("slow");
    // });
    //  $("#bottomminimizer").click(function(){
    // $("#toggleapplicantlist").slideToggle("slow");
    //         $([document.documentElement, document.body]).animate({
    //     scrollTop: $("#applicantlistminimizer").offset().top
    // }, 1000);
    // });

     $(".scrolltonews").click(function(){
            $([document.documentElement, document.body]).animate({
        scrollTop: $("#newsfeed").offset().top
    }, 1000);
    });
     $(".scrolltohome").click(function(){
            $([document.documentElement, document.body]).animate({
        scrollTop: $("#phoenix").offset().top
    }, 1000);
    });
     $(".scrolltojobs").click(function(){
      $('.featuredbox').fadeIn(1000);
      $('.featuredimage').slideDown(2000);
      $('.nonfeaturedbox').fadeIn(2000);
      $('.nonfeaturedimage').slideDown(3000);
      $([document.documentElement, document.body]).animate({
        scrollTop: $(".join_emblem").offset().top
    }, 1000);
    });
var didScroll;
var lastScrollTop = 0;
var delta = 5;
var navbarHeight = $('.masterpage').outerHeight();
$(window).scroll(function(event){
    didScroll = true;
});
setInterval(function() {
    if (didScroll) {
        hasScrolled();
        didScroll = false;
    }
}, 250);
function hasScrolled() {
    var st = $(this).scrollTop();
    // Make sure they scroll more than delta
    if(Math.abs(lastScrollTop - st) <= delta)
        return;   
    // If they scrolled down and are past the navbar, add class .nav-up.
    // This is necessary so you never see what is "behind" the navbar.
    if (st > lastScrollTop && st > navbarHeight){
        // Scroll Down
        $('.masterpage').removeClass('nav-down').addClass('nav-up');
    } else {
        // Scroll Up
        if(st + $(window).height() < $(document).height()) {
            $('.masterpage').removeClass('nav-up').addClass('nav-down');
        }
    }
    lastScrollTop = st;
}
});
// if($('#defaultsigninview:visible').length == 0)
// {
// $(document).mouseup(function(e) 
// {
//     var container = $("#defaultsigninview");
//     // if the target of the click isn't the container nor a descendant of the container
//     if (!container.is(e.target) && container.has(e.target).length === 0) 
//     {
//         container.hide();
//     }
// });
// }
function openCity(evt, cityName) {
    // Declare all variables
    var i, tabcontent, tablinks;
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
 // $(document).ready(function(){
 // var imgArr = new Array( // relative paths of images
 // 'images/slider1.jpeg',
 // 'images/slider2.jpg',
 // 'images/cityhall.jpg'
 // );
 // var preloadArr = new Array();
 // var i;
 // /* preload images */
 // for(i=0; i < imgArr.length; i++){
 // preloadArr[i] = new Image();
 // preloadArr[i].src = imgArr[i];
 // }
 // var currImg = 1;
 // var intID = setInterval(changeImg, 2000);
 // /* image rotator */
 // function changeImg(){
 // $('#titleimage').animate({opacity: 0}, 1000, function(){
 // $(this).css('background','url(' + preloadArr[currImg++%preloadArr.length].src +') top center');
 // }).animate({opacity: 1}, 1000);
 // }
 // });
 $.fn.isInViewport = function() {
  var elementTop = $(this).offset().top;
  var elementBottom = elementTop + $(this).outerHeight();

  var viewportTop = $(window).scrollTop();
  var viewportBottom = viewportTop + $(window).height();

  return elementBottom > viewportTop && elementTop < viewportBottom;
};

$(window).on('resize scroll', function() {
  $('.navhide').each(function() {
      var activeColor = $(this).attr('id');
    if ($(this).isInViewport()) {
      $('#mashk').fadeIn(3000);
    } else {
      $('#mashk').hide();
    }
  });
});

$(window).on('resize scroll', function() {
  $('.watchnews').each(function() {
      var activeColor = $(this).attr('id');
    if ($(this).isInViewport()) {
      $('.featuredbox').fadeIn(1000);
      $('.featuredimage').slideDown(2000);
    } else {
      // $('.featuredbox').hide();
    }
  });
});
$(window).on('resize scroll', function() {
  $('.watchnewsnonlatest').each(function() {
      var activeColor = $(this).attr('id');
    if ($(this).isInViewport()) {
      $('.nonfeaturedbox').fadeIn(2000);
      $('.nonfeaturedimage').slideDown(3000);
    } else {
      // $('.featuredbox').hide();
    }
  });
});

$(window).on('resize scroll', function() {
  $('.auxiliary_1').each(function() {
      var activeColor = $(this).attr('id');
    if ($(this).isInViewport()) {
      $('.padded').fadeIn(3000);
      $('.photoimg').slideDown(2000);
    } else {
      // $('.featuredbox').hide();
    }
  });
});

// $(window).on('resize scroll', function() {
//   $('.auxiliary_2').each(function() {
//       var activeColor = $(this).attr('id');
//     if ($(this).isInViewport()) {
//       $('.applicantbox').slideUp(2000);
//     } else {
//       // $('.featuredbox').hide();
//     }
//   });
// });