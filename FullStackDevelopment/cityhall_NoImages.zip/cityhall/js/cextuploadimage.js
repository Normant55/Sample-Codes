$(document).ready(function (e) {
$("#cextuploadimage").on('submit',(function(e) {
e.preventDefault();
$("#messagecext").empty();
$('#loading').show();
nicInstancesb = nicEditors.findEditor('makarovs');
notessb = nicInstancesb.getContent();
notessb = '<div class = "hexor">'+notessb+'</div>';
descriptionsb = notessb;
descriptionsb = descriptionsb.replace(/</gi, "e1p1"); 
descriptionsb = descriptionsb.replace(/>/gi, "e1p2");
descriptionsb = descriptionsb.replace(/\"/gi, "e1p3"); 
descriptionsb = descriptionsb.replace(/#/gi, "e1p4"); 
descriptionsb = descriptionsb.replace(/\(/gi, "e1p5"); 
descriptionsb = descriptionsb.replace(/\)/gi, "e1p6");
descriptionsb = descriptionsb.replace(/-/gi, "e1p7"); 
descriptionsb = descriptionsb.replace(/:/gi, "e1p8"); 
descriptionsb = descriptionsb.replace(/\&/gi, "e1p9");
descriptionsb = descriptionsb.replace(/\&/gi, "e1p9");
titleb = document.getElementById("imagesubtle").value;
titleconid = document.getElementById("selectortitlecover").value;
alignmentsub = document.getElementById("alignmentsub").value;
theidb = window.localStorage.getItem("loginid");
$.ajax({
url: '../php/coverextender.php?theid='+theidb+'&title='+titleb+'&description='+descriptionsb+'&titleconid='+titleconid+'&alignmentsub='+alignmentsub, // Url to which the request is send
type: "POST",             // Type of request to be send, called as method
data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
contentType: false,       // The content type used when sending data to the server.
cache: false,             // To unable request pages to be cached
processData:false,        // To send DOMDocument or non processed data file it is set to false
success: function(data)   // A function to be called if request succeeds
{
$('#loading').hide();
$("#messagecext").html(data);
// 	if(usertype == 'employee'){
//    window.location.href = "player.html";
// }else{
//    window.location.href = "applicantprofile.html";	
// }               
          daser = document.getElementById("selectortitlecover").value;
          var xmlhttp = new XMLHttpRequest();
          xmlhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
             document.getElementById("subtitlefinder").innerHTML = this.responseText;
          }
        };
          xmlhttp.open("GET", "phpfunction/searchsubtlecover.php?idea="+daser, true);
          xmlhttp.send();


}
});
}));
// Function to preview image after validation
$(function() {
$("#cextcover").change(function() {
$("#messagecext").empty(); // To remove the previous error message
var file = this.files[0];
var imagefile = file.type;
var match= ["image/jpeg","image/png","image/jpg"];
if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
{
$('#previewingcext').attr('src','noimage.png');
$("#messagecext").html("<p id='error'>Please Select A valid Image File</p>"+"<h4>Note</h4>"+"<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
return false;
}
else
{
var reader = new FileReader();
reader.onload = imageIsLoaded;
reader.readAsDataURL(this.files[0]);
}
});
});
function imageIsLoaded(e) {
$("#cextcover").css("color","green");
$('#image_cext').css("display", "block");
$('#previewingcext').attr('src', e.target.result);
$('#previewingcext').attr('width', '250px');
$('#previewingcext').attr('height', '230px');
};



});