function startUpload(){
  setTimeout(function(){ 
    window.location.href = "applicantprofile";
  }, 1000);
}
function stopUpload(success,uploadedFile){
    alert(success + uploadedFile);
    var result = '';
    if (success == 1){
        result = '<span class="sucess-msg">The file was uploaded successfully!<\/span><br/><br/>';
        //Uploaded file preview
        var embed = document.getElementById("UploadedFile");
        var clone = embed.cloneNode(true);
        clone.setAttribute('src',uploadedFile);
        embed.parentNode.replaceChild(clone,embed);
        













    }else {
       result = '<span class="error-msg">There was an error during resume upload!<\/span><br/><br/>';
    }
 
}