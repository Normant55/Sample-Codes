$(document).ready(function (e) {
$("#coverimagingb").on('submit',(function(e) {
e.preventDefault();
$("#messagereplacerb").empty();
$('#loading').show();
selectortitlecover = document.getElementById("selectortitlecover").value;
if(selectortitlecover == 'none'){
	alert("Please select a News Title!");
	window.location.href = "frontnewstool.html";
}
attribute = document.getElementById("imagespanmaker").value;
$.ajax({
url: "../php/gloryoflove.php?attribute="+attribute+"&newsid="+selectortitlecover, // Url to which the request is send
type: "POST",             // Type of request to be send, called as method
data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
contentType: false,       // The content type used when sending data to the server.
cache: false,             // To unable request pages to be cached
processData:false,        // To send DOMDocument or non processed data file it is set to false
success: function(data)   // A function to be called if request succeeds
{
$('#loading').hide();
$("#messagereplacerb").html(data);

        selectortitlecover = document.getElementById("selectortitlecover").value;
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        document.getElementById("fullviewnews").innerHTML = this.responseText;
            }
        };
          // theid = window.localStorage.getItem("loginid");
        xmlhttp.open("GET", "phpfunction/viewingthiscover.php?idea="+selectortitlecover, true);
        xmlhttp.send();       

}
});
}));
// Function to preview image after validation
$(function() {
$("#filereplacerb").change(function() {
$("#messagereplacerb").empty(); // To remove the previous error message
var file = this.files[0];
var imagefile = file.type;
var match= ["image/jpeg","image/png","image/jpg"];
if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
{
$('#previewingreplacerb').attr('src','noimage.png');
$("#messagereplacerb").html("<p id='error'>Please Select A valid Image File</p>"+"<h4>Note</h4>"+"<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
return false;
}
else
{
var reader = new FileReader();
reader.onload = imageIsLoaded;
reader.readAsDataURL(this.files[0]);
}
});
});
function imageIsLoaded(e) {
$("#filereplacerb").css("color","green");
$('#image_previewreplacerb').css("display", "block");
$('#previewingreplacerb').attr('src', e.target.result);
$('#previewingreplacerb').attr('width', '250px');
$('#previewingreplacerb').attr('height', '230px');
};



});