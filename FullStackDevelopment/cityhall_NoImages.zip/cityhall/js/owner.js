// $(document).ready(function(){
// $( ".clicktoenlarge" ).on("click",
//   function() {
//     $(".datacontainment").css("width", "90%")
//     $(".datacontainment").css("right", "5%")
//     $(".datacontainment").css("position", "fixed")
//     $(".mytable").css("margin", "0 auto")
//     $(".dummyclick").css("display", "block")
//     $(this).css("display", "none")   
//   });
// $( ".dummyclick" ).on("click",
//   function() {
//     $(".datacontainment").css("width", "100%")
//     $(".datacontainment").css("right", "0%")
//     $(".datacontainment").css("position", "absolute")
//     $(".mytable").css("margin", "0 0")
//     $(this).css("display", "none")
//     $(".clicktoenlarge").css("display", "block")
//   });
// $( ".itemdatainput" ).click(
//   function() {
//     $("this").prop('disabled' , false)
//   });
// });
$(document).ready(function(){
    $("#lament").click(function(){
        $("#controlpanel").slideToggle("slow");
    });
    $("#exitcontrolpanel").click(function(){
        $("#controlpanel").slideToggle("slow");
    });
    $("#applicantlist").click(function(){
                 if($("#examination").length){
                 document.getElementById("examination").style.display = "none";
                 }
                 if($("#leftnavigator").length){
                 document.getElementById("leftnavigator").style.display = "none";
                 }
                 if($("#leave_application").length){
                 document.getElementById("leave_application").style.display = "none";
                 }
                 if($("#file_application").length){
                 document.getElementById("file_application").style.display = "none";
                 }
                 if($("#inbox").length){
                 document.getElementById("inbox").style.display = "none";
                 }
        window.localStorage.setItem("adminviewmode", "overview");
        document.getElementById("leftnavigator").style.display = "none";
         document.getElementById("leave_application").style.display = "none";
            gender_select = 2;
            status_select = 4;
            input_min_age = 0;
            input_max_age = 999;
            var d = new Date();
            var n = d.getMonth();
            var year = d.getFullYear();
            var numberdays = daysInMonth(n, year);
            startmonthtoolkit = n+1;
            startdaytoolkit = 1;
            startyeartoolkit = year;
            endmonthtoolkit = n+1;
            enddaytoolkit = numberdays;
            endyeartoolkit = year;
            var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("applicantlistboard").innerHTML = this.responseText;
            }
        };
          xmlhttp.open("GET", "subpages/phpfunction/applicantlist.php?startmonthtoolkit="
            +startmonthtoolkit+"&startdaytoolkit="+startdaytoolkit+"&enddaytoolkit="+enddaytoolkit+
            "&endyeartoolkit="+endyeartoolkit+"&startyeartoolkit="+startyeartoolkit+"&endmonthtoolkit="
            +endmonthtoolkit+"&gender_select="+gender_select+"&status_select="+status_select+"&input_min_age="+input_min_age+"&input_max_age="+input_max_age, true);
          xmlhttp.send();
        
        $("#applicantlistboardouter").slideToggle("slow");
    });
    $("#examination").click(function(){
                 document.getElementById("leave_application").style.display = "none";
                 document.getElementById("leftnavigator").style.display = "none";
                 searchkeyword = window.localStorage.getItem("searchkeyword");
                 searchdate =window.localStorage.getItem("searchdate");
                 searchfnt = window.localStorage.getItem("searchfnt");
                 eft = window.localStorage.getItem("eft");
                 searchtnt = window.localStorage.getItem("searchtnt");
                 ett = window.localStorage.getItem("ett");
                 inputname = window.localStorage.getItem("inputname");
                 inputcontact = window.localStorage.getItem("inputcontact");
                 inputlevel =window.localStorage.getItem("inputlevel");
                 inputscore = window.localStorage.getItem("inputscore");
                 inputresult = window.localStorage.getItem("inputresult");
                 inputremarks = window.localStorage.getItem("inputremarks");
                 inputdate = window.localStorage.getItem("inputdate");
                 inputtime = window.localStorage.getItem("inputtime");  
        window.localStorage.setItem("adminviewmode", "examoverview");
            var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("examinationboard").innerHTML = this.responseText;
            }
        };
           xmlhttp.open("GET", "subpages/phpfunction/exammodule/examlist.php?searchkeyword="+searchkeyword+"&searchdate="+searchdate+"&searchfnt="+searchfnt+"&eft="+eft+"&searchtnt="+searchtnt+"&ett="+ett+"&inputname="+inputname+"&inputtime="+inputtime+"&inputdate="+inputdate+"&inputremarks="+inputremarks+"&inputresult="+inputresult+"&inputscore="+inputscore+"&inputlevel="+inputlevel+"&inputcontact="+inputcontact, true);
          xmlhttp.send();
        $("#examinationboard").slideToggle("slow");
    });
    $("#leaveapplicant").click(function(){
                 if($("#examination").length){
                 document.getElementById("examination").style.display = "none";
                 }
                 if($("#leftnavigator").length){
                 document.getElementById("leftnavigator").style.display = "none";
                 }
                 if($("#inbox").length){
                 document.getElementById("inbox").style.display = "none";
                 }
                 if($("#file_application").length){
                 document.getElementById("file_application").style.display = "none";
                 }
                 theid = window.localStorage.getItem("loginid"); 
                 window.localStorage.setItem("adminviewmode", "leaveoverview");
            var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("leave_application").innerHTML = this.responseText;
                function return_typeleave(data){
                  button_html = '<a class = "word_button_sky" style = "cursor:pointer; text-decoration: none;" onclick = "multi_tick()"><img class = "img-responsive" src="images/subtarget_logo.png" alt="image test" style = "position: relative;background-repeat: no-repeat; background-size: 100% 100%;background-position: 20% 50%;background-color: rgba(200,200,200, 0);height: 30px;display: inline-block;"/>Add Item</a>';
                  $('.type_leave_forms').html(button_html);
                  write_html = '';
                  // write_html = 'Header ID: <div class = "id_leave" style = "display: inline-flex;"></div>';
                  // function return_header_ids(data){
                  //   write_select_html = select_maker(data, 'my_leave_id');
                  //   $('.id_leave').html(write_select_html);
                  // }
                  // search_query('LEAV_STAT_ID=:LEAV_STAT_ID', '[LGU_DEV].[hr].[LEAV_REQ_HEADER]', 'LEAV_REQNO*-, LEAV_REQNO', '5', '', 'select_allby', '', 'dbh_leave', return_header_ids);
                          write_html = write_html+'<div class = "col-md-4">Leave Type: ';
                          write_html = write_html+select_maker(data, 'my_select')+'</div>';
                  write_html = write_html+'<div class = "col-md-2">Time: ';
                  write_html = write_html + '<select class = "input_standard" id = \'time_pick\'><option value = \'0\'>Whole Day</option><option value = \'1\'>Half AM</option><option value = \'2\'>Half PM</option></select>';
                  write_html = write_html+'</div><div class = "col-md-3">Date From: ';
                  write_html = write_html + '<input class = "input_standard" type = \'date\' id = \'date_from\'>';
                  write_html = write_html+'</div><div class = "col-md-3">Date To: ';
                  write_html = write_html + '<input class = "input_standard" type = \'date\' id = \'date_to\'></div>';
                  $('.type_leave').html(write_html);
                }
                search_query('', '[LGU_DEV].[hr].[LEAV_TYPES]', 'LEAV_TYPE_ID*-, LEAV_TYPE_TEXT', '', '', 'select_allby', '', 'dbh_leave', return_typeleave);
            }
        };
           xmlhttp.open("GET", "subpages/phpfunction/leave_appmodule/leave_list.php?startmonthtoolkit="+startmonthtoolkit+"&startdaytoolkit="+startdaytoolkit+"&enddaytoolkit="+enddaytoolkit+"&endyeartoolkit="+endyeartoolkit+"&startyeartoolkit="+startyeartoolkit+"&endmonthtoolkit="+endmonthtoolkit+"&theid="+theid, true);
          xmlhttp.send();
        $("#leave_application").slideToggle("slow");
    });
    $("#inbox_view").click(function(){
                 if($("#examination").length){
                 document.getElementById("examination").style.display = "none";
                 }
                 if($("#leftnavigator").length){
                 document.getElementById("leftnavigator").style.display = "none";
                 }
                 if($("#leave_application").length){
                 document.getElementById("leave_application").style.display = "none";
                 }
                 if($("#file_application").length){
                 document.getElementById("file_application").style.display = "none";
                 }
                 document.getElementById("txtHint").innerHTML = "";
                 searchkeyword = window.localStorage.getItem("searchkeyword");
                 item_ranking_first =window.localStorage.getItem("item_ranking_first");
                 item_ranking_last = window.localStorage.getItem("item_ranking_last"); 
                 userprof = window.localStorage.getItem("loginuser"); 
                 window.localStorage.setItem("adminviewmode", "inboxview");
            var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("inbox").innerHTML = this.responseText;
            }
        };
           xmlhttp.open("GET", "subpages/phpfunction/inbox_appmodule/inbox_list.php?searchkeyword="+searchkeyword+"&item_ranking_first="+item_ranking_first+"&item_ranking_last="+item_ranking_last+"&userprof="+userprof, true);
          xmlhttp.send();
        $("#inbox").slideToggle("slow");
    });
    $("#button_filemgt").click(function(){
                 if($("#examination").length){
                 document.getElementById("examination").style.display = "none";
                 }
                 if($("#leftnavigator").length){
                 document.getElementById("leftnavigator").style.display = "none";
                 }
                 if($("#leave_application").length){
                 document.getElementById("leave_application").style.display = "none";
                 }
                 if($("#inbox").length){
                 document.getElementById("inbox").style.display = "none";
                 }
                 searchkeyword = window.localStorage.getItem("searchkeyword");
                 item_ranking_first =window.localStorage.getItem("item_ranking_first");
                 item_ranking_last = window.localStorage.getItem("item_ranking_last"); 
                 userprof = window.localStorage.getItem("loginuser"); 
                 window.localStorage.setItem("adminviewmode", "view_filemgt");
           $.post("subpages/phpfunction/files_appmodule/list.php", 
           //Required URL of the page on server
           { // Data Sending With Request To Server
            startmonthtoolkit:startmonthtoolkit,
            startdaytoolkit:startdaytoolkit,
            enddaytoolkit:enddaytoolkit,
            endyeartoolkit:endyeartoolkit,
            startyeartoolkit:startyeartoolkit,
            endmonthtoolkit:endmonthtoolkit,
            searchkeyword:searchkeyword,
            item_ranking_first:item_ranking_first,
            item_ranking_last:item_ranking_last,
            theid:theid
           },
           function(response,status){ // Required Callback Function
                //alert("*----Received Data----*nnResponse : " + response+"nnStatus : " + status);
                //"response" receives - whatever written in echo of above PHP script.
                // $("#form")[0].reset();
                document.getElementById("file_application").innerHTML = response;
                function return_typefile(data){
                    write_html = 'Choose Category: ';
                    write_html = write_html+select_maker(data, 'my_file_category');
                    // button_html = '<div class = "dashuploader" id ="coverreplacer" style = "float: left;"><div class="main" id = "coverup"><hr><form id="coverimagingb" action="" method="post" enctype="multipart/form-data"><div id="image_previewreplacerb"><img id="previewingreplacerb" src="noimage.png" /></div><hr id="line"><div id="selectImage"><label>Select Your Image</label><br/><input type="file" name="file" id="filereplacerb" required /><input type="submit" value="Add Photo" id ="replacerbutton" class="submit" /></div></form></div><div id="messagereplacerb"></div></div>'+write_html+'';
                    // $('.type_file_forms').html(button_html);
                }
                search_query('is_fixed = 0', '[biosub].[dbo].[file_category]', 'file_category_id*-, description', '', '', 'select_allby', '', 'dbhsub', return_typefile);
           });
           $("#file_application").slideToggle("slow");
    });
    $("#exitapplicantlist").click(function(){
        $("#applicantlistboardouter").slideToggle("slow");
    });
    $("#fronteditor").click(function(){
         window.location.href = "subpages/frontcontrol";
    });
    $("#newstools").click(function(){
         window.location.href = "subpages/frontnewstool";
    });
});