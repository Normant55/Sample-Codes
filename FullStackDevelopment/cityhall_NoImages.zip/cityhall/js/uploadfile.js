function startUpload(){
           firstname = document.getElementById("firstnamei").value;
           middlename = document.getElementById("middlenamei").value;
           lastname = document.getElementById("lastnamei").value;
           emailaddress = document.getElementById("emailaddressi").value;
           address = document.getElementById("addressi").value;
           birthdate = document.getElementById("birthdatei").value;
           birthplacei = document.getElementById("birthplacei").value;
           phonenumber = document.getElementById("phonenumberi").value;
           mobilenumber = document.getElementById("mobilenumberi").value;
           course = document.getElementById("educational_attainment").innerHTML;
           course = course.trim();
           // course2 = document.getElementById("coursei2").value;
           schoolgraduated = document.getElementById("school_graduated").innerHTML;
           schoolgraduated = schoolgraduated.trim();
           religion = document.getElementById("religioni").value;
           gender = document.getElementById("genderi").value;
           username = document.getElementById("usernamei").value;
           password = document.getElementById("passwordi").value;
           trainingi = document.getElementById("training").innerHTML;
           trainingi = trainingi.trim();
           citizenship = document.getElementById("citizenshipi").value;
           maritalstatus = document.getElementById("maritalstatusi").value;
           ssgsis = document.getElementById("ssgsisi").value;
           philhealth = document.getElementById("philhealthi").value;
           pagibig = document.getElementById("pagibigi").value;
           eligibility = document.getElementById("eligibility").innerHTML;
           eligibility = eligibility.trim();
           experience = document.getElementById("experience").innerHTML;
           experience = experience.trim();
           special_skills = document.getElementById("special_skills").innerHTML;
           special_skills = special_skills.trim();
           // yearsexp = document.getElementById("yearonei").value;
            if(document.getElementById("usernamei").value !== null && document.getElementById("usernamei").value !== '' 
            && document.getElementById("passwordi").value !== null && document.getElementById("passwordi").value !== ''
            && document.getElementById("addressi").value !== null && document.getElementById("addressi").value !== '' 
            && document.getElementById("emailaddressi").value !== null && document.getElementById("emailaddressi").value !== ''
            && document.getElementById("birthplacei").value !== null && document.getElementById("birthplacei").value !== '' 
            && document.getElementById("lastnamei").value !== null && document.getElementById("lastnamei").value !== '' 
            && document.getElementById("middlenamei").value !== null && document.getElementById("middlenamei").value !== ''
            && document.getElementById("firstnamei").value !== null && document.getElementById("firstnamei").value !== '' 
            && document.getElementById("phonenumberi").value !== null && document.getElementById("phonenumberi").value !== ''
            && document.getElementById("mobilenumberi").value !== null && document.getElementById("mobilenumberi").value !== ''){
            departments = '';
             var xmlhttpmain = new XMLHttpRequest();
            xmlhttpmain.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                Yehey = this.responseText;
                  
                  if(this.responseText == 'fnau'){
                document.getElementById("usernotifier").innerHTML = 'Username already taken!';
                document.getElementById("namenotifier").innerHTML = document.getElementById("lastnamei").value + ', ' + document.getElementById("firstnamei").value + ' ' + document.getElementById("middlenamei").value + ' has already sent an application';
           alert("The fullname and username is already taken!");  
           }
           else if(this.responseText == 'u'){
                document.getElementById("usernotifier").innerHTML = 'Username already taken!';
                document.getElementById("namenotifier").innerHTML = '';
                alert("The username is already taken!");  
           }
           else if(this.responseText == 'fn'){
                document.getElementById("namenotifier").innerHTML = document.getElementById("lastnamei").value + ', ' + document.getElementById("firstnamei").value + ' ' + document.getElementById("middlenamei").value + ' has already sent an application';
                document.getElementById("usernotifier").innerHTML = '';
                alert("The fullname already submitted an application!");  
           }else{
            // $('#applicationform').hide();
            if(confirm("Successfully Registered Applicant, proceed to login?")){
             window.localStorage.setItem("usertype", 'applicant');
             window.localStorage.setItem("loginuser", username);
             window.localStorage.setItem("thepasswordentry", password);
             window.localStorage.setItem("loginid", Yehey);
             window.location.href = "../applicantprofile";
            }else{
            window.location.href = "../index";
            }
           }
                


            }
        };
         theid = window.localStorage.getItem("userid");
         // xmlhttpmain.open("GET", "../php/testing.php?valuefortest="+departments, true);
        xmlhttpmain.open("GET", "phpfunction/addapplicant.php?special_skills="+special_skills+"&birthplacei="+birthplacei+"&username="+username+"&password="+password+"&firstname="+firstname+"&middlename="+middlename+"&lastname="+lastname+"&emailaddress="+emailaddress+"&address="+address+"&birthdate="+birthdate+"&phonenumber="+phonenumber+"&mobilenumber="+mobilenumber+"&course="+course+"&schoolgraduated="+schoolgraduated+"&religion="+religion+"&gender="+gender+"&citizenship="+citizenship+"&maritalstatus="+maritalstatus+"&ssgsis="+ssgsis+"&philhealth="+philhealth+"&pagibig="+pagibig+"&eligibility="+eligibility+"&departments="+departments+"&experience="+experience+"&training="+trainingi, true);
        xmlhttpmain.send();
}else{

}

}
function stopUpload(success,uploadedFile){
    alert(success + uploadedFile);
    var result = '';
    if (success == 1){
        result = '<span class="sucess-msg">The file was uploaded successfully!<\/span><br/><br/>';
        //Uploaded file preview
        var embed = document.getElementById("UploadedFile");
        var clone = embed.cloneNode(true);
        clone.setAttribute('src',uploadedFile);
        embed.parentNode.replaceChild(clone,embed);
        













    }else {
       result = '<span class="error-msg">There was an error during resume upload!<\/span><br/><br/>';
    }
 
}