
function crud_function(condition, condition_targets, table, operation_columns, operation_targets, crud, message, database)
  {
    $.post("http://79.125.201.223:8080/cityhall/subpages/phpfunction/update_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        condition:condition,
        condition_targets:condition_targets,
        table:table,
        operation_columns:operation_columns,
        operation_targets:operation_targets,
        crud:crud,
        message:message,
        database:database
      },
    function(response,status)
      {
        alert(response);
        codeAddress();
        // $("#form")[0].reset();
      });
  }

function crud_function_preset(condition, condition_targets,preset_columns,preset_targets, table, operation_columns, operation_targets, crud, message, database)
  {
    $.post("http://79.125.201.223:8080/cityhall/subpages/phpfunction/update_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        condition:condition,
        condition_targets:condition_targets,
        table:table,
        operation_columns:operation_columns,
        operation_targets:operation_targets,
        preset_columns:preset_columns,
        preset_targets:preset_targets,
        crud:crud,
        message:message,
        database:database
      },
    function(response,status)
      {
        alert(response);
        codeAddress();
        // $("#form")[0].reset();
      });
  }

function crud_function_preset_noload_noalert(condition, condition_targets,preset_columns,preset_targets, table, operation_columns, operation_targets, crud, message, database)
  {
    $.post("http://79.125.201.223:8080/cityhall/subpages/phpfunction/update_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        condition:condition,
        condition_targets:condition_targets,
        table:table,
        operation_columns:operation_columns,
        operation_targets:operation_targets,
        preset_columns:preset_columns,
        preset_targets:preset_targets,
        crud:crud,
        message:message,
        database:database
      },
    function(response,status)
      {
        // $("#form")[0].reset();
      });
  }

function crud_function_noload(condition, condition_targets, table, operation_columns, operation_targets, crud, message, database)
  {
    $.post("http://79.125.201.223:8080/cityhall/subpages/phpfunction/update_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        condition:condition,
        condition_targets:condition_targets,
        table:table,
        operation_columns:operation_columns,
        operation_targets:operation_targets,
        crud:crud,
        message:message,
        database:database
      },
    function(response,status)
      { 
        alert(response);
        // $("#form")[0].reset();
      });
  }

function crud_function_noload_noalert(condition, condition_targets, table, operation_columns, operation_targets, crud, message, database)
  {
    $.post("http://79.125.201.223:8080/cityhall/subpages/phpfunction/update_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        condition:condition,
        condition_targets:condition_targets,
        table:table,
        operation_columns:operation_columns,
        operation_targets:operation_targets,
        crud:crud,
        message:message,
        database:database
      },
    function(response,status)
      { 
        // $("#form")[0].reset();
      });
}

function search_query(condition, table, operation_columns, condition_targets, suffix, type, message, database, callback)
{
    $.post("http://79.125.201.223:8080/cityhall/subpages/phpfunction/select_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        condition:condition,
        table:table,
        operation_columns:operation_columns,
        condition_targets:condition_targets,
        suffix:suffix,
        type:type,
        message:message,
        database:database
      },
    function(response,status)
      { 
        // var search_query_returns = response;
        // $("#form")[0].reset();
        callback(response);
      });
}
function select_maker(data, select_id){
                  var my_select = '<select class = "input_standard" id = "'+select_id+'">';
                  data = data.substring(0, data.length - 2);
                  var writer = data;
                  my_segregation = 0;
                    my_leavetype = writer.split(', ');
                    my_leavetype.forEach(function(element) {
                      if(my_segregation == 0){
                        my_select = my_select+'<option value = \''+element;
                        my_segregation = 1;
                      }else{
                        my_select = my_select+'\'>'+element+'</option>';
                        my_segregation = 0;
                      }
                    });
                    my_select = my_select+'</select>';
                    my_select = ''+my_select+'';
                return my_select;
}

function select_maker_function(data, select_id, sub_function, locator){
                  var my_select = '<select onchange = "'+sub_function+'" class = "input_standard" id = "'+select_id+'">';
                  data = data.substring(0, data.length - 2);
                  var writer = data;
                  my_segregation = 0;
                    my_leavetype = writer.split(', ');
                    my_leavetype.forEach(function(element) {
                      if(my_segregation == 0){
                        if(locator == element){
                        my_select = my_select+'<option selected value = \''+element;                         
                        }else{
                        my_select = my_select+'<option value = \''+element;
                        }
                        my_segregation = 1;
                      }else{
                        my_select = my_select+'\'>'+element+'</option>';
                        my_segregation = 0;
                      }
                    });
                    my_select = my_select+'</select>';
                    my_select = ''+my_select+'';
                return my_select;
}
