<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
$theword = ['theword'];
$theword = str_replace("<", "e1p1",  $theword);
$theword = str_replace(">", "e1p2",  $theword);
$theword = str_replace("\"", "e1p3", $theword);
$theword = str_replace("#", "e1p4",  $theword);
$theword = str_replace("(", "e1p5",  $theword);
$theword = str_replace(")", "e1p6",  $theword);
$theword = str_replace("-", "e1p7",  $theword);
$theword = str_replace(":", "e1p8",  $theword);
$theword = str_replace("&", "e1p9",  $theword);
$theword = str_replace("rgba(0,0,0,0)", "rgb(255, 255, 255)",  $description);
$theword = str_replace("a", "!!",  $theword);
?>