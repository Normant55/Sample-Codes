<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
$serverName = "NATNAT-PC"; //serverName\instanceName
$connectionInfo = array( "Database"=>"Untitled", "UID"=>"msdss", "PWD"=>"madix_t");
$conn = sqlsrv_connect( $serverName, $connectionInfo);
if($conn) {
     echo "Connection established.<br />";
}else{
     echo "Connection could not be established.<br />";
     die( print_r( sqlsrv_errors(), true));
}
$pagename = basename($_SERVER['PHP_SELF']);
if($pagename != 'componentspage.php'){
if(isset($_SESSION['itemidfcom'])&&!empty($_SESSION['itemidfcom'])){
  unset($_SESSION['itemidfcom']);
  }
}
?>
