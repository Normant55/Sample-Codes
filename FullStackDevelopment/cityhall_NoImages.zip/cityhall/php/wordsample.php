<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
$content = $_GET['values'];
// $firstname = $_GET['firstname'];
// $lastname = $_GET['lastname'];
// $middlename = $_GET['middlename'];
$try = $_GET['try'];
if($try == ''){
	$try = 'default';
}

// $fullname = $lastname.'-'.$firstname.'-'.$middlename;
header("Content-type: application/vnd.ms-word");
header("Content-Disposition: attachment; filename=".$try.".doc");

echo "<html>";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=Windows-1252\">";
echo "<body>";


echo $content;
echo "</body>";
echo "</html>";

?>