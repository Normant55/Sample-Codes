<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("connectPDO.php");
require('../fpdf181/fpdf.php');
if(isset($_GET['registereduser'])&&!empty($_GET['registereduser'])){
$registereduser = $_GET['registereduser'];
$statement = $dbh -> prepare("SELECT employeeid FROM applicantlogin WHERE username = :registereduser");
$statement->bindParam(":registereduser", $registereduser);
$statement -> execute();
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
	$employeeid = $row['employeeid'];
}
}
if(isset($_GET['inhere'])&&!empty($_GET['inhere'])){
	$employeeid = $_GET['inhere'];
}
// sleep(2);
$statement = $dbh -> prepare("SELECT fullname, firstname,middle,lastname,email_address,home_address,
	CONVERT(VARCHAR(10),birthdate, 101) AS birthdate ,home_phone,
  mobile_no, course_degree, school_grad, gender, citizenship, job_title, dept_abbriv, marital_status, eligibility, experience, yearsexp, training, date_registered, special_skills FROM Applicants WHERE employeeid = :employeeid");
$statement->bindParam(":employeeid", $employeeid, PDO::PARAM_INT);
$statement -> execute();
$pdf = new FPDF('P','mm','Legal');
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
$pdf->AddPage();
$pdf->Ln(6);
$pdf->Image('../images/mainlogo.jpg',5, 12.5,-250);
$pdf->SetFont('times','B',16);
$pdf->Cell(15, 6, '', 0);
$pdf->Cell(40,10,'Application Details');
$pdf->Ln(3);
$pdf->SetFont('times', '', 6);
$pdf->Cell(25, 6, '', 0);
$pdf->Cell(40,12, ' '.date("F jS \of Y"));
$pdf->Ln(10);
$pdf->setFont('times', '', 12);
$pdf->Cell(0, 25, 'Applicant ID: '.$employeeid);
$pdf->Ln(10);
$pdf->Cell(0, 25, 'Date Registered: '.$row['date_registered']);
$pdf->Ln(10);
$pdf->SetFont('times','B',12);
$pdf->Cell(40,25,'Applicant Profile');
$pdf->Ln(10);
$pdf->setFont('times', '', 12);
$pdf->Cell(50, 25, 'Firstname: ');
$pdf->Cell(0, 25, ''.$row['firstname']);
$pdf->Ln(5);
$pdf->Cell(50, 25, 'Middlename: ');
$pdf->Cell(0, 25, ''.$row['middle']);
$pdf->Ln(5);
$pdf->Cell(50, 25, 'Lastname: ');
$pdf->Cell(0, 25, ''.$row['lastname']);
$pdf->Ln(5);
$pdf->Cell(50, 25, 'Home Address: ');
$pdf->Cell(0, 25, ''.$row['home_address']);
$pdf->Ln(5);
$pdf->Cell(50, 25, 'Birthday: ');
$pdf->Cell(0, 25, ''.$row['birthdate']);
$pdf->Ln(5);
switch($row['marital_status']){
	case 1:
	$maritalstatus = 'Single';
	case 2:
	$maritalstatus = 'Married';
	case 3:
	$maritalstatus = 'Widowed';
	case 4:
	$maritalstatus = 'Separated';
}
$pdf->Cell(50, 25, 'Marital Status: ');
$pdf->Cell(0, 25, ''.$maritalstatus);
$pdf->Ln(5);
$pdf->Cell(50, 25, 'Citizenship: ');
$pdf->Cell(0, 25, ''.$row['citizenship']);
$pdf->Ln(5);
switch($row['gender']){
	case 0:
	$gender = 'Female';
	case 1:
	$gender = 'Male';
}
$pdf->Cell(50, 25, 'Gender: ');
$pdf->Cell(0, 25, ''.$gender);
$pdf->Ln(10);
$pdf->SetFont('times','B',12);
$pdf->Cell(40,25,'Applicant Qualifications');
// $pdf->Cell(0, 25, ''.$row['course_degree']);
$pdf->Ln(10);
$pdf->setFont('times', '', 12);
$data = str_replace(']', '', $row['course_degree']);
$data_array = array();
$data_array = explode('[', $data);
$x = 0;
foreach ($data_array as $key) {
if($x==0){
$pdf->Cell(50, 25, 'Course/Degree: ');
}elseif($x==1){
$key = substr($key, 0, strpos($key, ':', strpos($key, ':')+1));
$pdf->Cell(0, 25, ''.$key);
}else{
$pdf->Ln(5);
$pdf->Cell(50, 25, '');
$key = substr($key, 0, strpos($key, ':', strpos($key, ':')+1));
$pdf->Cell(0, 25, ''.$key);
}
$x++;
}
$pdf->Ln(5);
$data = str_replace(']', '', $row['school_grad']);
$data_array = array();
$data_array = explode('[', $data);
$x = 0;
foreach ($data_array as $key) {
if($x==0){
$pdf->Cell(50, 25, 'School Graduated: ');
}elseif($x==1){
$pdf->Cell(0, 25, ''.$key);
}else{
$pdf->Ln(5);
$pdf->Cell(50, 25, '');
$pdf->Cell(0, 25, ''.$key);
}
$x++;
}
$pdf->Ln(5);
$data = str_replace(']', '', $row['eligibility']);
$data_array = array();
$data_array = explode('[', $data);
$x = 0;
foreach ($data_array as $key) {
if($x==0){
$pdf->Cell(50, 25, 'Eligibilities: ');
}elseif($x==1){
$pdf->Cell(0, 25, ''.$key);
}else{
$pdf->Ln(5);
$pdf->Cell(50, 25, '');
$pdf->Cell(0, 25, ''.$key);
}
$x++;
}
$pdf->Ln(5);
$data = str_replace(']', '', $row['special_skills']);
$data_array = array();
$data_array = explode('[', $data);
$x = 0;
foreach ($data_array as $key) {
if($x==0){
$pdf->Cell(50, 25, 'Special Skills: ');
}elseif($x==1){
$pdf->Cell(0, 25, ''.$key);
}else{
$pdf->Ln(5);
$pdf->Cell(50, 25, '');
$pdf->Cell(0, 25, ''.$key);
}
$x++;
}
$pdf->Ln(5);
$data = str_replace(']', '', $row['experience']);
$data_array = array();
$data_array = explode('[', $data);
$x = 0;
foreach ($data_array as $key) {
$key = str_replace(':Started-', 'ez122.', $key);
$key = str_replace(':Ended-', ' to ', $key);
if($x==0){
$pdf->Cell(50, 25, 'Experience: ');
}elseif($x==1){
// $pdf->Cell(0, 25, ''.$key);
$data_arrayi1 = array();
$data_arrayi1 = explode('ez122.', $key);
$x_i1 = 0;
foreach ($data_arrayi1 as $key_i1) {
	if($x_i1!=0){
		$pdf->Ln(5);
		$pdf->Cell(50, 25, '');
	}
	$pdf->Cell(0, 25, ''.$key_i1);
	$x_i1++;
}
}else{
$pdf->Ln(7);
$pdf->Cell(50, 25, '');
// $pdf->Cell(0, 25, ''.$key);
$data_arrayi1 = array();
$data_arrayi1 = explode('ez122.', $key);
$x_i1 = 0;
foreach ($data_arrayi1 as $key_i1) {
	if($x_i1!=0){
		$pdf->Ln(5);
		$pdf->Cell(50, 25, '');
	}
	$pdf->Cell(0, 25, ''.$key_i1);
	$x_i1++;
}
}
$x++;
}
$pdf->Ln(7);
$data = str_replace(']', '', $row['training']);
$data_array = array();
$data_array = explode('[', $data);
$x = 0;
foreach ($data_array as $key) {
if($x==0){
$pdf->Cell(50, 25, 'Training: ');
}elseif($x==1){
$pdf->Cell(0, 25, ''.$key);
}else{
$pdf->Ln(5);
$pdf->Cell(50, 25, '');
$pdf->Cell(0, 25, ''.$key);
}
$x++;
}
// $pdf->Ln(5);
// $pdf->Cell(50, 25, 'Year(s) of experience: ');
// $pdf->Cell(0, 25, ''.$row['yearsexp']);
$pdf->Ln(10);
$pdf->SetFont('times','B',12);
$pdf->Cell(40,25,'Contact Information');
$pdf->Ln(10);
$pdf->setFont('times', '', 12);
$pdf->Cell(50, 25, 'Email Address: ');
$pdf->Cell(0, 25, ''.$row['email_address']);
$pdf->Ln(5);
$pdf->Cell(50, 25, 'Phone Number: ');
$pdf->Cell(0, 25, ''.$row['home_phone']);
$pdf->Ln(5);
$pdf->Cell(50, 25, 'Mobile Number: ');
$pdf->Cell(0, 25, ''.$row['mobile_no']);
$pdf->Ln(20);
$lenght = strlen($row['job_title']);
$jobtitle = substr($row['job_title'], 0, $lenght -2);
$lenght = strlen($row['dept_abbriv']);
$deptabbriv = substr($row['dept_abbriv'], 0, $lenght -2);
$depcodearray = array();
$depcodearray = explode(', ', $deptabbriv);
$jobarray = array();
$jobarray = explode(', ', $jobtitle);
$pdf->SetFont('times','B',12);
$pdf->Cell(100, 25, 'Position(s) Applied: ');
$pdf->Cell(100, 25, 'Department-JobCode: ');
$pdf->setFont('times', '', 12);
$x = 0;
$counter = 1;
$jobdisplay = 'begin';
while($counter<2){
	if(isset($jobarray[$x]) AND $jobarray[$x] != '' AND $jobarray[$x] != $jobdisplay){
	$jobdisplay = $jobarray[$x];
	$depcodedisplay = $depcodearray[$x];
	$x++;
	$pdf->Ln(5);
$pdf->Cell(100, 25, ''.$jobdisplay);
$pdf->Cell(100, 25, ''.$depcodedisplay);
	}else{
		$counter = 2;
	}
}
}

$pdf->Ln(75);
$pdf->SetFont('times','',12);
$pdf->Cell(50, 25, 'Norman Ted U. Tabasa');
$pdf->Cell(75, 25, '');
$pdf->Cell(50, 25, 'Romer B. Hormiguera');
$pdf->Ln(5);
$pdf->SetFont('times','B',12);
$pdf->Cell(100, 25, 'Acting Defence Officer IV');
$pdf->Cell(25, 25, '');
$pdf->Cell(100, 25, 'Department Head');
$pdf->Ln(5);
$pdf->SetFont('times','',12);
$pdf->Cell(50, 25, 'Command Center Office', 'T');
$pdf->Cell(75, 25, '');
$pdf->Cell(50, 25, 'City Human Resource Office', 'T');
$pdf->Ln(50);
$pdf->SetFont('times','',12);
$pdf->Cell(100, 25, '');
$pdf->Cell(25, 25, '');
$pdf->Cell(50, 25, 'Novie B. Lubguban');
$pdf->Ln(5);
$pdf->SetFont('times','B',12);
$pdf->Cell(100, 25, '');
$pdf->Cell(25, 25, '');
$pdf->Cell(100, 25, 'Attorney V');
$pdf->Ln(5);
$pdf->SetFont('times','',12);
$pdf->Cell(100, 25, '');
$pdf->Cell(25, 25, '');
$pdf->Cell(50, 25, 'City Court Office', 'T');
	$pdf->Output();
?>