<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../connectPDO.php');
$loginuser = $_POST['email'];
$loginpassword = $_POST['password'];

$query = "select count(*) from userlogn where username = :loginuser AND intra_pword = :loginpassword";
$stmt = $dbh -> prepare($query);
$stmt->bindParam(':loginuser', $loginuser);
$stmt->bindParam(':loginpassword', $loginpassword);
$stmt -> execute();
//$ok = $stmt -> fetchColumn();
echo '<style>.hiddendiv{visibility:hidden;}</style>';
if($stmt -> fetchColumn() > 0){
	
	$query = "select * from userlogn where username = '$loginuser'";
	$stmt = $dbh -> query($query);
	while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
		if($row['authority']=='devadmin'){
		 echo '<div class = "hiddendiv" id = "directiondeter">admin';
		}else{
		 echo '<div class = "hiddendiv" id = "directiondeter">employee';	
		}
	echo '</div><div class = "hiddendiv" id = "entereduser">'. $row['username'];
  	echo '</div><div class = "hiddendiv" id = "theloginid">'. $row['employeeid'];
 	echo '</div>';
 	echo '<div class = "hiddendiv" id = "thepasswordentry">'. $row['intra_pword'];
 	echo '</div>';
 // echo $row['employeeid'];
 // echo $row['username'];
}
 echo '<div class = "hiddendiv" id = "confirmation">confirmed</div>';

}else{
$query = "select count(*) from applicantlogin where username = :loginuser AND intra_pword = :loginpassword";
$stmt = $dbh -> prepare($query);
$stmt->bindParam(':loginuser', $loginuser);
$stmt->bindParam(':loginpassword', $loginpassword);
$stmt -> execute();
//$ok = $stmt -> fetchColumn();
echo '<style>.hiddendiv{visibility:hidden;}</style>';
if($stmt -> fetchColumn() > 0){
	
	$query = "select * from applicantlogin where username = '$loginuser'";
	$stmt = $dbh -> query($query);
	while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
	echo '<div class = "hiddendiv" id = "directiondeter">applicant';
	echo '</div><div class = "hiddendiv" id = "entereduser">'. $row['username'];
  	echo '</div><div class = "hiddendiv" id = "theloginid">'. $row['employeeid'];
 	echo '</div>';
 	echo '<div class = "hiddendiv" id = "thepasswordentry">'. $row['intra_pword'];
 	echo '</div>';
 // echo $row['employeeid'];
 // echo $row['username'];
}
 echo '<div class = "hiddendiv" id = "confirmation">confirmed</div>';

}else{
echo '<div class = "hiddendiv" id = "directiondeter">NaN</div>';
 echo '<div class = "hiddendiv" id = "entereduser">';
 echo '</div><div class = "hiddendiv" id = "theloginid">';
 echo '</div>';	
 echo '<div class = "hiddendiv" id = "thepasswordentry">';
 echo '</div>';
 echo '<div class = "failbar" id = "confirmation">Failed to login, no such user!</div>';
 echo '<style>.failbar{color:red;
	}</style>';	
}
}


	

        //echo 'window.localStorage.setItem("loginuser", "'.$_SESSION['user'].'");';
               //echo 'window.localStorage.setItem("userid", "'.$_SESSION['studID'].'");';
                     // echo 'window.localStorage.setItem("clearance", "'.$_SESSION['clearance'].'");';

 
?>