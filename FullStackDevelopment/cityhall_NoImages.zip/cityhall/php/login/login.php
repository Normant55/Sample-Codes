<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
$loginemail = $_POST['loginemail'];
$loginpassword = $_POST['loginpassword'];

$query = "select count(*) from userlogn where username = :loginemail AND password = :loginpassword";
$stmt = $dbh -> prepare($query);
$stmt->bindParam(':loginemail', $loginemail);
$stmt->bindParam(':loginpassword', $loginpassword);
$stmt -> execute();
//$ok = $stmt -> fetchColumn();
if($stmt -> fetchColumn() > 0){
	$query = "select * from userlogn where username = '$loginemail'";
	$stmt = $dbh -> query($query);
	while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
	$employeeid = $row['employeeid'];
	// echo ' '.$clearancelevel;
	// session_start();
	// $_SESSION['user'] = $row['user_name'];
	// $_SESSION['clearance'] = $clearancelevel;
	}
		session_start();
	$_SESSION['user'] = $loginemail;
	$_SESSION['clearance'] = 1;
	$_SESSION['employeeid'] = $employeeid;
	$clearancelevel = 1;
	switch($clearancelevel)
	{
		case 1:
		echo '<script language="JavaScript" type="text/javascript">';
        echo 'if(confirm("Login Successful")){';
        echo 'window.location.href = "../../player.html"}else{window.location.href = "../../index.php"}';
		echo '</script>';
		break;
	
		case 2:
		echo '<script language="JavaScript" type="text/javascript">';
        echo 'if(confirm("Login Successful")){';
        echo 'window.location.href = "../../admin.php"}else{window.location.href = "../../index.php"}';
		echo '</script>';
		break;

		case 3:
		echo '<script language="JavaScript" type="text/javascript">';
        echo 'if(confirm("Login Successful")){';
        echo 'window.location.href = "../../owner.php"}else{window.location.href = "../../index.php"}';
		echo '</script>';
		break;
	}
}
else{
		echo '<script language="JavaScript" type="text/javascript">';
        echo 'alert("Login Failed!");';
        echo 'window.location.href = "../../index.php"';
		echo '</script>';
}
 //print_r( "<div class = 'test'>".$ok."</div>" );  


?>