<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
$usertype = $_GET['usertype'];
$theid = $_GET['theid'];
if(isset($_FILES["file"]["type"]))
{
$validextensions = array("jpeg", "jpg", "png");
$temporary = explode(".", $_FILES["file"]["name"]);
$file_extension = end($temporary);
if ((($_FILES["file"]["type"] == "image/png") ||($_FILES["file"]["type"] == "image/jpeg")||($_FILES["file"]["type"] == "image/jpg")) && ($_FILES["file"]["size"] < 400000000)//Approx. 100kb files can be uploaded.
&& in_array($file_extension, $validextensions)) {
if ($_FILES["file"]["error"] > 0)
{
echo "Return Code: " . $_FILES["file"]["error"] . "<br/><br/>";
}
else
{
if (file_exists("../images/cityhall.jpg")){
$deleterpath = "../images/cityhall.jpg";
echo $_FILES["file"]["name"] . "Picture replaced";
unlink($deleterpath);
$sourcePath = $_FILES['file']['tmp_name']; // Storing source path of the file in a variable
$targetPath = "../images/cityhall.jpg"; // Target path where file is to be stored
move_uploaded_file($sourcePath,$targetPath) ; // Moving Uploaded file
// echo "<br/><b>File Name:</b> " . $_FILES["file"]["name"] . "<br>";
echo "<br><b>Type:</b> " . $_FILES["file"]["type"] . "<br>";
echo "<b>Size:</b> " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
}
else
{
$sourcePath = $_FILES['file']['tmp_name']; // Storing source path of the file in a variable
$targetPath = "../images/cityhall.jpg"; // Target path where file is to be stored
// $temp = explode(".", $_FILES["file"]["name"]);
// $newfilename = round(microtime(true)) . '.' . end($temp);
// move_uploaded_file($_FILES["file"]["tmp_name"], "../img/imageDirectory/" . $newfilename);
move_uploaded_file($sourcePath,$targetPath) ; // Moving Uploaded file
echo "Image Uploaded Successfully...!!";
// echo "<br/><b>File Name:</b> " . $_FILES["file"]["name"] . "<br>";
echo "<br><b>Type:</b> " . $_FILES["file"]["type"] . "<br>";
echo "<b>Size:</b> " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
 echo "<b>Temp file:</b> " . $_FILES["file"]["tmp_name"] . "<br>";
}

}



}
else
{
echo "***Invalid file Size or Type;***";
}
}
?>