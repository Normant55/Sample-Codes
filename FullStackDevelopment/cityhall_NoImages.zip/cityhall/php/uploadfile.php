<!-- <script src = "../js/uploadfile.js"></script> -->
<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("connectPDO.php");
ini_set('upload_max_filesize', '9M');
    $thislove = $_GET['thislove'];
    $success = 0;
    $uploadedFile = '';
    //File upload path
    $uploadPath = '../uploads/';
    $targetPath = $uploadPath . strip_tags($thislove) . ".pdf";
$firstname = strip_tags($_GET['firstname']);
$firstname = strtoupper($firstname);
$middlename = strip_tags($_GET['middlename']);
$middlename = strtoupper($middlename);
$lastname = strip_tags($_GET['lastname']);
$lastname = strtoupper($lastname);
$username = strip_tags($_GET['username']);
$errorlog = 0;
$statement = $dbh -> query("SELECT count(*) FROM Applicants WHERE firstname = '$firstname' AND middle = '$middlename' AND lastname = '$lastname'");
if($statement ->fetchColumn()>0){
  echo 'fn';
  $errorlog++;
}
$statement = $dbh -> query("SELECT count(*) FROM applicantlogin WHERE username = '$username'");
if($statement ->fetchColumn()>0){
  if($errorlog == 1){
  echo 'au';
  }else{
  echo 'u';
  }
  $errorlog++;
}else{
$statement = $dbh -> query("SELECT count(*) FROM userlogn WHERE username = '$username'");
if($statement ->fetchColumn()>0){
  if($errorlog == 1){
  echo 'au';
  }else{
  echo 'u';
  }
  $errorlog++;
} 
}

if($errorlog==0){

$goodExtensions = array(

  '.pdf',

  ); 

  $error='';

  //set the current directory where you wanna upload the doc/docx files

  // $uploaddir = './ ';

  $name = $_FILES['myfile']['name'];//get the name of the file that will be uploaded

  $max_filesize=9000000;//set up a minimum file size(a doc/docx can't be lower then 10 bytes)

  // $stem=substr($name,0,strpos($name,'.'));

  //take the file extension

  $extension = substr($name, strpos($name,'.'), strlen($name)-1);

  //verify if the file extension is doc or docx

   if(!in_array($extension,$goodExtensions))

     $error.='Extension not allowed<br>';

echo "<span> </span>"; //verify if the file size of the file being uploaded is greater then 1

   if(filesize($_FILES['myfile']['tmp_name']) > $max_filesize)

     $error.='File size too large<br>'."\n";

//   $uploadfile = $uploadPath . $stem.$extension;

// $filename=$stem.$extension;

if ($error=='')

{
// echo $uploadfile;
if (@move_uploaded_file($_FILES['myfile']['tmp_name'], $targetPath)) {

echo 'File Uploaded. Thank You and please wait while application form is being processed for print preview...';

}




  // $allowedExts = array("pdf", "doc", "docx");
  //   $wet = explode(".", $_FILES['myfile']["name"]);
  //   $extension = end($wet);
  //   if (($_FILES["myfile"]["type"] == "application/pdf") || ($_FILES["myfile"]["type"] == "application/msword") || ($_FILES["myfile"]["type"] == "application/vnd.openxmlformats-officedocument.wordprocessingml.document") && in_array($extension, $allowedExts))
  //   {
        //     if(@move_uploaded_file($_FILES['myfile']['tmp_name'], $targetPath)){
        // $success = 1;
        // $uploadedFile = $targetPath;
        // echo 'Success!';
    }
else{
    echo $error;
}
}
?>
<script type="text/javascript">function startup(){
  // registereduser = window.localStorage.getItem("registeredusername");
  // window.location.href = "printspecificapplicant.php?registereduser="+registereduser;
  window.close();
 
}
window.onload = startup();
</script>