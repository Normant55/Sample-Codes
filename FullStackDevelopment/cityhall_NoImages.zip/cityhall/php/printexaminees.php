<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("connectPDO.php");
require('../fpdf181/fpdf.php');
$pdf = new FPDF('P','mm','A4');
$statement = $dbh -> prepare("SELECT * FROM Applicants");
$statement -> execute();
$pdf->AddPage();
$pdf->Ln(6);
$pdf->Image('../images/mainlogo.jpg',5, 15,-300);
$pdf->SetFont('times','B',16);
$pdf->Cell(15, 6, '', 0);
$pdf->Cell(40,10,'Applicant List');
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
}
	$pdf->Output();
?>