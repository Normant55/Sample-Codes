<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../connectPDO.php');
// if(empty($_POST['username'])){
//         echo '<script language="JavaScript" type="text/javascript">';
//         echo 'alert("Page Violation!");';
//         echo 'window.location.href = "../../index.php"';
//         echo '</script>';
//         exit();
// }
$registeruser = strip_tags($_GET['username']);
$registerpass = strip_tags($_GET['password']);
$registergende = $_GET['gender'];
$registerbirth = $_GET['birthday'];
$officeorigin = $_GET['officeorigin'];
$registeremai = strip_tags($_GET['email']);
$registerfname = strip_tags($_GET['firstname']);
$registermname = strip_tags($_GET['middlename']);
$registerlname = strip_tags($_GET['lastname']);
$errorlog = array();
$theasci = array();
$thefinalcode = array();
$asciin = array();
$asciiString = '';
// $ascipass = ord($registerpass);
// $ascipass = $ascipass + 123;
// $asciienc .= chr(ascipass);
// $string ="This is an example string with a few specialy symbols: *?%&/äö$ü!";
for($i = 0; $i != strlen($registerpass); $i++)
{
     $asciiString .="&#".(ord($registerpass[$i])+123)." ";
     // $asciiString += 123;
     // $asciiCode = str_replace("&", "&amp;", $asciiString);
     // echo ''.$asciiString;
     // array_push($theasci, $asciiCode);
     // $asciicodex .= chr($asciiString[$i])."";
}
array_push($theasci, $asciiString);
//  $asciiCode = str_replace(" ", " ", $asciiString);
// $thefinalcode = explode(" ", $asciiCode);
// for($i = 0; $i != strlen($registerpass); $i++)
// {
//     echo 'skip: ' .$thefinalcode[$i];
//  $asciienc = chr($thefinalcode[$i]);
//  echo 'encryption:'.$asciienc.' ';
//   array_push($theasci, $asciienc);

// }
$asciiCode2 = implode(" ", $theasci);
$asciiCode3 = str_replace(" ", "", $asciiCode2);
  // $sixfourbitencoding = $asciiCode3;
   // $sixfourbitencoding = base64_encode($asciiCode3);
echo 'final encryption: '.$asciiCode3;
$query = "select count(*) from employee where firstname = :firstname AND middle = :middlename AND lastname = :lastname AND birthdate = :birthdate";
$stmt = $dbh -> prepare($query);
$stmt->bindParam(':firstname', $registerfname);
$stmt->bindParam(':middlename', $registermname);
$stmt->bindParam(':lastname', $registerlname);
$stmt->bindParam(':birthdate', $registerbirth);
// $stmt->bindParam(':gender', $registergende);
$stmt -> execute();
//$ok = $stmt -> fetchColumn();
if($stmt -> fetchColumn() > 0){
  $error = 0;
    $query = "select * from employee where firstname = '$registerfname' AND middle = '$registermname' AND lastname = '$registerlname'";
     $stmt = $dbh -> query($query);
    while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
        $employeeid = $row['employeeid'];
    }
    $query = "SELECT count(*) FROM userlogn WHERE employeeid = '$employeeid'";
    $stmt = $dbh -> query($query);
    if($stmt -> fetchColumn() > 0){
        array_push($errorlog, 'employeeid already taken');
        // echo ' here';
        $error++;
    }
    $query = "SELECT count(*) FROM userlogn WHERE username = '$registeruser'";
    $stmt = $dbh -> query($query);
    if($stmt -> fetchColumn() > 0){
        array_push($errorlog, 'username already taken');
        $error++;
        // echo ' here';
    }
if($error == 0){
$query = "INSERT INTO userlogn(username, password, intra_pword, datetimelog, officeOrigin, employeeid) VALUES ('$registeruser', '$registerpass', '$registerpass' , GETDATE(), '$officeorigin' , '$employeeid');"; 
// simple query  
$stmt = $dbh->query($query);
if($stmt){
        // echo '<script language="JavaScript" type="text/javascript">';
        // echo 'alert("Registration Complete!");';
        // echo 'window.location.href = "../../index.php"';
        // echo '</script>';
  echo '<div id = "registrationconfirm">Success</div>';
}else{
  echo '<div id = "registrationconfirm">Query Error!</div>';
}}
else{
    // echo '<script language="JavaScript" type="text/javascript">';
    // echo 'alert("'.implode("&&", $errorlog).'");';
    //     echo 'window.location.href = "../../registrationindex.php"';
    // echo '</script>';
    echo '<div id = "registrationconfirm">'.implode("&&", $errorlog).'</div>';
}
$stmt = null;
}
else{
    // echo '<script language="JavaScript" type="text/javascript">';
    // echo 'alert("No matching fullname!");';
    //     echo 'window.location.href = "../../registrationindex.php"';    
    // echo '</script>';
    // echo ''.implode(" ", $errorlog);
      echo '<div id = "registrationconfirm">No matching fullname or birthday!</div>';
}


/*
$statement = $dbh->prepare("INSERT INTO user_account(user_name, user_password, gender, birthday, country, email, firstname, middlename, lastname)
    VALUES(:uname, :upass, :ugender, :birth, :ucountry, :uemail, :fname, :mname, :lname,)");
$statement->execute(array(
    "uname" => "$registeruser",
    "upass" => "$registerpass",
    "ugender" => "$registergende",
    "birth" => "$registerbirth",
    "ucountry" => "$registercount",
    "uemail" => "$registeremai",
    "fname" => "$registerfname",
    "mname" => "$registermname",
    "lname" => "$registerlname"
)); */
?>