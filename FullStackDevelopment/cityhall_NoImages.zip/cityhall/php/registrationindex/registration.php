<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('../../php/connectPDO.php');
if(empty($_POST['username'])){
        echo '<script language="JavaScript" type="text/javascript">';
        echo 'alert("Page Violation!");';
        echo 'window.location.href = "../../index.php"';
        echo '</script>';
        exit();
}
$registeruser = $_POST['username'];
$registerpass = $_POST['password'];
$registergende = $_POST['gender'];
$registerbirth = $_POST['birthday'];
$officeorigin = $_POST['officeorigin'];
$registeremai = $_POST['email'];
$registerfname = $_POST['firstname'];
$registermname = $_POST['middlename'];
$registerlname = $_POST['lastname'];
$errorlog = array();
// $ascipass = ord($registerpass);
// $ascipass = $ascipass + 123;
// $asciienc .= chr(ascipass);
$query = "select count(*) from employee where firstname = :firstname AND middle = :middlename AND lastname = :lastname";
$stmt = $dbh -> prepare($query);
$stmt->bindParam(':firstname', $registerfname);
$stmt->bindParam(':middlename', $registermname);
$stmt->bindParam(':lastname', $registerlname);
// $stmt->bindParam(':birthdate', $registerbirth);
// $stmt->bindParam(':gender', $registergende);
$stmt -> execute();
//$ok = $stmt -> fetchColumn();
if($stmt -> fetchColumn() > 0){
    $query = "select * from employee where firstname = '$registerfname' AND middle = '$registermname' AND lastname = '$registerlname'";
     $stmt = $dbh -> query($query);
    while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
        $employeeid = $row['employeeid'];
    }
    $query = "SELECT count(*) FROM userlogn WHERE employeeid = '$employeeid'";
    $stmt = $dbh -> query($query);
    if($stmt -> fetchColumn() > 0){
        array_push($errorlog, 'employeeid already taken');
        // echo ' here';
    }
    $query = "SELECT count(*) FROM userlogn WHERE username = '$registeruser'";
    $stmt = $dbh -> query($query);
    if($stmt -> fetchColumn() > 0){
        array_push($errorlog, 'username already taken');
        // echo ' here';
    }
$query = "INSERT INTO userlogn(username, password, datetimelog, officeOrigin, employeeid) VALUES ('$registeruser', '$registerpass', GETDATE(), '$officeorigin' , '$employeeid');";  

// simple query  
$stmt = $dbh->query($query);
if($stmt){
        echo '<script language="JavaScript" type="text/javascript">';
        echo 'alert("Registration Complete!");';
        echo 'window.location.href = "../../index.php"';
        echo '</script>';
}
else{
    echo '<script language="JavaScript" type="text/javascript">';
    echo 'alert("'.implode("&&", $errorlog).'");';
        echo 'window.location.href = "../../registrationindex.php"';
    echo '</script>';
}
$stmt = null;
}
else{
    echo '<script language="JavaScript" type="text/javascript">';
    echo 'alert("No matching fullname!");';
        echo 'window.location.href = "../../registrationindex.php"';    
    echo '</script>';
    // echo ''.implode(" ", $errorlog);
}


/*
$statement = $dbh->prepare("INSERT INTO user_account(user_name, user_password, gender, birthday, country, email, firstname, middlename, lastname)
    VALUES(:uname, :upass, :ugender, :birth, :ucountry, :uemail, :fname, :mname, :lname,)");
$statement->execute(array(
    "uname" => "$registeruser",
    "upass" => "$registerpass",
    "ugender" => "$registergende",
    "birth" => "$registerbirth",
    "ucountry" => "$registercount",
    "uemail" => "$registeremai",
    "fname" => "$registerfname",
    "mname" => "$registermname",
    "lname" => "$registerlname"
)); */

?>