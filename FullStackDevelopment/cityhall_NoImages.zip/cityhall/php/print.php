<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("connectPDO.php");
require('../fpdf181/fpdf.php');
$theids =  $_GET['studID'];
$startmonth =  $_GET['startmonth'];
$startday =  $_GET['startday'];
$startyear =  $_GET['startyear'];
$endmonth =  $_GET['endmonth'];
$endday =  $_GET['endday'];
$endyear =  $_GET['endyear'];
$a_date = $endyear."-".$endmonth."-".$endday;
$maxdaymonth = date("t", strtotime($a_date));
// $d1 = strtotime($startyear.'-'.$startmonth.'-'.$startday);
// $d2 = strtotime($endyear.'-'.$endmonth.'-'.$endday);
// $min_date = min($d1, $d2);
// $max_date = max($d1, $d2);
// $i = 0;
// while (($min_date = strtotime("+1 MONTH", $min_date)) <= $max_date) {
//     $i++;
// }
$pdf = new FPDF('P','mm','A4');
$query = "SELECT CONVERT(VARCHAR(10),dtr_date, 101) AS dtrdt
      ,[arrival_am]
      ,[departure_am]
      ,[arrival_pm]
      ,[departure_pm]
      ,[lut_freq]
      ,[ttl_lut]
      ,[lastname]
      ,[firstname]
      ,[middle]
  FROM [BIOMETRICS].[dbo].[dtr_final] as t1 INNER JOIN [BIOMETRICS].[dbo].[employee] as t2 ON t1.employeeid = t2.employeeid WHERE t1.employeeid = '$theids' AND t1.dtr_date BETWEEN '".$startyear."-".$startmonth."-01 00:00:00.000' AND '".$endyear."-".$endmonth."-".$maxdaymonth." 00:00:00.000'
  ORDER BY dtr_date asc
  "; 

  $stmt = $dbh_dtr -> query($query);
  $lutfreq = 0;
	$totlut = 0;
$monthprevious = 'none';
$monthnow = 'start';
$dayprevious = 'start';
$daynow = 'start';
$loopstring = 'start';
$daydtrdt = 'start';
	while($row = $stmt -> fetch( PDO::FETCH_ASSOC )){
$yearnow = substr($row['dtrdt'], 6, 4); 
$monthnow = substr($row['dtrdt'], 0, 2);
$dateObj   = DateTime::createFromFormat('!m', $monthnow);
$monthName = $dateObj->format('F'); // March
$daytoploop = substr($row['dtrdt'], 3, 2);
$b_date = $yearnow."-".$monthnow."-".$daytoploop;
if($daytoploop == '01'){
$nowmaxdaymonth = date("t", strtotime($b_date));}

if($monthnow != $monthprevious){
$pdf->AddPage();
$pdf->Ln(6);
$pdf->Image('../images/mainlogo.jpg',5, 15,-300);
$pdf->SetFont('times','B',16);
$pdf->Cell(15, 6, '', 0);
$pdf->Cell(40,10,'Daily Time Record');
$pdf->Ln(3);
$pdf->SetFont('times', '', 6);
$pdf->Cell(25, 6, '', 0);
$pdf->Cell(40,12, ' '.date("F jS \of Y"));
$pdf->Ln(18);
$pdf->SetFont('times','B',16);
$pdf->Cell(20, 6,  $row['lastname'].', '.$row['firstname'].' '.$row['middle'], 0);
$pdf->Ln(5);
$pdf->SetFont('times','',8);
$pdf->Cell(20, 6.5, 'For the period of', 0);
$pdf->SetFont('times','',10);
$pdf->Cell(50, 6.5, $monthName.' 1 - '.$nowmaxdaymonth.' '.$yearnow, 0);
$pdf->Ln(4);
$pdf->SetFont('times','',8);
$pdf->Cell(20, 6.5, 'Official hours of arrival and departure 8:00 am-12:00 am 1pm-5:30pm', 0);
$pdf->Ln(8);
$pdf->SetFont('times','B',8);
$pdf->Cell(20, 6, 'Date', 1, 0, 'C');
$pdf->Cell(30, 6, 'Day' , 1, 0, 'C');
$pdf->Cell(20, 6, 'Arrival', 1, 0, 'C');
$pdf->Cell(20, 6, 'Departure', 1, 0, 'C');
$pdf->Cell(20, 6, 'Arrival', 1, 0, 'C');
$pdf->Cell(20, 6, 'Departure', 1, 0, 'C');
$pdf->Cell(20, 6, 'L&UT.Freq', 1, 0, 'C');
$pdf->Cell(20, 6, 'Tot.L&UT', 1, 0, 'C');
}
$month = substr($daydtrdt, 0, 2);
$day = substr($daydtrdt, 3, 2);
$year = substr($daydtrdt, 6, 4); 
if($loopstring != $row['dtrdt']&&($dayprevious < 31)){
if($dayprevious != 'start'){
$daynow = substr($row['dtrdt'], 3, 2);
$daynow = $daynow + 1 - 1;
}
while($daynow != $dayprevious){
$pdf->SetFont('times','',8);
$day++;
$combined = $year.'-'.$month.'-'.$day;
$dayOfWeek = date("l", strtotime($combined));
$pdf->Ln(6);
$combined = $month.'/'.$day.'/'.$year;
$pdf->Cell(20, 6, $combined, 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(30, 6, $dayOfWeek , 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(20, 6, '', 'L, R' ,0, 'L, R',0, 'C');
$pdf->Cell(20, 6, '', 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(20, 6, '', 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(20, 6, '', 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(20, 6, '0', 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(20, 6, '0', 'L, R' ,0, 'L, R', 0, 'C');
$daynow--;
}}

$pdf->SetFont('times','',8);
$month = substr($row['dtrdt'], 0, 2);
$day = substr($row['dtrdt'], 3, 2);
$year = substr($row['dtrdt'], 6, 4); 
$combined = $year.'-'.$month.'-'.$day;
$dayOfWeek = date("l", strtotime($combined));
if($loopstring != $row['dtrdt']){
$pdf->Ln(6);
$pdf->Cell(20, 6, $row['dtrdt'], 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(30, 6, $dayOfWeek , 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(20, 6, $row['arrival_am'], 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(20, 6, $row['departure_am'], 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(20, 6, $row['arrival_pm'], 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(20, 6, $row['departure_pm'], 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(20, 6, $row['lut_freq'], 'L, R' ,0, 'L, R', 0, 'C');
$pdf->Cell(20, 6, $row['ttl_lut'], 'L, R' ,0, 'L, R', 0, 'C');
$loopstring = $row['dtrdt'];


if($day == $nowmaxdaymonth){
$pdf->Ln(0);
$pdf->SetFont('times','B',12);
$pdf->Cell(20, 6, '', 'B' ,0, 'B', 0, 'C');
$pdf->Cell(30, 6, '' , 'B' ,0, 'B', 0, 'C');
$pdf->Cell(20, 6, '', 'B' ,0, 'B', 0, 'C');
$pdf->Cell(20, 6, '', 'B' ,0, 'B', 0, 'C');
$pdf->Cell(20, 6, '', 'B' ,0, 'B', 0, 'C');
$pdf->Cell(20, 6, '', 'B' ,0, 'B', 0, 'C');
$pdf->Cell(20, 6, '', 'B' ,0, 'B', 0, 'C');
$pdf->Cell(20, 6, '', 'B' ,0, 'B', 0, 'C');
$pdf->Ln(15);
$pdf->Cell(40, 6, 'This document will only be used for viewing', 0);
}



}






$monthprevious = substr($row['dtrdt'], 0, 2);
$dayprevious = substr($row['dtrdt'], 3, 2);
$dayprevious++;
$daydtrdt = $row['dtrdt'];
	}



	$pdf->Output();
?>