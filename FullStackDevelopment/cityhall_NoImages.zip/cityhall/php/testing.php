<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include('connectPDO.php');
$dep = $_GET['valuefortest'];
$sarray = array();
$targe = array();
$dep = str_replace("<li><a>", "", $dep);
$dep = str_replace("</a></li>", ", ", $dep);
// echo $dep;
$sarray = explode(", ", $dep);
$arraycounter = count($sarray);
for($min = 0; $min<$arraycounter; $min++){
$what_you_want = substr($sarray[$min], 0, strpos($sarray[$min], ':'));
echo $what_you_want;
$jobdescription = str_replace($what_you_want.':', '', $sarray[$min]);
 array_push($targe, $jobdescription);
}
  //   $queryforabbriv = "select deptAbbriv from OfficeHeaders WHERE Department = '".implode('\' OR Department = \'',$sarray)."'";
  // $stmtdepabbriv = $dbhbudget -> query($queryforabbriv);
  // while($row = $stmtdepabbriv -> fetch( PDO::FETCH_ASSOC )){
  //     array_push($targe, $row['deptAbbriv']);
  //   }
  $deptarmentschoosen = implode(", ", $targe);
  echo $deptarmentschoosen;
?>