<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("connectPDO.php");
require('../fpdf181/fpdf.php');
$pdf = new FPDF('P','mm','A4');
$startmonth =  $_GET['startmonthtoolkit'];
$startday =  $_GET['startdaytoolkit'];
$startyear =  $_GET['startyeartoolkit'];
$endmonth =  $_GET['endmonthtoolkit'];
$endday =  $_GET['enddaytoolkit'];
$endyear =  $_GET['endyeartoolkit'];
$gender_select =  $_GET['gender_select'];
$status_select =  $_GET['status_select'];
$input_min_age =  $_GET['input_min_age'];
$input_max_age =  $_GET['input_max_age'];
if($gender_select == 1){
$gender_query = 'gender = 1';}elseif($gender_select == 0){
$gender_query = 'gender = 0';}elseif($gender_select == 2){
$gender_query = 'gender = 1 OR gender = 0';
}
if($status_select == 0){
$select_query = 'process_status = \'Hired\'';}
elseif($status_select == 3){
$select_query = 'process_status IS NULL';}
elseif($status_select == 2){
$select_query = 'process_status = \'Viewed\'';}
elseif($status_select == 1){
$select_query = 'process_status = \'For Exam\'';}
elseif($status_select == 4){
$select_query = '1 = 1';
}
if(isset($_GET['searchkeyword']) AND !empty($_GET['searchkeyword'])){
	$searchkeyword = $_GET['searchkeyword'];
$keys = explode(" ", $searchkeyword);
$idfound = array();
$x = 1;
$current = 0;
$counter = 0;
while($x<2){
	if(isset($keys[$current]) && $keys[$current]!=''){
	$searchthis = $keys[$current];
	$current++;
$statement = $dbh -> prepare("SELECT employeeid, lastname, firstname, middle, job_title, course_degree, eligibility, birthdate, CONVERT(VARCHAR(10),birthdate, 101) AS birthdate, school_grad, date_registered FROM Applicants WHERE (lastname LIKE :searchthis OR firstname LIKE :searchthis2 OR middle LIKE :searchthis3 OR job_title LIKE :searchthis4 OR eligibility LIKE :searchthis5 OR school_grad LIKE :searchthis6 OR course_degree LIKE :searchthis7 OR home_address LIKE :searchthis8) AND (CONVERT(int, age) >= :input_min_age AND CONVERT(int, age) <= :input_max_age) AND (".$select_query.") AND (".$gender_query.") AND employeeid NOT IN ('".implode(' \', \'', $idfound)."') AND date_registered between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' ORDER BY date_registered DESC");
$statement -> bindValue(':searchthis', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis2', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis3', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis4', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis5', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis6', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis7', '%'.$searchthis.'%');
$statement -> bindValue(':searchthis8', '%'.$searchthis.'%');
$statement -> bindParam(':input_min_age', $input_min_age, PDO::PARAM_INT);
$statement -> bindParam(':input_max_age', $input_max_age, PDO::PARAM_INT);
$statement -> execute();
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
	if($counter == 0){
$pdf->AddPage();
$pdf->Ln(6);
$pdf->Image('../images/mainlogo.jpg',5, 15,-300);
$pdf->SetFont('times','B',16);
$pdf->Cell(15, 6, '', 0);
$pdf->Cell(40,10,'Applicant List');

$pdf->Ln(20);
$pdf->SetFont('times','B',12);
// $pdf->Cell(70,8,'Full Name', 1, 0, 'C');
// $pdf->Cell(70,8,'Position', 1, 0, 'C');
$pdf->Cell(50,8,'Full Name', 0, 0, 'C');
$pdf->Cell(100,8,'Position', 0, 0, 'C');
$pdf->Cell(20, 8, 'Date Applied', 0, 0, 'C');
	}
$horray = array();
$horray = explode(", ", $row['job_title']);
$beep = sizeof($horray);
$beep--;
$leap = 1;
$pdf->Ln(8);
$pdf->SetFont('times', '', 8);
$pdf->Cell(5, 0, '', 0);
$pdf->Cell(40,15, $row['lastname'].', '.$row['firstname'].' '.$row['middle']);
$pdf->Cell(30, 15, '', 0);
$pdf->Cell(40, 15, $horray[0]);
$pdf->Cell(30, 15, '', 0);
$pdf->Cell(40, 15, $row['date_registered'], 0);
$counter++;
while($leap<$beep){
$pdf->Ln(8);
$pdf->Cell(5, 0, '', 0);
$pdf->Cell(40,15, '', 0);
$pdf->Cell(30, 15, '', 0);
$pdf->Cell(40, 15, $horray[$leap]);
$pdf->Cell(30, 15, '', 0);
$pdf->Cell(15, 15, '', 0);
$counter++;
$leap++;
}
if($counter == 23){
	$counter = 0;
}
}
}else{
	$x = 2;
}
}}else{
$statement = $dbh -> prepare("SELECT employeeid, lastname, firstname, middle, job_title, course_degree, eligibility, birthdate, CONVERT(VARCHAR(10),birthdate, 101) AS birthdate, school_grad, date_registered FROM Applicants WHERE (CONVERT(int, age) >= '$input_min_age' AND CONVERT(int, age) <= '$input_max_age') AND (".$select_query.") AND (".$gender_query.") AND date_registered between '".$startyear."-".$startmonth."-".$startday." 00:00:00.000' AND '".$endyear."-".$endmonth."-".$endday." 00:00:00.000' ORDER BY date_registered DESC");
$statement -> execute();
$counter = 0;
while($row = $statement -> fetch(PDO::FETCH_ASSOC)){
	if($counter == 0){
$pdf->AddPage();
$pdf->Ln(6);
$pdf->Image('../images/mainlogo.jpg',5, 15,-300);
$pdf->SetFont('times','B',16);
$pdf->Cell(15, 6, '', 0);
$pdf->Cell(40,10,'Applicant List');
$pdf->Ln(20);
$pdf->SetFont('times','B',12);
// $pdf->Cell(70,8,'Full Name', 1, 0, 'C');
// $pdf->Cell(70,8,'Position', 1, 0, 'C');
$pdf->Cell(50,8,'Full Name', 0, 0, 'C');
$pdf->Cell(100,8,'Position', 0, 0, 'C');
$pdf->Cell(20, 8, 'Date Applied', 0, 0, 'C');
	}
$horray = array();
$horray = explode(", ", $row['job_title']);
$beep = sizeof($horray);
$beep--;
$leap = 1;
$pdf->Ln(8);
$pdf->SetFont('times', '', 8);
$pdf->Cell(5, 0, '', 0);
$pdf->Cell(40,15, $row['lastname'].', '.$row['firstname'].' '.$row['middle']);
$pdf->Cell(30, 15, '', 0);
$pdf->Cell(40, 15, $horray[0]);
$pdf->Cell(30, 15, '', 0);
$pdf->Cell(40, 15, $row['date_registered'], 0);
$counter++;
while($leap<$beep){
$pdf->Ln(8);
$pdf->Cell(5, 0, '', 0);
$pdf->Cell(40,15, '', 0);
$pdf->Cell(30, 15, '', 0);
$pdf->Cell(40, 15, $horray[$leap]);
$pdf->Cell(30, 15, '', 0);
$pdf->Cell(15, 15, '', 0);
$counter++;
$leap++;
}
if($counter == 23){
	$counter = 0;
}
}}	
	$pdf->Output();
?>