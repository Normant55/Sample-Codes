<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("connectPDO.php");
$newsid = $_GET['newsid'];
$attribute = $_GET['attribute'];
if(isset($_FILES["file"]["type"]))
{
$validextensions = array("jpeg", "jpg", "png");
$temporary = explode(".", $_FILES["file"]["name"]);
$file_extension = end($temporary);
if ((($_FILES["file"]["type"] == "image/png") ||($_FILES["file"]["type"] == "image/jpeg")||($_FILES["file"]["type"] == "image/jpg")) && ($_FILES["file"]["size"] < 400000000)//Approx. 100kb files can be uploaded.
&& in_array($file_extension, $validextensions)) {
if ($_FILES["file"]["error"] > 0)
{
echo "Return Code: " . $_FILES["file"]["error"] . "<br/><br/>";
}
else
{
$insertuser = $dbhsub -> prepare("INSERT INTO coverextender(imageid, description, type, sizeposition, dateuploaded, imagepath)VALUES('$newsid', 'none', 'none', :attribute, GETDATE(), 'none')");
$insertuser -> bindParam(':attribute', $attribute);
$insertuser -> execute();
if($insertuser){
}

	$statement = $dbhsub -> prepare("SELECT TOP 1 extenderid FROM coverextender ORDER BY extenderid DESC");
	$statement -> execute();
	while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
		$currentidea = $row['extenderid'];
	}
$insertuser = $dbhsub -> prepare("UPDATE coverextender SET imagepath = '../images/coverimages/".$currentidea.".png' WHERE extenderid = :currentidea");
$insertuser -> bindParam(':currentidea', $currentidea);
$insertuser -> execute();
if($insertuser){
}	
$sourcePath = $_FILES['file']['tmp_name']; // Storing source path of the file in a variable
$targetPath = "../images/coverimages/".$currentidea.".png"; // Target path where file is to be stored
// $temp = explode(".", $_FILES["file"]["name"]);
// $newfilename = round(microtime(true)) . '.' . end($temp);
// move_uploaded_file($_FILES["file"]["tmp_name"], "../img/imageDirectory/" . $newfilename);
move_uploaded_file($sourcePath,$targetPath) ; // Moving Uploaded file
echo "Image Uploaded Successfully...!!";
// echo "<br/><b>File Name:</b> " . $_FILES["file"]["name"] . "<br>";
echo "<br><b>Type:</b> " . $_FILES["file"]["type"] . "<br>";
echo "<b>Size:</b> " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
 echo "<b>Temp file:</b> " . $_FILES["file"]["tmp_name"] . "<br>";
}



}
else
{
echo "***Invalid file Size or Type;***";
}
}
?>