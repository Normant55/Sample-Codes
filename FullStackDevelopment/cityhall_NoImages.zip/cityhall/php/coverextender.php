<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
include("connectPDO.php");
$theid = $_GET['theid'];
$title = $_GET['title'];
$titleconid = $_GET['titleconid'];
$alignmentsub = $_GET['alignmentsub'];
$description = $_GET['description'];
$description = str_replace("e1p1", "<", $description);
$description = str_replace("e1p2", ">", $description);
$description = str_replace("e1p3", "\"", $description);
$description = str_replace("e1p4", "#", $description);
$description = str_replace("e1p5", "(", $description);
$description = str_replace("e1p6", ")", $description);
$description = str_replace("e1p7", "-", $description);
$description = str_replace("e1p8", ":", $description);
$description = str_replace("e1p9", "&", $description);
$description = str_replace("rgb(255, 255, 255)", "rgba(0,0,0,0)", $description);
if(isset($_FILES["file"]["type"]))
{
$validextensions = array("jpeg", "jpg", "png");
$temporary = explode(".", $_FILES["file"]["name"]);
$file_extension = end($temporary);
if ((($_FILES["file"]["type"] == "image/png") ||($_FILES["file"]["type"] == "image/jpeg")||($_FILES["file"]["type"] == "image/jpg")) && ($_FILES["file"]["size"] < 400000000)//Approx. 100kb files can be uploaded.
&& in_array($file_extension, $validextensions)) {
if ($_FILES["file"]["error"] > 0)
{
echo "Return Code: " . $_FILES["file"]["error"] . "<br/><br/>";
}
else
{
$insertuser = $dbhsub -> prepare("INSERT INTO coverextender(imagepath, description, imagetitle, dateuploaded, alignment, imageid)VALUES('../images/extendersimages/temp.png', :description, :title, GETDATE(), :alignmentsub, :titleconid)");
$insertuser -> bindParam(':description', $description);
$insertuser -> bindParam(':title', $title);
$insertuser -> bindParam(':alignmentsub', $alignmentsub);
$insertuser -> bindParam(':titleconid', $titleconid);
$insertuser -> execute();
if($insertuser){
}
	$statement = $dbhsub -> prepare("SELECT TOP 1 extenderid FROM coverextender ORDER BY extenderid DESC");
	$statement -> execute();
	while($row = $statement ->fetch(PDO::FETCH_ASSOC)){
		$currentidea = $row['extenderid'];
	}
$insertuser = $dbhsub -> prepare("UPDATE coverextender SET imagepath = '../images/extendersimages/".$currentidea.".png' WHERE extenderid = :currentidea");
$insertuser -> bindParam(':currentidea', $currentidea);
$insertuser -> execute();
if($insertuser){
}
$sourcePath = $_FILES['file']['tmp_name']; // Storing source path of the file in a variable
$targetPath = "../images/extendersimages/".$currentidea.".png"; // Target path where file is to be stored
// $temp = explode(".", $_FILES["file"]["name"]);
// $newfilename = round(microtime(true)) . '.' . end($temp);
// move_uploaded_file($_FILES["file"]["tmp_name"], "../img/imageDirectory/" . $newfilename);
move_uploaded_file($sourcePath,$targetPath) ; // Moving Uploaded file
echo "Image Uploaded Successfully...!!";
// echo "<br/><b>File Name:</b> " . $_FILES["file"]["name"] . "<br>";
echo "<br><b>Type:</b> " . $_FILES["file"]["type"] . "<br>";
echo "<b>Size:</b> " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
 echo "<b>Temp file:</b> " . $_FILES["file"]["tmp_name"] . "<br>";
}



}
else
{
echo "***Invalid file Size or Type;***";
}
}
?>