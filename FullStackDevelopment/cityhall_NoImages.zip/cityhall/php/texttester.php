<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
$dasviet = $_GET['textareav'];
$dasviet = str_replace("e1p1", "<", $dasviet);
$dasviet = str_replace("e1p2", ">", $dasviet);
$dasviet = str_replace("e1p3", "\"", $dasviet);
$dasviet = str_replace("e1p4", "#", $dasviet);
echo $dasviet;
?>