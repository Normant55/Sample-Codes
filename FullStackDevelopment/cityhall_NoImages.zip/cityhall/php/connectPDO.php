<?php
header('Access-Control-Allow-Origin: 79.125.201.223:8080');
    try 
    {
      //putenv('ODBCSYSINI=/etc/'); 
      //putenv('ODBCINI=/etc/odbc.ini'); 
      // $hostname = "ABT-MOBILE2";
      $hostname = "79.125.201.223";
      $port = 8080;
      // $hostname = "192.168.1.222";
      // $hostname = "119.93.165.180";
      // $port = ;
      $dbname = "BIOMETRICS";
      $username = "squid";
      $pw = "squid211994";
      // $username = "msdss";
      // $pw = "madix_t";      
      $dbh = new PDO ("sqlsrv:server=$hostname;Database=$dbname","$username","$pw");
      $dbh->SetAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      //$dbh = new PDO("odbc:MSSQLServer", $username, $pw); 
      $dbname = "budgetdb";
      $dbhbudget = new PDO ("sqlsrv:server=$hostname;Database=$dbname","$username","$pw");
      $dbname = "biosub";
      $dbhsub = new PDO ("sqlsrv:server=$hostname;Database=$dbname","$username","$pw");
      $dbname = "HRIS";
      $dbhhris = new PDO ("sqlsrv:server=$hostname;Database=$dbname","$username","$pw");
      $hostname = "79.125.201.1";
      $dbname = "BIOMETRICS";
      $username = "msdss";
      $pw = "madix_t";
      $dbh_dtr = new PDO ("sqlsrv:server=$hostname;Database=$dbname","$username","$pw");
      $dbh_dtr->SetAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $dbname = "LGU_DEV";
      $dbh_leave = new PDO ("sqlsrv:server=$hostname;Database=$dbname","$username","$pw");
      $dbh_leave->SetAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);        
    }
    catch (PDOException $e) 
    {
      echo "Failed to get DB handle: " . $e->getMessage() . "\n";
      exit;
    }
    $stmt = $dbh->prepare("select name from master..sysdatabases where name = db_name()");
    $stmt->execute();
    while ($row = $stmt->fetch())
    {
      //print_r($row);
    }
      //unset($dbh); unset($stmt);
    //$dbh->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );  
    //$dbh->setAttribute( PDO::SQLSRV_ATTR_QUERY_TIMEOUT, 1 );  
    // $pagename = basename($_SERVER['PHP_SELF']);
    // if($pagename != 'componentspage.php'){
    // if(isset($_SESSION['itemidfcom'])&&!empty($_SESSION['itemidfcom'])){
    // unset($_SESSION['itemidfcom']);
    // } 
    // }
?>
