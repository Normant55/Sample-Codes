
function crud_function(condition, condition_targets, table, operation_columns, operation_targets, crud, message, database, callback)
  {
    $.post("http://localhost:8080/Revive_trading/php/engines/update_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        condition:condition,
        condition_targets:condition_targets,
        table:table,
        operation_columns:operation_columns,
        operation_targets:operation_targets,
        crud:crud,
        message:message,
        database:database
      },
    function(response,status)
      {
        callback(response);
        // alert(response);
        // codeAddress();
        // $("#form")[0].reset();
      });
  }

function crud_function_preset(condition, condition_targets,preset_columns,preset_targets, table, operation_columns, operation_targets, crud, message, database, callback)
  {
    $.post("http://localhost:8080/Revive_trading/php/engines/update_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        condition:condition,
        condition_targets:condition_targets,
        table:table,
        operation_columns:operation_columns,
        operation_targets:operation_targets,
        preset_columns:preset_columns,
        preset_targets:preset_targets,
        crud:crud,
        message:message,
        database:database
      },
    function(response,status)
      {
        callback(response);
        // alert(response);
        // codeAddress();
        // $("#form")[0].reset();
      });
  }

function crud_function_noload(condition, condition_targets, table, operation_columns, operation_targets, crud, message, database, callback)
  {
    $.post("http://localhost:8080/Revive_trading/php/engines/update_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        condition:condition,
        condition_targets:condition_targets,
        table:table,
        operation_columns:operation_columns,
        operation_targets:operation_targets,
        crud:crud,
        message:message,
        database:database
      },
    function(response,status)
      { 
        callback(response);
        // alert(response);
        // $("#form")[0].reset();
      });
  }

function crud_function_noload_noalert(condition, condition_targets, table, operation_columns, operation_targets, crud, message, database, callback)
  {
    $.post("http://localhost:8080/Revive_trading/php/engines/update_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        condition:condition,
        condition_targets:condition_targets,
        table:table,
        operation_columns:operation_columns,
        operation_targets:operation_targets,
        crud:crud,
        message:message,
        database:database
      },
    function(response,status)
      { 
        callback(response);
        // $("#form")[0].reset();
      });
}

function search_query(condition, table, operation_columns, condition_targets, suffix, type, message, database, callback)
{
    $.post("http://localhost:8080/Revive_trading/php/engines/select_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        condition:condition,
        table:table,
        operation_columns:operation_columns,
        condition_targets:condition_targets,
        suffix:suffix,
        type:type,
        message:message,
        database:database
      },
    function(response,status)
      { 
        // var search_query_returns = response;
        // $("#form")[0].reset();
        callback(response);
      });
}
function process_data(data, type, callback)
{
    $.post("http://localhost:8080/Revive_trading/php/engines/process_data.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        data:data,
        type:type
      },
    function(response,status)
      { 
        // var search_query_returns = response;
        // $("#form")[0].reset();
        callback(response);
      });
}
function select_maker(data, select_id){
                  var my_select = '<select id = "'+select_id+'">';
                  data = data.substring(0, data.length - 2);
                  var writer = data;
                  my_segregation = 0;
                    my_leavetype = writer.split(', ');
                    my_leavetype.forEach(function(element) {
                      if(my_segregation == 0){
                        my_select = my_select+'<option value = \''+element;
                        my_segregation = 1;
                      }else{
                        my_select = my_select+'\'>'+element+'</option>';
                        my_segregation = 0;
                      }
                    });
                    my_select = my_select+'</select>';
                    my_select = ''+my_select+'';
                return my_select;
}
function select_maker_function(data, select_id, sub_function, locator){
                  var my_select = '<select onchange = "'+sub_function+'" class = "input_standard" id = "'+select_id+'">';
                  data = data.substring(0, data.length - 2);
                  var writer = data;
                  my_segregation = 0;
                    my_leavetype = writer.split(', ');
                    my_leavetype.forEach(function(element) {
                      if(my_segregation == 0){
                        if(locator == element){
                        my_select = my_select+'<option selected value = \''+element;                         
                        }else{
                        my_select = my_select+'<option value = \''+element;
                        }
                        my_segregation = 1;
                      }else{
                        my_select = my_select+'\'>'+element+'</option>';
                        my_segregation = 0;
                      }
                    });
                    my_select = my_select+'</select>';
                    my_select = ''+my_select+'';
                return my_select;
}

function createNew_View() {
  var obj = {};
  //FORM CLASS
  obj.div_class = '';
  //FORM INPUTS
  obj.input_outer_class = '';
  obj.input_description = '';
  obj.input_id = '';
  obj.input_class = '';
  obj.input_type = '';
  //FORM BUTTONS
  obj.input_button_outer_class = '';
  obj.input_button_description = '';
  obj.input_button_id = '';
  obj.input_button_class = '';
  //VIEW TYPE
  obj.view_type = '';

  obj.run = function (callback)
  {
    $.post("http://localhost:8080/Revive_trading/php/engines/access_views.php", //Required URL of the page on server
      { // Data Sending With Request To Server
        //FORM CLASS
        div_class:obj.div_class,
        //FORM INPUTS
        input_outer_class:obj.input_outer_class,
        input_description:obj.input_description,
        input_id:obj.input_id,
        input_class:obj.input_class,
        input_type:obj.input_type,
        //FORM BUTTONS
        input_button_outer_class:obj.input_button_outer_class,
        input_button_description:obj.input_button_description,
        input_button_id:obj.input_button_id,
        input_button_class:obj.input_button_class,
        //VIEW TYPE
        view_type:obj.view_type
      },
    function(response,status)
      { 
        callback(response);
        // $("#form")[0].reset();
      });
  };
  return obj;
}
